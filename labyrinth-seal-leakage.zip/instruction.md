A straight-through labyrinth seal on a large rotor was tested on a leakage rig with dry air: first a series of steady points at several rotor speeds, inlet temperatures and pressure ratios, then four transient records logged once per second. `/app/data/seal_rig.json` describes the seal, the rotor and stator ring, the instruments, the record files and a start-up of the seal; `/app/data/seal_tests.csv` holds the steady points as logged, in the order they were run, and `/app/data/transient_TR1.csv` to `/app/data/transient_TR4.csv` hold the transient records.

Predict the leakage mass flow of the seal, in the condition the campaign left it in, at the listed times during the described start-up.

Write `/app/output/results.json` as a regular file containing a JSON object, without duplicate keys, with the single key `leakage_g_per_s`, mapping exactly `t60`, `t200`, `t450`, `t900` and `t2400` (seconds from the start of the start-up) to finite positive mass flows in g/s.

You have 28800 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
