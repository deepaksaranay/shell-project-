"""Independent reduction (no code shared with solution/predict_leakage.py or the generator).

Differences from the reference: Vermes' carry-over relation instead of Hodkinson's; the rub is located block by block
instead of by a global change-point fit; gas density at the meter's standard state from the ideal-gas law written out here.
1. Calibrate Cd, a Vermes factor and the thermal clearance slope on the first two blocks (rotor at rest, two temperatures).
2. With these frozen, fit one clearance offset for every later block (constant speed and temperature). Offsets of blocks at
   rest after running give the permanent opening (a rub); the first spinning block gives the centrifugal coefficient, and the
   rub is placed at the first block whose offset exceeds what centrifugal growth explains.
3. Refit Cd, the factor and both clearance coefficients to all points with the opening applied from that block on.
4. Transient records: invert the flow model sample by sample for the effective clearance and fit its thermal part as a
   ring response minus one rotor response (first-order lags of the gas temperature), with a separate rotor time constant in
   each gas-temperature record; derive the speed law of the rotor time constant from those and predict the start-up.

    python blockwise_reduction.py <data_dir> <results.json>
"""
import json, os, sys
import numpy as np
from scipy.optimize import brentq, least_squares

dd, of = sys.argv[1], sys.argv[2]
info = json.load(open(os.path.join(dd, 'seal_rig.json'))); sl = info['seal']
nt = sl['number_of_teeth']; pitch = sl['tooth_pitch_mm']/1e3; tip = sl['tooth_tip_width_mm']/1e3
b = sl['rotor_radius_at_teeth_mm']/1e3; c_cold = sl['radial_clearance_mm']/1e3
gas_R, k_ad = 287.05, 1.4
crit = (2/(k_ad + 1))**(k_ad/(k_ad - 1))
std_density = 101325.0/(gas_R*273.15)


def gap(speed, temp, cf, th):
    """cold clearance - cf (growth at 10000 rpm) x (speed/10000)^2 + th (per K) x (T - 293.15); cf, th from the data."""
    return c_cold - cf*1e-6*(speed/1e4)**2 + th*1e-6*(temp - 293.15)


def psi(r):
    r = max(r, crit); return np.sqrt(2*k_ad/(k_ad - 1)*(r**(2/k_ad) - r**((k_ad + 1)/k_ad)))


psi_star, psi_tiny = psi(crit), psi(1 - 1e-12)


def flow(pu, pd, temp, c, cd, fac):
    kin = 1/np.sqrt(1 - min(fac*8.52/((pitch - tip)/c + 7.23), 0.95))
    mults = [1.0] + [kin]*(nt - 1); base = cd*2*np.pi*b*c/np.sqrt(gas_R*temp)

    def downstream(m):
        p = pu
        for mm in mults:
            req = m/(mm*base*p)
            if req >= psi_star: return None
            p *= 1.0 if req <= psi_tiny else brentq(lambda r: psi(r) - req, crit, 1 - 1e-12)
        return p
    a, z = 0.0, mults[-1]*base*pu*psi_star
    for _ in range(70):
        mid = 0.5*(a + z)
        if downstream(mid) is None: z = mid
        else: a = mid
    if pd <= downstream(a): return a
    return brentq(lambda m: downstream(m) - pd, 1e-9*a, a, xtol=1e-14, rtol=1e-12)


tab = np.genfromtxt(os.path.join(dd, info['test_file']), delimiter=',', names=True)
pu = (tab['upstream_gauge_kPa'] + tab['barometer_kPa'])*1e3; pdn = (tab['downstream_gauge_kPa'] + tab['barometer_kPa'])*1e3
mf = tab['flow_slpm']*std_density/60000.0; spd = tab['speed_rpm']; tmp = tab['inlet_temperature_K']
blk = np.cumsum(np.r_[1, (np.abs(np.diff(spd)) > 500) | (np.abs(np.diff(tmp)) > 5)]) - 1


def misfit(sel, cd, fac, cf, th, extra):
    return np.array([flow(pu[i], pdn[i], tmp[i], gap(spd[i], tmp[i], cf, th) + extra[i], cd, fac) for i in np.where(sel)[0]])/mf[sel] - 1


zero = np.zeros(len(mf))
first = blk <= 1                                        # rotor at rest, two temperatures: Cd, Vermes factor, thermal slope
cd0, fac0, th0 = least_squares(lambda q: misfit(first, q[0], q[1], 0.0, q[2], zero), [0.7, 1.0, 0.5],
                               bounds=([0.2, 0.05, -3], [1.2, 3.0, 5])).x
offs = {}
for bb in range(2, blk.max() + 1):                      # every later block: one clearance offset with the rest frozen
    sel = blk == bb
    offs[bb] = (np.mean(spd[sel]), least_squares(lambda q: misfit(sel, cd0, fac0, 0.0, th0, np.full(len(mf), q[0]*1e-6)),
                                                [0.0], bounds=([-200], [200])).x[0])
# offset(block) = -cf (n/1e4)^2 (+ rub opening once it has happened). Blocks at rest after running show the opening alone;
# the rub is placed at the first block whose offset exceeds what centrifugal growth alone explains.
rest_after = [o for bb, (n, o) in offs.items() if n < 100]
opening = float(np.mean(rest_after)) if rest_after else 0.0
spun = [(bb, n, o) for bb, (n, o) in offs.items() if n >= 100]
cf_first = -spun[0][2]/(spun[0][1]/1e4)**2
jump = next((bb for bb, n, o in spun if o + cf_first*(n/1e4)**2 > 0.5*opening), None)
if jump is None: jump = min(bb for bb, (n, o) in offs.items() if n < 100)
extra = np.where(blk >= jump, opening*1e-6, 0.0)
cd, fac, cf, th = least_squares(lambda q: misfit(np.ones(len(mf), bool), q[0], q[1], q[2], q[3], extra), [cd0, fac0, cf_first, th0],
                                bounds=([0.2, 0.05, -100, -3], [1.2, 3.0, 200, 5])).x
print('offsets um', {k: round(v[1], 1) for k, v in offs.items()}, 'opening', round(opening, 1), 'um from block', jump,
      'centrifugal', round(cf, 1), 'um at 10000 rpm, thermal', round(th, 3), 'um/K')



# ---------------------------------------------------------------------------------------------------------------------
# Transient part (start-up target). The steady calibration above fixes Cd, the Vermes factor, the centrifugal coefficient
# and the rub. Each sample of the transient records is turned into an effective running clearance by inverting the
# calibrated flow model (root finding in c). Its thermal part, c - (c_cold + opening - cf (n/1e4)^2), is fitted as
#     g_ring x lagged(T, tau_ring) - g_rotor x lagged(T, tau_rotor[record]) - d_cf (n/1e4)^2     (temperatures re 293.15 K),
# where d_cf corrects the centrifugal coefficient of the steady calibration with the speed-ramp record,
# a deliberately simpler rotor than the reference's land-plus-disc model: one rotor lag, but with its own time constant in
# each record, because rotor heat transfer depends on the speed of that record; the rotor is also driven by windage heating
# ~ (n/12500)^2, which lags like the rest of the rotor and shows as the slow drift after the speed ramp of TR3. The gains are linear for
# given time constants; the time constants are found on a log grid and refined. The disc time constants of the constant-speed records
# (1500, 3000 and 6000 rpm) fix the speed law 1/tau_rotor = A + C n^0.8 (turbulent rotating-disc heat transfer, Nu ~ Re^0.8, plus a
# speed-independent part), which is integrated along the start-up.
from scipy.optimize import minimize


def exp_lag(Tg, t, tau):
    tau = np.broadcast_to(np.asarray(tau, float), Tg.shape)
    out = np.empty_like(Tg); y = Tg[0]
    for i in range(len(t)):
        if i:
            a_ = np.exp(-(t[i] - t[i-1])/(0.5*(tau[i] + tau[i-1]))); y = a_*y + (1 - a_)*0.5*(Tg[i] + Tg[i-1])
        out[i] = y
    return out


samples = []; samples_n = []
for fn in info['transient_files'].values():
    tr = np.genfromtxt(os.path.join(dd, fn), delimiter=',', names=True)
    keep = slice(None, None, 5)
    t_ = tr['time_s']; Tg_ = tr['inlet_temperature_K']; n_ = tr['speed_rpm']
    pu_ = (tr['upstream_gauge_kPa'] + tr['barometer_kPa'])*1e3; pd_ = (tr['downstream_gauge_kPa'] + tr['barometer_kPa'])*1e3
    m_ = tr['flow_slpm']*std_density/60000.0
    ceff = np.array([brentq(lambda cc: flow(pu_[i], pd_[i], Tg_[i], cc, cd, fac) - m_[i], 0.05e-3, 1.0e-3) for i in range(0, len(t_), 5)])
    base = c_cold + opening*1e-6 - cf*1e-6*(n_[keep]/1e4)**2
    samples.append((t_, Tg_, keep, ceff - base, float(np.median(n_)), (n_[keep]/1e4)**2, (n_/12500.0)**2))
    samples_n.append(n_)


def disc_tau(lt, n):
    """Disc time constant from the speed law 1/tau = A + C (n/1e4)^0.8 (turbulent rotating-disc heat transfer plus a
    speed-independent part); lt[3:5] = log A, log C."""
    return 1/(np.exp(lt[3]) + np.exp(lt[4])*(np.abs(n)/1e4)**0.8)


def thermal_fit(lt):
    """Unknowns lt = log tau_ring, log tau_land, windage W (K at 12500 rpm), log A, log C of the disc speed law. Land and disc
    follow the gas temperature plus the windage excess W (n/12500)^2. Columns: ring lag, land lag and disc lag of their drives,
    centrifugal correction (n/1e4)^2 and a constant correction of the rub opening (both refine the steady block calibration
    with the transient records, which were all taken after the rub). The disc lag uses the time constant of the current speed."""
    t_ring, t_land = np.exp(lt[:2]); W = lt[2]
    rows, rhs = [], []
    for k, (t_, Tg_, keep, dc, n_med, n2, s2) in enumerate(samples):
        drive = Tg_ + W*s2; td = disc_tau(lt, samples_n[k])
        if not (t_ring < t_land < td.min()):
            return 1e30, None
        rows.append(np.column_stack([(exp_lag(Tg_, t_, t_ring) - 293.15)[keep], -(exp_lag(drive, t_, t_land) - 293.15)[keep],
                                     -(exp_lag(drive, t_, td) - 293.15)[keep], -n2, np.ones_like(n2)]))
        rhs.append(dc*1e6)
    A_ = np.vstack(rows); y_ = np.concatenate(rhs)
    coef = np.linalg.lstsq(A_, y_, rcond=None)[0]
    return np.sum((A_@coef - y_)**2), coef


best = None
for a_ in (20, 50):
    for b_ in (60, 120, 250):
        for tA, tC in ((3000, 800), (6000, 500), (1500, 1500)):
            for w_ in (5.0, 20.0):
                x0 = np.r_[np.log([a_, b_]), w_, np.log([1/tA, 1/tC])]
                r_ = minimize(lambda x: thermal_fit(x)[0], x0, method='Nelder-Mead', options={'maxiter': 4000, 'xatol': 1e-4, 'fatol': 1e-6})
                if best is None or r_.fun < best.fun: best = r_
_, (g_ring, g_land, g_disc, d_cf, d_open) = thermal_fit(best.x)
tau_ring, tau_land = np.exp(best.x[:2]); W = best.x[2]; A_, C_ = np.exp(best.x[3:5])
print('centrifugal correction', round(d_cf, 2), 'um; opening correction', round(d_open, 2), 'um; ring', round(g_ring, 3), 'um/K tau', round(tau_ring, 1), 's; land', round(g_land, 3), 'um/K tau',
      round(tau_land, 1), 's; disc', round(g_disc, 3), 'um/K, tau at 3000/6000/9000/12500 rpm',
      [round(float(disc_tau(best.x, n)), 1) for n in (3000, 6000, 9000, 12500)], '; windage', round(W, 2), 'K at 12500 rpm')
su = info['start_up_target']; ts = np.arange(0, max(su['report_times_s']) + 1, 1.0)
ns = su['speed_rpm']['end']*np.clip(ts/su['speed_rpm']['ramp_s'], 0, 1) + su['speed_rpm']['start']*(1 - np.clip(ts/su['speed_rpm']['ramp_s'], 0, 1))
Tgs = su['inlet_temperature_K']['start'] + (su['inlet_temperature_K']['end'] - su['inlet_temperature_K']['start'])*np.clip(ts/su['inlet_temperature_K']['ramp_s'], 0, 1)
tau_s = 1/(A_ + C_*(ns/1e4)**0.8); drv = Tgs + W*(ns/12500.0)**2
cs = (c_cold + (opening + d_open)*1e-6 - (cf + d_cf)*1e-6*(ns/1e4)**2 + g_ring*1e-6*(exp_lag(Tgs, ts, tau_ring) - 293.15)
      - g_land*1e-6*(exp_lag(drv, ts, tau_land) - 293.15) - g_disc*1e-6*(exp_lag(drv, ts, tau_s) - 293.15))
res = {f't{tt}': float(1e3*flow(su['upstream_absolute_kPa']*1e3, su['downstream_absolute_kPa']*1e3, Tgs[tt], cs[tt], cd, fac))
       for tt in su['report_times_s']}
print({k: round(v, 3) for k, v in res.items()})
json.dump({'leakage_g_per_s': res}, open(of, 'w'), indent=2)
