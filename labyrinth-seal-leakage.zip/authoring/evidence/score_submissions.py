"""Calibrates the 1.5 % bound with the real checks.

For the shipped data (seed 0) and regenerated campaigns (LAB_SEED = 1..), every submitter writes results.json in its own
folder: solution/solve.sh, blockwise_reduction.py and each route of alternatives.py. tests/leakage_checks.py, unchanged, is
placed next to that campaign's expected.json and run with pytest and the CTRF plugin as tests/test.sh runs it; reward.txt and
ctrf.json stay in the folder. One line per submission: reward, tests passed, largest relative error.

    python score_submissions.py <work_dir> <seed> [<seed> ...]

With SCORE_ONLY=1 nothing is regenerated or re-solved: the submissions already in <work_dir> are scored with the current
check file (used for the summary; the routes far from the bound were run on the shipped data only).
"""
import json, os, shutil, subprocess, sys
top = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
ev = os.path.join(top, 'authoring', 'evidence'); py = sys.executable; work = os.path.abspath(sys.argv[1])
only = os.environ.get('SCORE_ONLY') == '1'
for seed in sys.argv[2:]:
    w = os.path.join(work, f'seed{seed}'); t = os.path.join(w, 'tests'); os.makedirs(t, exist_ok=True)
    if only: pass
    elif seed == '0':
        data = os.path.join(top, 'environment', 'data'); shutil.copy(os.path.join(top, 'tests', 'expected.json'), t)
    else:
        data = os.path.join(w, 'data')
        subprocess.run([py, os.path.join(top, 'authoring', 'provenance', 'generate.py'), data, t], check=True, env={**os.environ, 'LAB_SEED': seed})
    shutil.copy(os.path.join(top, 'tests', 'leakage_checks.py'), t)
    subs = {'reference': os.path.join(w, 'reference'), 'blockwise_independent': os.path.join(w, 'blockwise_independent')}
    for f in subs.values(): os.makedirs(f, exist_ok=True)
    if not only: subprocess.run(['bash', os.path.join(top, 'solution', 'solve.sh')], check=True, stdout=subprocess.DEVNULL,
                   env={**os.environ, 'DATA_DIR': data, 'OUT_DIR': subs['reference']})
    if not only: subprocess.run([py, os.path.join(ev, 'blockwise_reduction.py'), data, os.path.join(subs['blockwise_independent'], 'results.json')],
                   check=True, stdout=subprocess.DEVNULL)
    if not only: subprocess.run([py, os.path.join(ev, 'alternatives.py'), data, os.path.join(w, 'alternatives')], check=True)
    for n in sorted(os.listdir(os.path.join(w, 'alternatives'))):
        subs[n] = os.path.join(w, 'alternatives', n)
    truth = json.load(open(os.path.join(t, 'expected.json')))['leakage_g_per_s']
    for name, f in subs.items():
        if not os.path.isfile(os.path.join(f, 'results.json')): continue
        r = subprocess.run([py, '-m', 'pytest', os.path.join(t, 'leakage_checks.py'), '-q', '-p', 'no:cacheprovider', '--rootdir', t,
                            '-c', os.devnull, '-p', 'ctrf', '--ctrf', os.path.join(f, 'ctrf.json')], capture_output=True, text=True,
                           env={**os.environ, 'RESULTS_PATH': os.path.join(f, 'results.json'), 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'})
        reward = int(r.returncode == 0); open(os.path.join(f, 'reward.txt'), 'w').write(f'{reward}\n')
        sm = json.load(open(os.path.join(f, 'ctrf.json')))['results']['summary']
        got = json.load(open(os.path.join(f, 'results.json')))['leakage_g_per_s']
        e = max(abs(got[k]/truth[k] - 1) for k in truth)
        print(f'[seed {seed}] {name:36s} reward {reward}   tests {sm["passed"]}/{sm["tests"]}   largest error {100*e:6.1f} %   ({e/0.015:5.2f} x the 1.5 % bound)', flush=True)
