"""Other reductions of the seal campaign: a defensible alternative (Vermes carry-over) and shortcuts that a quick analysis
could take (one rotor time constant, a speed-independent disc time constant, a pure power law, quasi-steady clearance, an
instantaneous ring, rub ignored, reading errors). Each
writes a complete submission <out_dir>/<name>/results.json for score_submissions.py to grade with the shipped checks.

    python alternatives.py <data_dir> <out_dir>
"""
import json, os
import numpy as np
from scipy.optimize import brentq, least_squares
from scipy.interpolate import RegularGridInterpolator
from scipy.signal import lfilter

import sys
DATA, OUTROOT = sys.argv[1], sys.argv[2]
rig = json.load(open(os.path.join(DATA, 'seal_rig.json'))); S = rig['seal']
N = S['number_of_teeth']; PITCH = S['tooth_pitch_mm']*1e-3; B = S['rotor_radius_at_teeth_mm']*1e-3; C0 = S['radial_clearance_mm']*1e-3
R_AIR, GAM = 287.05, 1.4; RHO_STD = 101325.0/(R_AIR*273.15); RC = (2/(GAM + 1))**(GAM/(GAM - 1))


def phi(r):
    r = max(r, RC); return np.sqrt(2*GAM/(GAM - 1)*(r**(2/GAM) - r**((GAM + 1)/GAM)))


PMAX, PEPS = phi(RC), phi(1 - 1e-12)


def phi_seal(rN, mu):
    """Dimensionless mass flow m sqrt(R T) / (Cd A p0) of the N-tooth seal at pressure ratio rN = pN/p0."""
    mus = [1.0] + [mu]*(N - 1)
    def endp(m):
        p = 1.0
        for mm in mus:
            need = m/(mm*p)
            if need >= PMAX: return None
            p *= 1.0 if need <= PEPS else brentq(lambda r: phi(r) - need, RC, 1 - 1e-12)
        return p
    lo, hi = 0.0, mus[-1]*PMAX
    for _ in range(60):
        mid = 0.5*(lo + hi)
        if endp(mid) is None: hi = mid
        else: lo = mid
    if rN <= endp(lo): return lo
    return brentq(lambda m: endp(m) - rN, 1e-9*lo, lo, xtol=1e-14, rtol=1e-12)


R_GRID = np.linspace(0.08, 0.995, 120); MU_GRID = np.linspace(1.0, 1.8, 33)
TABLE = RegularGridInterpolator((R_GRID, MU_GRID), np.array([[phi_seal(r, m) for m in MU_GRID] for r in R_GRID]))


KIND = {'v': 'hodkinson'}


def mdot(p0, pN, T, c, cd, beta):
    x = c/PITCH
    if KIND['v'] == 'vermes':
        mu = 1/np.sqrt(1 - np.minimum(beta*8.52/((PITCH - 0.3e-3)/c + 7.23), 0.95))
    else:
        mu = 1/np.sqrt(1 - (N - 1)/N*x/(x + beta))
    return cd*2*np.pi*B*c*p0/np.sqrt(R_AIR*T)*TABLE(np.c_[np.clip(pN/p0, R_GRID[0], R_GRID[-1]), np.clip(mu, 1.0, 1.8)])


def lag(Tg, tau):
    e = np.exp(-1.0/tau); g = tau*(1 - e)
    return lfilter([1 - g, g - e], [1.0, -e], Tg, zi=[g*Tg[0]])[0]


def read(fn, gauge_abs=False, stdT=273.15):
    d = np.genfromtxt(os.path.join(DATA, fn), delimiter=',', names=True)
    base = 0.0 if gauge_abs else d['barometer_kPa']
    return d, np.maximum((d['upstream_gauge_kPa'] + base)*1e3, 1.0), np.maximum((d['downstream_gauge_kPa'] + base)*1e3, 1.0), d['flow_slpm']/60e3*101325.0/(R_AIR*stdT)


# q = cd, beta, a, bs, br, kappa, tau_ring, tau_land, tau_disc(10000 rpm), h_axial, delta, windage (K at 12500 rpm)
X0 = [0.7, 0.02, 25.0, 2.0, 1.5, 0.3, 45.0, 120.0, 600.0, 0.2, 20.0, 5.0]
LO = [0.3, 1e-4, -50, -5, -5, 0.0, 5, 20, 50, 0.0, -50, -20]; HI = [1.0, 3.0, 100, 10, 10, 1.0, 400, 2000, 5000, 1.0, 150, 80]
XS = [0.01, 0.005, 2, 0.1, 0.1, 0.05, 5, 20, 50, 0.05, 2, 1]


def run(mode='full', kind='hodkinson', rub=True, gauge_abs=False, stdT=273.15, expo=0.8):
    KIND['v'] = kind
    st, sp0, spN, sm = read(rig['test_file'], gauge_abs, stdT)
    TR = [read(f, gauge_abs, stdT) for f in rig['transient_files'].values()]
    TR = [(d, a[::5], b[::5], m[::5], d['inlet_temperature_K'], d['speed_rpm']) for d, a, b, m in TR]
    if mode == 'quasi_steady': TR = []                         # transient records not used
    rpm_s = st['speed_rpm']; T_s = st['inlet_temperature_K']
    cands = [i for i in range(1, len(rpm_s)) if abs(rpm_s[i] - rpm_s[i-1]) > 500] if rub else [len(sm) + 10**6]
    lo, hi, x0 = list(LO), list(HI), list(X0)
    fixed = {}
    if mode in ('one_rotor_time_constant', 'one_rotor_lag_speed_dependent', 'single_time_constant', 'ring_instant'):
        fixed[5] = 0.0                                          # no separate land: the rotor is one body
    if mode in ('one_rotor_time_constant', 'disc_time_constant_speed_independent', 'single_time_constant', 'ring_instant'):
        fixed[9] = 1.0                                          # disc time constant independent of speed
    if mode == 'pure_power_law': fixed[9] = 0.0                 # 1/tau proportional to n^0.8, no speed-independent part
    if not rub: fixed[10] = 0.0
    if mode == 'windage_ignored': fixed[11] = 0.0             # all speed-squared closing taken as instantaneous centrifugal growth
    if kind == 'vermes': x0[1] = 1.0
    free = [k for k in range(12) if k not in fixed]

    def full(p):
        q = np.array(x0, float); q[free] = p
        for k, v in fixed.items(): q[k] = v
        return q

    def taus(q, n):
        if mode == 'single_time_constant': return np.array([q[8], q[8], q[8]])
        if mode == 'ring_instant': return np.array([1e-3, q[7], q[8]])
        return np.array([q[6], q[7], q[8]/(q[9] + (1 - q[9])*(abs(n)/1e4)**expo)])

    def wind(q, n):
        return q[11]*(np.asarray(n, float)/12500.0)**2

    def metal_const(Tg, tau, w):
        drives = (Tg, Tg + w, Tg + w)
        return np.column_stack([d_ if tt < 0.01 else lag(d_, tt) for d_, tt in zip(drives, tau)])

    def metal_var(t, rpm, Tg, q, sub=8):
        out = np.empty((len(t), 3)); y = np.array([Tg[0], Tg[0] + wind(q, rpm[0]), Tg[0] + wind(q, rpm[0])]); out[0] = y
        for i in range(1, len(t)):
            h = (t[i] - t[i-1])/sub
            for j in range(sub):
                f = (j + 0.5)/sub; g = Tg[i-1] + f*(Tg[i] - Tg[i-1]); n = rpm[i-1] + f*(rpm[i] - rpm[i-1])
                w = wind(q, n); drive = np.array([g, g + w, g + w])
                y = drive + (y - drive)*np.exp(-h/taus(q, n))
            out[i] = y
        return out

    def clear(rpm, M, q, after):
        cd, beta, a, bs, br, kap, ts, tl, tref, hax, delta, wnd = q
        Trot = kap*M[:, 1] + (1 - kap)*M[:, 2]
        return C0 + np.where(after, delta*1e-6, 0.0) - a*1e-6*(rpm/1e4)**2 + bs*1e-6*(M[:, 0] - 293.15) - br*1e-6*(Trot - 293.15)

    def res(p, i0):
        q = full(p); cd, beta = q[0], q[1]; after = np.arange(len(sm)) >= i0
        ws = wind(q, rpm_s)
        out = [mdot(sp0, spN, T_s, clear(rpm_s, np.column_stack([T_s, T_s + ws, T_s + ws]), q, after), cd, beta)/sm - 1]
        for d, p0, pN, m, Tg, n in TR:
            if np.ptp(n) < 500:
                M = metal_const(Tg, taus(q, np.median(n)), wind(q, np.median(n)))[::5]
            else:
                M = metal_var(d['time_s'], n, Tg, q, sub=1)[::5]
            out.append(mdot(p0, pN, Tg[::5], clear(n[::5], M, q, True), cd, beta)/m - 1)
        return np.concatenate(out)
    pl = [lo[k] for k in free]; ph = [hi[k] for k in free]; ps = [XS[k] for k in free]; p0_ = [x0[k] for k in free]
    best = None
    for i0 in cands:
        r = least_squares(res, p0_, args=(i0,), bounds=(pl, ph), x_scale=ps)
        if best is None or r.cost < best[0].cost: best = (r, i0)
    fit, i0 = best
    for tr0 in (300.0, 1500.0):
        x = list(fit.x); x[free.index(8)] = tr0
        r = least_squares(res, x, args=(i0,), bounds=(pl, ph), x_scale=ps)
        if r.cost < fit.cost: fit = r
    q = full(fit.x); print('# rms misfit %.4f %%' % (100*np.sqrt(np.mean(fit.fun**2))), 'tau_disc(12500) %.1f s' % taus(q, 12500.0)[2], flush=True)
    su = rig['start_up_target']; t = np.arange(0, max(su['report_times_s']) + 1, 1.0)
    n = su['speed_rpm']['start'] + (su['speed_rpm']['end'] - su['speed_rpm']['start'])*np.clip(t/su['speed_rpm']['ramp_s'], 0, 1)
    Tg = su['inlet_temperature_K']['start'] + (su['inlet_temperature_K']['end'] - su['inlet_temperature_K']['start'])*np.clip(t/su['inlet_temperature_K']['ramp_s'], 0, 1)
    M = np.column_stack([Tg, Tg + wind(q, n), Tg + wind(q, n)]) if mode == 'quasi_steady' else metal_var(t, n, Tg, q)
    c = clear(n, M, q, True)
    m = mdot(np.full(len(t), su['upstream_absolute_kPa']*1e3), np.full(len(t), su['downstream_absolute_kPa']*1e3), Tg, c, q[0], q[1])
    return {f't{tt}': float(1e3*m[tt]) for tt in su['report_times_s']}


ROUTES = {
    'alt_vermes_carry_over': dict(kind='vermes'),
    'one_rotor_time_constant': dict(mode='one_rotor_time_constant'),
    'one_rotor_lag_speed_dependent': dict(mode='one_rotor_lag_speed_dependent'),
    'disc_time_constant_speed_independent': dict(mode='disc_time_constant_speed_independent'),
    'pure_power_law_disc_heat_transfer': dict(mode='pure_power_law'),
    'quasi_steady_clearance': dict(mode='quasi_steady'),
    'single_thermal_time_constant': dict(mode='single_time_constant'),
    'ring_assumed_instantaneous': dict(mode='ring_instant'),
    'rub_ignored': dict(rub=False),
    'windage_ignored': dict(mode='windage_ignored'),
    'gauge_pressures_taken_as_absolute': dict(gauge_abs=True),
    'standard_state_20C': dict(stdT=293.15),
    'steep_disc_law_exponent_1p75': dict(expo=1.75),
    'hedge_between_disc_laws': 'hedge',
}
only = sys.argv[3:] or list(ROUTES)
for name in only:
    os.makedirs(os.path.join(OUTROOT, name), exist_ok=True)
    if ROUTES[name] == 'hedge':                                  # middle of the Re^0.8 and the steep (n^1.75) disc laws
        a_, b_ = run(), run(expo=1.75); out = {k: 0.5*(a_[k] + b_[k]) for k in a_}
    else:
        out = run(**ROUTES[name])
    print(name, {k: round(v, 2) for k, v in out.items()}, flush=True)
    json.dump({'leakage_g_per_s': out}, open(os.path.join(OUTROOT, name, 'results.json'), 'w'), indent=2)
