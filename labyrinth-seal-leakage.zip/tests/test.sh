#!/usr/bin/env bash
# Writes /logs/verifier/reward.txt: 1 if leakage_checks.py passes completely, 0 otherwise; CTRF via the pytest plugin.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests || exit 0
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest /tests/leakage_checks.py --rootdir=/tests -c /dev/null \
    -p no:cacheprovider -p ctrf --ctrf /logs/verifier/ctrf.json -q && echo 1 > /logs/verifier/reward.txt
exit 0
