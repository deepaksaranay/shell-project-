"""Predicted seal leakage at five instants of the start-up versus the leakage of the simulation that made the data."""
import json
import math
import os
from pathlib import Path

import pytest

OUTPUT = Path(os.environ.get('RESULTS_PATH', '/app/output/results.json'))
TRUE_FLOW = json.loads(Path(__file__).with_name('expected.json').read_text())['leakage_g_per_s']
TARGETS = ('t60', 't200', 't450', 't900', 't2400')
TOL = 0.015


def _no_repeats(items):
    out = {}
    for key, value in items:
        if key in out:
            raise ValueError(f'repeated key {key}')
        out[key] = value
    return out


def _load():
    """Returns (table, None) for a valid file, (None, reason) otherwise; the tests below turn a reason into a failure."""
    if OUTPUT.is_symlink() or not OUTPUT.is_file():
        return None, 'results.json is missing or is a symbolic link'
    try:
        data = json.loads(OUTPUT.read_text(), object_pairs_hook=_no_repeats)
    except ValueError as exc:
        return None, f'results.json is not valid: {exc}'
    if not isinstance(data, dict) or list(data) != ['leakage_g_per_s']:
        return None, 'results.json must be an object with the single key leakage_g_per_s'
    table = data['leakage_g_per_s']
    if not isinstance(table, dict) or sorted(table) != sorted(TARGETS):
        return None, f'leakage_g_per_s must have exactly the keys {list(TARGETS)}'
    return table, None


@pytest.fixture(scope='module')
def loaded():
    return _load()


def test_output_shape(loaded):
    table, why = loaded
    assert why is None, why


def _target_test(name):
    def run(loaded):
        table, why = loaded
        assert why is None, why
        x = table[name]
        assert isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x > 0, \
            f'{name}: leakage must be a finite positive number'
        assert abs(x/TRUE_FLOW[name] - 1) <= TOL, f'{name}: {x:.3f} g/s'
    run.__name__ = f'test_leakage_{name}'
    return run


for _n in TARGETS:
    globals()[f'test_leakage_{_n}'] = _target_test(_n)
