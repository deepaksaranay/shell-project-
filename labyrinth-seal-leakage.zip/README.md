# labyrinth-seal-leakage

A six-tooth see-through labyrinth on a 150 mm-radius rotor was tested with dry air: settled steady points at three speeds, two inlet temperatures and six pressure ratios (with repeat points at rest), followed by four transient records at 1 Hz. Three are gas-temperature steps at constant speed (a rise at 3000 rpm, a fall at 6000 rpm and a rise at 1500 rpm), and one is a speed ramp to 9000 rpm at constant gas temperature. The solver predicts the leakage at five instants of a described engine start-up. The start-up runs at 12500 rpm and heats the gas from 295 K to 390 K. The campaign is simulated (`authoring/provenance/generate.py`), and the answers are that simulation's leakage along the start-up.

## Difficulty

**Who does this work:** secondary-air-system and seal engineers at gas-turbine and compressor manufacturers. They predict leakage during engine transients from seal-rig data, because that is when the running clearance, and with it the cooling-air budget, changes fastest.

**What moves the clearance:**

- The rotor disc grows with speed squared, instantly.
- The thin stator ring, keyed into an aluminium casing, follows the gas temperature within about a minute.
- The rotor carries the seal land on a thin flange at the rim of a 60 mm-thick forged disc. The land follows the gas in about two minutes and the disc body over many minutes, so the rotor growth mixes two metal temperatures.

**Two hidden effects, each needed for the answer:**

1. **Windage heating of the rotor.** At 12500 rpm the seal runs at a tip speed of about 196 m/s, and disc friction heats the rotor metal above the gas: about 18 K when settled at 12500 rpm, growing with speed squared. In the settled steady points this extra rotor growth also scales with speed squared, so it is indistinguishable from centrifugal growth and simply looks like a larger centrifugal coefficient. The difference is timing. Centrifugal growth is instantaneous, while windage heating builds up with the rotor's thermal lag. The only place this shows is the slow drift of the leakage for many minutes after the speed ramp of record TR3, at a gas temperature that does not change. A solver that takes all of the speed-squared closing as centrifugal predicts the clearance closing at once when the start-up reaches speed. It misses by up to 6.8 % (4.5 times the 1.5 % bound): too little leakage at 60 s and too much later on.
2. **Speed-dependent rotor heat transfer.** The disc is heated by convection over its faces, and on a spinning disc the convective coefficient rises with speed (turbulent rotating disc, Nu ∝ Re^0.8, plus a part that does not depend on speed). Its time constant is about 2200 s at 1500 rpm (TR4), 1470 s at 3000 rpm (TR1), 930 s at 6000 rpm (TR2), 700 s at 9000 rpm (the windage drift of TR3) and 550 s at the 12500 rpm of the start-up, beyond all records. The solver has to read the law from the four speeds and extrapolate it. A disc time constant independent of speed misses by up to 8.0 % (5.3 times).

The natural first model gives ring and rotor one constant time constant each. Even with windage allowed, it misses the start-up by up to 8.5 % (5.6 times the bound). Nothing in the files names either effect; only the rotor construction and the records are given.

**Other errors that fail:**

- Settled clearance law at every instant (quasi-steady): up to 21.4 %.
- One time constant for all metal: up to 16.0 %.
- Stator ring assumed instantaneous: up to 7.8 %.
- Gauge pressures taken as absolute: the predictions more than double.
- Flow meter assumed at 20 °C standard state: up to 7.2 % low.

The start-up runs at a pressure ratio of 3 with a choking last tooth, beyond the steady points (up to 2.3), so the flow model must be tooth by tooth and compressible.

**What is not decisive:** the rotor rubbed the teeth on the way to 12500 rpm and opened the cold clearance by 35 µm for good. A fit that ignores the rub still passes, because the transient records were all taken after it. Representing the rotor by one lag with the speed-dependent time constant (no separate land) also passes, and so does a pure Re^0.8 law without the speed-independent part.

**The form of the disc heat-transfer law is decided by the records.** TR4 at 1500 rpm, where the disc is slowest, gives the law four speeds. A much steeper law (1/τ growing with n^1.75) no longer fits all of them: its rms misfit is 0.411 % against 0.397 %. It also extrapolates to a disc time constant of about 205 s at 12500 rpm instead of 550 s, and misses the start-up by 3.4–3.8 %. The mean of the Re^0.8 and n^1.75 answers misses by 1.6–1.9 %, so an answer that hedges between the two laws does not pass.

## Reference solution

`solution/solve.sh` runs `solution/predict_leakage.py` in five steps:

1. Convert the readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute × air density at 0 °C and 101.325 kPa.
2. Model the seal tooth by tooth (discharge coefficient, Hodkinson-type carry-over, choking), tabulated once as a dimensionless flow function.
3. Write the clearance as c0 + δ − a (n/10⁴)² + b_s (T_ring − 293.15) − b_r [κ (T_land − 293.15) + (1 − κ)(T_disc − 293.15)]. Ring, land and disc are first-order lags. Land and disc are driven by the gas temperature plus the windage excess W (n/12500)², and τ_disc(n) = τ_ref / (h_ax + (1 − h_ax)(n/10⁴)^0.8). In settled points the rotor carries the full windage excess.
4. Fit all twelve parameters to the steady and the four transient records together, integrating the speed-ramp record with the speed-dependent time constant.
5. Integrate the metal temperatures along the start-up.

It recovers W = 18.1 K (true 18 K), τ_ref = 637 s (true 650 s), h_ax = 0.095 (true 0.10), a = 24.2 µm (true 24.8 µm) and a 34.6 µm rub before test 25. It runs in about four minutes.

## Verification

`tests/leakage_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `leakage_g_per_s` → `t60`, `t200`, `t450`, `t900`, `t2400`. Malformed output fails every test as a test failure. Each instant then has its own test: a finite positive flow within 1.5 % of the simulated leakage. The tolerance appears in no file the solver sees. Reward is 1 only if all six pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign for seeds 1–5 (new noise and barometer drift) beside the shipped seed 0. It grades complete submissions with the unchanged check file through pytest with the CTRF plugin, as `tests/test.sh` does. Each of the 96 submissions keeps its own `reward.txt` and `ctrf.json`; the summary is in `authoring/evidence/scoring_results.txt`.

**Reward 1 on all six data sets (6/6 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.2–0.6 % (0.14–0.38× the 1.5 % bound) |
| Vermes carry-over relation instead of Hodkinson's, otherwise the reference model (`alternatives.py`) | 0.3–0.5 % (0.19–0.35×) |
| Rub ignored | 0.8–1.0 % (0.56–0.65×) |

**At the bound:**

- One rotor lag with the speed-dependent time constant (no separate land): 1.1–1.5 % (0.72–1.01×), reward on 5 of 6 data sets.
- A pure Re^0.8 law without the speed-independent part: 1.4–1.7 % (0.94–1.13×), reward on 2 of 6.
- `authoring/evidence/blockwise_reduction.py`, an independent reduction with no shared code: 0.4–2.2 % (0.26–1.47×), reward on 1 of 6. It uses Vermes carry-over, freezes a block-by-block steady calibration, inverts the transient flows into an effective clearance and fits ring, land and disc lags with a windage drive and a 1/τ = A + C n^0.8 disc law. Because the steady calibration is frozen before the transient fit, it does not reach the 1.5 % bound.

The bound is set by the full simultaneous reductions, which stay at or below 0.6 %. It has to be tighter than half the gap between the disc laws.

**Reward 0 on all six data sets (same file, `authoring/evidence/alternatives.py`):**

| Route | Tests passed | Largest error |
|---|---|---|
| Mean of the Re^0.8 and n^1.75 answers (hedging between disc laws) | 4–5/6 | 1.6–1.9 % (1.08–1.26×) |
| Steeper disc law, 1/τ growing with n^1.75 | 3/6 | 3.4–3.8 % (2.3–2.5×) |
| Windage heating ignored (all speed-squared closing instantaneous) | 2/6 | 6.5–6.8 % (4.3–4.5×) |
| 20 °C standard state | 1/6 | 6.8–7.2 % (4.5–4.8×) |
| Ring assumed instantaneous | 2–3/6 | 7.6–7.8 % (5.1–5.2×) |
| Disc time constant independent of speed | 2–3/6 | 7.8–8.0 % (5.2–5.3×) |
| One constant rotor time constant | 2/6 | 8.3–8.5 % (5.6×) |
| One thermal time constant for all metal | 1/6 | 15.2–16.0 % (10.2–10.7×) |
| Quasi-steady clearance | 2/6 | 20.7–21.4 % (13.8–14.3×) |
| Gauge pressures taken as absolute | 1/6 | 169 % (113×) |

**Trivial answers and the instances they pass:** reward needs all five instants, and no constant passes more than one, so no constant answer earns the reward. Checked against `tests/expected.json`:

| Trivial answer | Value (g/s) | Instances passed |
|---|---|---|
| Zero | 0 | none |
| Mean of the five true leakages | 138.0 | `t900` |
| Their median | 136.2 | `t900` |
| Quasi-steady leakage at 60 s (all metal settled) | 108.0 | none |
| Fully settled hot leakage (390 K, 12500 rpm) | 124.8 | `t2400` |
| Best constants | 117.2–120.8, 123.7–127.4, 134.1–138.2, 149.1–153.6 or 155.5–160.2 | one instant each |

Zero or negative flows are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver therefore cannot reproduce the noise sequence and subtract it to get noiseless records. Only the physics reduction recovers the answer.

The hidden generator values (discharge coefficient, effective expansion coefficients, ring, land and disc time constants, speed-independent share of the disc heat transfer, land share of the rotor growth, windage excess, rub, quasi-steady comparison) are in `authoring/evidence/generator_truth.json`.
