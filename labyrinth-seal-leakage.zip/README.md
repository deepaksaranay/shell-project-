# labyrinth-seal-leakage

A six-tooth see-through labyrinth on a 150 mm-radius rotor was tested on a rig with dry air at about 2 bar: settled steady points at three speeds, two inlet temperatures and six pressure ratios (with repeat points at rest), followed by three transient records at 1 Hz. Two are gas-temperature steps at constant speed (a rise at 3000 rpm and a fall at 6000 rpm), and one is a speed ramp to 9000 rpm at constant gas temperature. The solver predicts the leakage at five instants of a start-up of the same seal **in the engine**: 12500 rpm, gas heating from 295 K to 390 K, and an upstream pressure of 12.2 bar, about six times the rig's. The campaign is simulated (`authoring/provenance/generate.py`), and the answers are that simulation's leakage along the start-up.

## Difficulty

**Who does this work:** secondary-air-system and seal engineers at gas-turbine and compressor manufacturers. They predict leakage during engine transients from seal-rig data, because that is when the running clearance, and with it the cooling-air budget, changes fastest. The rig does not run at engine pressure, so what they carry over to the engine has to be the physics, not the fitted numbers.

**What moves the clearance:**

- The rotor disc grows with speed squared, instantly.
- The thin stator ring, keyed into an aluminium casing, follows the gas temperature within about a minute.
- The rotor carries the seal land on a thin flange at the rim of a 60 mm-thick forged disc. The land follows the gas in about two minutes and the disc body over many minutes, so the rotor growth mixes two metal temperatures.

**Three things decide the answer. None is named as an effect in the files.**

1. **Windage heating of the rotor.** At 12500 rpm disc friction heats the rotor metal about 18 K above the gas, growing with speed squared. In the settled steady points this extra growth scales with speed squared like the centrifugal growth and is indistinguishable from it. Only its lag shows, as the slow drift of the leakage after the speed ramp of TR3 at constant gas temperature. Taking all of the speed-squared closing as centrifugal misses the start-up by 5.7 % (2.9 times the 2 % bound).
2. **The disc time constant depends on the Reynolds number, not on speed alone.** The disc faces are swept by the air upstream of the seal (the rotor description says so, and says the flow is turbulent), and convection on a rotating disc in turbulent flow goes with Nu ∝ Re^0.8, with Re = ρ ω b² / μ. The time constant therefore depends on the gas density (pressure over temperature) as well as on speed, and on the viscosity of the air. On the rig it is 2040 s at 3000 rpm (TR1), 880 s at 6000 rpm (TR2) and 840 s at 9000 rpm (TR3). In the engine start-up, at 12500 rpm, 12.2 bar and 390 K, it is **169 s**, where the same speed at rig pressure would give 544 s. The Reynolds number is 5.4 times the rig's reference state and 4.3 times the rig's at the same speed.
3. **The start-up is at engine pressure.** The solver has to carry the fitted heat-transfer law to a state the rig never reached. A disc law written in speed only, which is all the rig records can distinguish at first sight, gives the disc 562 s at the end of the start-up instead of 169 s and misses the start-up by 15.2–15.4 % (7.6–7.7 times the bound) on every data set.

**What the records do and do not show.** The three transients are at upstream pressures of 180, 200 and 160 kPa, so the pressure dependence of the disc is only weakly visible in them. A model that takes the law in speed only fits the records a little worse (rms 0.453 % against 0.399 %), a sign that something besides speed matters, not enough to say what. The physics fixes the form: the standard turbulent rotating-disc correlation with the rotational Reynolds number, using the density and viscosity of the air. The pieces are standard, and a solver that writes the law in Re from the start gets the answer.

**Shortcuts around the physics fail, including the ones that fit the records:**

- The law in speed only: 15.2–15.4 % on every data set (above).
- Re taken as ρ ω with the viscosity held constant: 0.7–1.0 %, within the bound. The viscosity of air changes by 16 % between the rig's reference state and the end of the start-up, but the error is small. This is a defensible simplification and it passes.
- The speed law times a fitted power of the pressure: the records cannot fix the power, and the fit extrapolates to a disc time constant of 6 s at the end of the start-up. It misses by 17.0–17.7 % on every data set.
- A fitted exponent on the Reynolds number instead of the standard 0.8: the fit returns 0.79–1.24 from the six data sets (true 0.8), the extrapolation to a 6 times higher Re moves with it, and the route passes on only one of six data sets (0.3–8.2 %).
- The mean of the speed-only and the Reynolds answers: 7.6–7.8 % on every data set. A hedge does not pass.

**Other errors that fail (shipped data):**

- Settled clearance law at every instant (quasi-steady): 12.0 %.
- Windage ignored: 5.7 % (above).
- Stator ring assumed instantaneous: 17.8 %.
- One time constant for all metal: 19.4 %.
- One constant rotor time constant, or a disc time constant independent of speed: 21–23 %.
- Gauge pressures taken as absolute: the predictions more than double.
- Flow meter assumed at 20 °C standard state: 6.9 % low.

The start-up runs at a pressure ratio of 3 with a choking last tooth, beyond the steady points (up to 2.3), so the flow model must be tooth by tooth and compressible.

**What is not decisive:** the rotor rubbed the teeth on the way to 12500 rpm and opened the cold clearance by 35 µm for good. A fit that ignores the rub misses by 1.2–2.3 % and passes on five of the six data sets, because the transient records were all taken after it. Representing the rotor by one lag with the Reynolds-number law (no separate land) also passes on five of six, and so does a pure Re^0.8 law (the disc heat transfer has no part independent of Re in this campaign).

## Reference solution

`solution/solve.sh` runs `solution/predict_leakage.py` in five steps:

1. Convert the readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute × air density at 0 °C and 101.325 kPa.
2. Model the seal tooth by tooth (discharge coefficient, Hodkinson-type carry-over, choking), tabulated once as a dimensionless flow function.
3. Write the clearance as c0 + δ − a (n/10⁴)² + b_s (T_ring − 293.15) − b_r [κ (T_land − 293.15) + (1 − κ)(T_disc − 293.15)]. Ring, land and disc are first-order lags. Land and disc are driven by the gas temperature plus the windage excess W (n/12500)². The disc time constant is τ_ref / (h_ax + (1 − h_ax) Re^0.8), with the rotational Reynolds number Re = ρ ω b² / μ of the current speed, upstream pressure and gas temperature (ideal-gas density, Sutherland viscosity) relative to a reference state. The disc time constant changes along every record, so the disc response is integrated with the current time constant.
4. Fit all twelve parameters to the steady points and the three transient records together.
5. Integrate the metal temperatures along the start-up at the Reynolds number of the engine pressure, and report the leakage at the requested times.

It recovers W = 17.9 K (true 18 K), τ_ref = 644 s (true 650 s), h_ax = 0.0 (true 0.0), a = 24.0 µm (true 24.8 µm) and a 34.5 µm rub before test 25. It runs in about four minutes.

## Verification

`tests/leakage_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `leakage_g_per_s` → `t60`, `t200`, `t450`, `t900`, `t2400`. Malformed output fails every test as a test failure. Each instant then has its own test: a finite positive flow within 2 % of the simulated leakage. The instruction says that each flow must meet a relative-error requirement; the size of the tolerance appears in no file the solver sees. Reward is 1 only if all six pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign for seeds 1–5 (new noise and barometer drift) beside the shipped seed 0. It grades complete submissions with the unchanged check file through pytest with the CTRF plugin, as `tests/test.sh` does (`SCORE_ONLY=1` rescoring the saved submissions). Each of the 75 submissions keeps its own `reward.txt` and `ctrf.json`; the summary is in `authoring/evidence/scoring_results.txt`. The routes near the bound were run on all six data sets, the routes far from it on the shipped data only.

**Reward 1 on all six data sets (6/6 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.2–0.6 % (0.09–0.28× the 2 % bound) |
| `authoring/evidence/blockwise_reduction.py`, an independent reduction with no shared code: Vermes carry-over, a block-by-block steady calibration, the transient flows inverted into an effective clearance, and ring, land and disc lags with a windage drive and a 1/τ = A + C Re^0.8 law in the Reynolds number | 0.3–1.0 % (0.14–0.52×) |
| Vermes carry-over relation instead of Hodkinson's, otherwise the reference model (`alternatives.py`) | 0.2–0.7 % (0.10–0.33×) |
| A pure Re^0.8 law, otherwise as the reference | 0.2–0.5 % (0.08–0.27×) |
| Re taken as ρ ω with a constant viscosity | 0.7–1.0 % (0.34–0.51×) |

**Passing on five of six data sets:** one rotor lag with the Reynolds-number law (no separate land), 1.5–2.1 %; rub ignored, 1.2–2.3 %.

**Reward 0 on every data set run (same file, `authoring/evidence/alternatives.py`):**

| Route | Data sets | Tests passed | Largest error |
|---|---|---|---|
| Disc law in speed only | 6 | 3/6 | 15.2–15.4 % (7.6–7.7×) |
| Speed law times a fitted power of the pressure | 6 | 3/6 | 17.0–17.7 % (8.5–8.9×) |
| Mean of the speed-only and the Reynolds answers | 6 | 3/6 | 7.6–7.8 % (3.8–3.9×) |
| Fitted Reynolds exponent (passes on one data set) | 6 | 3–6/6 | 0.3–8.2 % (0.2–4.1×) |
| Steeper law, 1/τ growing with Re^1.75 | 1 | 3/6 | 14.8 % (7.4×) |
| Windage heating ignored | 1 | 1/6 | 5.7 % (2.9×) |
| 20 °C standard state | 1 | 1/6 | 6.9 % (3.5×) |
| Quasi-steady clearance | 1 | 3/6 | 12.0 % (6.0×) |
| Ring assumed instantaneous | 1 | 1/6 | 17.8 % (8.9×) |
| One thermal time constant for all metal | 1 | 1/6 | 19.4 % (9.7×) |
| Disc time constant independent of speed | 1 | 2/6 | 21.4 % (10.7×) |
| One constant rotor time constant | 1 | 1/6 | 22.5 % (11.3×) |
| Gauge pressures taken as absolute | 1 | 1/6 | 201 % (101×) |

**Trivial answers and the instances they pass:** reward needs all five instants, and no constant passes more than two, so no constant answer earns the reward. Checked against `tests/expected.json`:

| Trivial answer | Value (g/s) | Instances passed |
|---|---|---|
| Zero | 0 | none |
| Mean of the five true leakages | 511.9 | none |
| Their median | 500.8 | `t900`, `t2400` |
| Quasi-steady leakage at 60 s (all metal settled) | 432.0 | none |
| Fully settled hot leakage (390 K, 12500 rpm) | 499.2 | `t900`, `t2400` |
| Best constants | 457.1–475.8, 557.0–579.8, 514.3–535.3 or 490.8–509.2 | one instant each, or `t900` and `t2400` |

Zero or negative flows are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver therefore cannot reproduce the noise sequence and subtract it to get noiseless records. Only the physics reduction recovers the answer.

The hidden generator values (discharge coefficient, effective expansion coefficients, ring, land and disc time constants at the reference state and in the start-up, windage excess, rub, quasi-steady comparison) are in `authoring/evidence/generator_truth.json`.
