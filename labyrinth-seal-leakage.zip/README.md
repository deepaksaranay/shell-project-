# labyrinth-seal-leakage

A six-tooth see-through labyrinth on a 150 mm-radius rotor was tested with dry air: settled steady points at three speeds, two inlet temperatures and six pressure ratios (with repeat points at rest), followed by four transient records at 1 Hz, in the order TR1 to TR4. Three are gas-temperature steps at constant speed (a rise at 3000 rpm, a fall at 6000 rpm and a rise at 1500 rpm), and one is a speed ramp to 9000 rpm at constant gas temperature. The solver predicts the leakage at five instants of a described engine start-up. The start-up runs at 12500 rpm and heats the gas from 295 K to 390 K. The campaign is simulated (`authoring/provenance/generate.py`), and the answers are that simulation's leakage along the start-up.

## Difficulty

**Who does this work:** secondary-air-system and seal engineers at gas-turbine and compressor manufacturers. They predict leakage during engine transients from seal-rig data, because that is when the running clearance, and with it the cooling-air budget, changes fastest.

**What moves the clearance:**

- The rotor disc grows with speed squared, instantly.
- The thin stator ring, keyed into an aluminium casing, follows the gas temperature within about a minute.
- The rotor carries the seal land on a thin flange at the rim of a 60 mm-thick forged disc. The land follows the gas in about two minutes and the disc body over many minutes, so the rotor growth mixes two metal temperatures.

**Four hidden effects, each needed for the answer (the files name none of them as an effect):**

1. **The flow meter is slow.** The thermal mass-flow meter answers a change of flow with a first-order lag of about 20 s. The settled steady points do not show it. In the 1 Hz records it delays every fast change: the density step when the gas temperature changes, and the centrifugal closing during the speed ramp. A solver that reads the meter as the instantaneous flow still fits the records closely (rms 0.46 % against 0.39 %), but it puts the delay into the metal: the ring and land time constants come out too long, and the start-up misses by 3.4–3.9 % (1.7–1.9 times the 2 % bound).
2. **A second rub during TR3.** The run log says that TR3 passed the first critical speed near 7000 rpm on its run-up and that the vibration monitor alarmed. From that instant the clearance is 25 µm larger: the leakage in TR3 stops falling and rises while the speed is still rising, and TR4 sits above the steady calibration by the same amount. The start-up is asked for the seal in the condition the campaign left it in, so it carries both openings. The repeat points at rest were taken before the transients and show only the first rub (35 µm). A solver that takes the opening from the repeat points misses by 11.0–12.3 % (5.5–6.1 times). A solver that fits one common opening to all four transient records misses by 8.1–11.6 %, and its fit is poor (rms 2.6 %), which is the signal that something happened inside the records.
3. **Windage heating of the rotor.** At 12500 rpm disc friction heats the rotor metal above the gas: about 18 K when settled, growing with speed squared. In the settled steady points this extra rotor growth is indistinguishable from centrifugal growth. The difference is timing: centrifugal growth is instantaneous, while windage heating builds up with the rotor's thermal lag, and shows only as the slow drift after the speed ramp of TR3. Taking all of the speed-squared closing as centrifugal misses by 13.9 %.
4. **Speed-dependent rotor heat transfer.** The disc is heated by convection over its faces, and the convective coefficient rises with speed (turbulent rotating disc, Nu ∝ Re^0.8, plus a part that does not depend on speed). Its time constant is about 2200 s at 1500 rpm (TR4), 1470 s at 3000 rpm (TR1), 930 s at 6000 rpm (TR2), 700 s at 9000 rpm (TR3) and 550 s at the 12500 rpm of the start-up, beyond all records. The solver has to read the law from the four speeds and extrapolate it. A disc time constant independent of speed misses by 7.2 %.

The four interact. The meter lag has to be separated from the ring lag (45 s) and the land lag (110 s). The second rub falls inside the speed ramp that is also the only evidence for the windage. Ignoring both the meter lag and the second rub misses by 9.1 %.

**Other errors that fail (shipped data):**

- Settled clearance law at every instant (quasi-steady): 23.0 %.
- One time constant for all metal: 14.9 %.
- One constant rotor time constant: 7.5 %.
- Stator ring assumed instantaneous: 7.4 %.
- Gauge pressures taken as absolute: the predictions more than double.
- Flow meter assumed at 20 °C standard state: 7.0 %.

The start-up runs at a pressure ratio of 3 with a choking last tooth, beyond the steady points (up to 2.3), so the flow model must be tooth by tooth and compressible.

**The first rub matters less.** The rotor rubbed the teeth on the way to 12500 rpm and opened the cold clearance by 35 µm. A fit that ignores it misses by 1.2–3.6 % and fails on the shipped data, but passes on the five regenerated data sets, because the transient records were all taken after it. Representing the rotor by one lag with the speed-dependent time constant (no separate land) passes.

**The form of the disc heat-transfer law is decided by the records.** TR4 at 1500 rpm, where the disc is slowest, gives the law four speeds. A much steeper law (1/τ growing with n^1.75) extrapolates to a disc time constant of about 320 s at 12500 rpm instead of 550 s, and misses the start-up by 5.6 %. The mean of the Re^0.8 and n^1.75 answers misses by 2.5–2.9 %, so an answer that hedges between the two laws does not pass.

## Reference solution

`solution/solve.sh` runs `solution/predict_leakage.py` in five steps:

1. Convert the readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute × air density at 0 °C and 101.325 kPa.
2. Model the seal tooth by tooth (discharge coefficient, Hodkinson-type carry-over, choking), tabulated once as a dimensionless flow function.
3. Write the clearance as c0 + δ + δ2 − a (n/10⁴)² + b_s (T_ring − 293.15) − b_r [κ (T_land − 293.15) + (1 − κ)(T_disc − 293.15)]. Ring, land and disc are first-order lags. Land and disc are driven by the gas temperature plus the windage excess W (n/12500)², and τ_disc(n) = τ_ref / (h_ax + (1 − h_ax)(n/10⁴)^0.8). δ is the first rub. δ2 applies from the sample where TR3 reaches the critical speed, in TR4 and in the start-up.
4. Pass the model flow of every 1 Hz record through a first-order meter lag, and fit all fourteen parameters to the steady points and the four transient records together.
5. Integrate the metal temperatures along the start-up, with both openings, and report the true (unlagged) leakage.

It recovers the meter time constant (21.2 s, true 20 s), the second opening (24.9 µm, true 25 µm), the first rub (34.6 µm, true 35 µm, before test 25), W = 17.7 K (true 18 K), τ_ref = 638 s (true 650 s) and h_ax = 0.099 (true 0.10). The fit rms is 0.39 %, the meter noise. It runs in about four minutes.

## Verification

`tests/leakage_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `leakage_g_per_s` → `t60`, `t200`, `t450`, `t900`, `t2400`. Malformed output fails every test as a test failure. Each instant then has its own test: a finite positive flow within 2 % of the simulated leakage. The instruction says that each flow must meet a relative-error requirement; the size of the tolerance appears in no file the solver sees. Reward is 1 only if all six pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign for seeds 1–5 (new noise and barometer drift) beside the shipped seed 0. It grades complete submissions with the unchanged check file through pytest with the CTRF plugin, as `tests/test.sh` does. Each of the 70 submissions keeps its own `reward.txt` and `ctrf.json`; the summary is in `authoring/evidence/scoring_results.txt` (`SCORE_ONLY=1` rescoring the saved submissions). The routes near the bound and the new shortcuts were run on all six data sets, the routes far from the bound on the shipped data only.

**Reward 1 on all six data sets (6/6 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.1–0.9 % (0.05–0.44× the 2 % bound) |
| `authoring/evidence/blockwise_reduction.py`, an independent reduction with no shared code: Vermes carry-over, a block-by-block steady calibration, the transient flows inverted into an effective clearance, the meter lag applied in clearance space with its own time constant, the second rub as an offset after the critical speed, and ring, land and disc lags with a windage drive and a 1/τ = A + C n^0.8 disc law | 0.5–1.5 % (0.23–0.74×) |
| Vermes carry-over relation instead of Hodkinson's, otherwise the reference model (`alternatives.py`) | 0.4–1.6 % (0.20–0.81×) |
| One rotor lag with the speed-dependent time constant (no separate land) | 0.2–0.5 % (0.12–0.24×) |

The 2 % bound is set by the Vermes reduction, a defensible flow model that reaches 1.6 %. The nearest wrong route is at 2.5 %.

**Passing on some data sets only:**

- A pure Re^0.8 law without the speed-independent part: 1.0–2.4 %, reward on 4 of 6.
- First rub ignored: 1.2–3.6 %, reward on 5 of 6 (not on the shipped data).

**Reward 0 on every data set run (same file, `authoring/evidence/alternatives.py`):**

| Route | Data sets | Tests passed | Largest error |
|---|---|---|---|
| Mean of the Re^0.8 and n^1.75 answers (hedging between disc laws) | 6 | 4/6 | 2.5–2.9 % (1.3–1.4×) |
| Flow-meter lag ignored | 6 | 4–5/6 | 3.4–3.9 % (1.7–1.9×) |
| Second rub ignored (opening from the repeat points) | 6 | 1–2/6 | 11.0–12.3 % (5.5–6.1×) |
| One opening fitted to all transient records | 6 | 1/6 | 8.1–11.6 % (4.1–5.8×) |
| Meter lag and second rub both ignored | 1 | 1/6 | 9.1 % (4.6×) |
| Steeper disc law, 1/τ growing with n^1.75 | 1 | 3/6 | 5.6 % (2.8×) |
| 20 °C standard state | 1 | 1/6 | 7.0 % (3.5×) |
| Disc time constant independent of speed | 1 | 1/6 | 7.2 % (3.6×) |
| Ring assumed instantaneous | 1 | 1/6 | 7.4 % (3.7×) |
| One constant rotor time constant | 1 | 1/6 | 7.5 % (3.7×) |
| Windage heating ignored (all speed-squared closing instantaneous) | 1 | 4/6 | 13.9 % (7.0×) |
| One thermal time constant for all metal | 1 | 1/6 | 14.9 % (7.5×) |
| Quasi-steady clearance | 1 | 1/6 | 23.0 % (11.5×) |
| Gauge pressures taken as absolute | 1 | 1/6 | 168 % (84×) |

**Trivial answers and the instances they pass:** reward needs all five instants, and no constant passes more than one, so no constant answer earns the reward. Checked against `tests/expected.json`:

| Trivial answer | Value (g/s) | Instances passed |
|---|---|---|
| Zero | 0 | none |
| Mean of the five true leakages | 147.5 | `t900` |
| Their median | 145.5 | `t900` |
| Quasi-steady leakage at 60 s (all metal settled) | 118.0 | none |
| Fully settled hot leakage (390 K, 12500 rpm) | 134.1 | `t2400` |
| Best constants | 126.5–131.7, 132.2–137.6, 142.6–148.5, 157.5–163.9 or 163.9–170.6 | one instant each |

Zero or negative flows are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver therefore cannot reproduce the noise sequence and subtract it to get noiseless records. Only the physics reduction recovers the answer.

The hidden generator values (discharge coefficient, effective expansion coefficients, ring, land and disc time constants, speed-independent share of the disc heat transfer, land share of the rotor growth, windage excess, both rub openings, the meter time constant, quasi-steady comparison) are in `authoring/evidence/generator_truth.json`.
