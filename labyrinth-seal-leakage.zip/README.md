# labyrinth-seal-leakage

A six-tooth see-through labyrinth on a 150 mm-radius rotor was tested with dry air: settled steady points at three speeds, two inlet temperatures and six pressure ratios (with repeat points at rest), followed by three transient records at 1 Hz. Two are gas-temperature steps at constant speed (a rise at 3000 rpm and a fall at 6000 rpm), and one is a speed ramp to 9000 rpm at constant gas temperature. The solver predicts the leakage at five instants of a described engine start-up. The start-up runs at 12500 rpm and heats the gas from 295 K to 390 K. The campaign is simulated (`authoring/provenance/generate.py`), and the answers are that simulation's leakage along the start-up.

## Difficulty

**Who does this work:** secondary-air-system and seal engineers at gas-turbine and compressor manufacturers. They predict leakage during engine transients from seal-rig data, because that is when the running clearance, and with it the cooling-air budget, changes fastest.

**What moves the clearance:**

- The rotor disc grows with speed squared, instantly.
- The thin stator ring, keyed into an aluminium casing, follows the gas temperature within about a minute.
- The rotor carries the seal land on a thin flange at the rim of a 60 mm-thick forged disc. The land follows the gas in about two minutes and the disc body over many minutes, so the rotor growth mixes two metal temperatures.

**Two hidden effects, each needed for the answer:**

1. **Windage heating of the rotor.** At 12500 rpm the seal runs at a tip speed of about 196 m/s, and disc friction heats the rotor metal above the gas: about 18 K when settled at 12500 rpm, growing with speed squared. In the settled steady points this extra rotor growth also scales with speed squared, so it is indistinguishable from centrifugal growth and simply looks like a larger centrifugal coefficient. The difference is timing. Centrifugal growth is instantaneous, while windage heating builds up with the rotor's thermal lag. The only place this shows is the slow drift of the leakage for many minutes after the speed ramp of record TR3, at a gas temperature that does not change. A solver that takes all of the speed-squared closing as centrifugal predicts the clearance closing at once when the start-up reaches speed. It misses by 6.9 % (4.6 times the 1.5 % bound): too little leakage at 60 s and too much later on.
2. **Speed-dependent rotor heat transfer.** The disc is heated by convection over its faces, and on a spinning disc the convective coefficient rises with speed (turbulent rotating disc, Nu ∝ Re^0.8, plus a part that does not depend on speed). Its time constant is about 1470 s at 3000 rpm (TR1), 930 s at 6000 rpm (TR2), 700 s at 9000 rpm (the windage drift of TR3) and 550 s at the 12500 rpm of the start-up, beyond all records. The solver has to read the law from the three speeds and extrapolate it. A disc time constant independent of speed misses by 8.0 % (5.3 times).

The natural first model gives ring and rotor one constant time constant each. Even with windage allowed, it misses the start-up by 8.3 % (5.5 times the bound). Nothing in the files names either effect; only the rotor construction and the records are given.

**Other errors that fail:**

- Settled clearance law at every instant (quasi-steady): 20.8 %.
- One time constant for all metal: 17.7 %.
- Stator ring assumed instantaneous: 7.7 %.
- Gauge pressures taken as absolute: the predictions more than double.
- Flow meter assumed at 20 °C standard state: 6.9 %.

The start-up runs at a pressure ratio of 3 with a choking last tooth, beyond the steady points (up to 2.3), so the flow model must be tooth by tooth and compressible.

**What is not decisive:** the rotor rubbed the teeth on the way to 12500 rpm and opened the cold clearance by 35 µm for good. A fit that ignores the rub misses by 1.2–1.5 % and passes on five of the six data sets, because the transient records were all taken after it. Representing the rotor by one lag with the speed-dependent time constant (no separate land) also passes, and so does a pure Re^0.8 law without the speed-independent part.

**The form of the disc heat-transfer law has to come from the physics, and hedging does not pass.** The records give the disc time constant at three speeds, and the start-up runs beyond them. A much steeper law (1/τ growing with n^1.75) fits the three speeds as well as the turbulent rotating-disc law (rms misfit 0.399 % against 0.40 %), but it extrapolates to a disc time constant of about 395 s at 12500 rpm instead of 550 s and misses the start-up by 3.2–3.6 %. The law is not a free choice: heat transfer on a rotating disc in turbulent flow goes with Re^0.8, the standard result for this geometry, and both forms of it pass (with and without a speed-independent part). The mean of the Re^0.8 and n^1.75 answers misses by 1.6–1.9 % and fails on all six data sets, so an answer that hedges between the two laws does not pass.

## Reference solution

`solution/solve.sh` runs `solution/predict_leakage.py` in five steps:

1. Convert the readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute × air density at 0 °C and 101.325 kPa.
2. Model the seal tooth by tooth (discharge coefficient, Hodkinson-type carry-over, choking), tabulated once as a dimensionless flow function.
3. Write the clearance as c0 + δ − a (n/10⁴)² + b_s (T_ring − 293.15) − b_r [κ (T_land − 293.15) + (1 − κ)(T_disc − 293.15)]. Ring, land and disc are first-order lags. Land and disc are driven by the gas temperature plus the windage excess W (n/12500)², and τ_disc(n) = τ_ref / (h_ax + (1 − h_ax)(n/10⁴)^0.8). In settled points the rotor carries the full windage excess.
4. Fit all twelve parameters to the steady and the three transient records together, integrating the speed-ramp record with the speed-dependent time constant.
5. Integrate the metal temperatures along the start-up.

It recovers W = 18.2 K (true 18 K), τ_ref = 634 s (true 650 s), h_ax = 0.086 (true 0.10), a = 24.0 µm (true 24.8 µm) and a 34.5 µm rub before test 25. It runs in about four minutes.

## Verification

`tests/leakage_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `leakage_g_per_s` → `t60`, `t200`, `t450`, `t900`, `t2400`. Malformed output fails every test as a test failure. Each instant then has its own test: a finite positive flow within 1.5 % of the simulated leakage. The instruction says that each flow must meet a relative-error requirement; the size of the tolerance appears in no file the solver sees. Reward is 1 only if all six pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign for seeds 1–5 (new noise and barometer drift) beside the shipped seed 0. It grades complete submissions with the unchanged check file through pytest with the CTRF plugin, as `tests/test.sh` does. Each of the 56 submissions keeps its own `reward.txt` and `ctrf.json`; the summary is in `authoring/evidence/scoring_results.txt` (`SCORE_ONLY=1` rescoring the saved submissions). The routes near the bound were run on all six data sets, the routes far from it on the shipped data only.

**Reward 1 on all six data sets (6/6 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.2–0.8 % (0.10–0.53× the 1.5 % bound) |
| `authoring/evidence/blockwise_reduction.py`, an independent reduction with no shared code: Vermes carry-over, a block-by-block steady calibration, the transient flows inverted into an effective clearance, and ring, land and disc lags with a windage drive and a 1/τ = A + C n^0.8 disc law | 0.3–1.1 % (0.18–0.72×) |
| Vermes carry-over relation instead of Hodkinson's, otherwise the reference model (`alternatives.py`) | 0.3–0.6 % (0.18–0.42×) |
| One rotor lag with the speed-dependent time constant (no separate land) | 0.9–1.3 % (0.62–0.89×) |
| A pure Re^0.8 law without the speed-independent part | 1.0–1.2 % (0.64–0.80×) |

The bound has to be tighter than half the gap between the disc laws (1.6 %), and it leaves every correct-physics reduction a margin: the largest of them reaches 1.3 %.

**Passing on some data sets only:** rub ignored, 1.2–1.5 %, reward on 5 of 6.

**Reward 0 on every data set run (same file, `authoring/evidence/alternatives.py`):**

| Route | Data sets | Tests passed | Largest error |
|---|---|---|---|
| Mean of the Re^0.8 and n^1.75 answers (hedging between disc laws) | 6 | 4–5/6 | 1.6–1.9 % (1.05–1.24×) |
| Steeper disc law, 1/τ growing with n^1.75 | 6 | 3–4/6 | 3.2–3.6 % (2.1–2.4×) |
| Windage heating ignored (all speed-squared closing instantaneous) | 1 | 1/6 | 6.9 % (4.6×) |
| 20 °C standard state | 1 | 1/6 | 6.9 % (4.6×) |
| Ring assumed instantaneous | 1 | 1/6 | 7.7 % (5.1×) |
| Disc time constant independent of speed | 1 | 3/6 | 8.0 % (5.3×) |
| One constant rotor time constant | 1 | 2/6 | 8.3 % (5.5×) |
| One thermal time constant for all metal | 1 | 1/6 | 17.7 % (11.8×) |
| Quasi-steady clearance | 1 | 2/6 | 20.8 % (13.9×) |
| Gauge pressures taken as absolute | 1 | 1/6 | 173 % (115×) |

**Trivial answers and the instances they pass:** reward needs all five instants, and no constant passes more than one, so no constant answer earns the reward. Checked against `tests/expected.json`:

| Trivial answer | Value (g/s) | Instances passed |
|---|---|---|
| Zero | 0 | none |
| Mean of the five true leakages | 138.0 | `t900` |
| Their median | 136.2 | `t900` |
| Quasi-steady leakage at 60 s (all metal settled) | 108.0 | none |
| Fully settled hot leakage (390 K, 12500 rpm) | 124.8 | `t2400` |
| Best constants | 117.2–120.8, 123.7–127.4, 134.1–138.2, 149.1–153.6 or 155.5–160.2 | one instant each |

Zero or negative flows are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver therefore cannot reproduce the noise sequence and subtract it to get noiseless records. Only the physics reduction recovers the answer.

The hidden generator values (discharge coefficient, effective expansion coefficients, ring, land and disc time constants, speed-independent share of the disc heat transfer, land share of the rotor growth, windage excess, rub, quasi-steady comparison) are in `authoring/evidence/generator_truth.json`.
