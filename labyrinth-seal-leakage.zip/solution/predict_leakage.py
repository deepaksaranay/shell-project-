"""Reference solution: labyrinth-seal leakage during an engine start-up, from steady and transient rig records.

1. Readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute x air density at 273.15 K and
   101.325 kPa.
2. Flow model, tooth by tooth: isentropic throttles of area 2 pi b c with one discharge coefficient Cd, a Hodkinson-type
   carry-over factor mu = [1 - (N-1)/N x/(x + beta)]^-1/2 (x = c / pitch) on teeth 2..N, constant gas temperature, choking of
   the last tooth. For speed, m = Cd 2 pi b c p0 / sqrt(R T) * Phi(pN/p0, mu), with Phi tabulated once by the exact
   tooth-by-tooth march and interpolated.
3. Running clearance: c = c0 + delta (after the rub) - a (n/10^4 rpm)^2 + b_s (T_ring - 293.15)
   - b_r [kappa (T_land - 293.15) + (1 - kappa) (T_disc - 293.15)]. The rotor is a thin seal-land flange on a forged disc, so
   its growth follows two metal temperatures. Ring, land and disc temperatures are first-order lags. Land and disc are driven
   by the gas temperature plus a windage excess W (n/12500)^2: disc friction heats the rotor metal, and in settled points
   this extra growth scales with speed squared like the centrifugal growth, so only its lag (the slow drift after the speed
   ramp of TR3) separates the two. The disc is heated by convection whose coefficient grows with speed (turbulent rotating
   disc, Nu ~ Re^0.8) on top of a speed-independent part: tau_disc(n) = tau_ref / (h_ax + (1 - h_ax) (n/10^4 rpm)^0.8).
4. All parameters (Cd, beta, a, b_s, b_r, kappa, tau_s, tau_land, tau_ref, h_ax, delta, W) are fitted to the steady points
   and the transient records together (relative least squares on mass flow); constant-speed records use exact lags, the
   speed ramp is integrated with the speed-dependent time constant; the rub opening starts at the speed change with the
   smallest misfit.
5. The start-up runs at 12500 rpm, beyond the records (1500 to 9000 rpm), so the disc time constant there is the extrapolated
   one; the four speeds fix the form of the law. The metal temperatures are integrated along the start-up and the leakage is reported at the requested times.
"""
import json, os
import numpy as np
from scipy.optimize import brentq, least_squares
from scipy.interpolate import RegularGridInterpolator
from scipy.signal import lfilter

DATA = os.environ.get('DATA_DIR', '/app/data'); OUT = os.environ.get('OUT_DIR', '/app/output')
rig = json.load(open(os.path.join(DATA, 'seal_rig.json'))); S = rig['seal']
N = S['number_of_teeth']; PITCH = S['tooth_pitch_mm']*1e-3; B = S['rotor_radius_at_teeth_mm']*1e-3; C0 = S['radial_clearance_mm']*1e-3
R_AIR, GAM = 287.05, 1.4; RHO_STD = 101325.0/(R_AIR*273.15); RC = (2/(GAM + 1))**(GAM/(GAM - 1))


def phi(r):
    r = max(r, RC); return np.sqrt(2*GAM/(GAM - 1)*(r**(2/GAM) - r**((GAM + 1)/GAM)))


PMAX, PEPS = phi(RC), phi(1 - 1e-12)


def phi_seal(rN, mu):
    """Dimensionless mass flow m sqrt(R T) / (Cd A p0) of the N-tooth seal at pressure ratio rN = pN/p0."""
    mus = [1.0] + [mu]*(N - 1)
    def endp(m):
        p = 1.0
        for mm in mus:
            need = m/(mm*p)
            if need >= PMAX: return None
            p *= 1.0 if need <= PEPS else brentq(lambda r: phi(r) - need, RC, 1 - 1e-12)
        return p
    lo, hi = 0.0, mus[-1]*PMAX
    for _ in range(60):
        mid = 0.5*(lo + hi)
        if endp(mid) is None: hi = mid
        else: lo = mid
    if rN <= endp(lo): return lo
    return brentq(lambda m: endp(m) - rN, 1e-9*lo, lo, xtol=1e-14, rtol=1e-12)


R_GRID = np.linspace(0.08, 0.995, 120); MU_GRID = np.linspace(1.0, 1.8, 33)
TABLE = RegularGridInterpolator((R_GRID, MU_GRID), np.array([[phi_seal(r, m) for m in MU_GRID] for r in R_GRID]))


def mdot(p0, pN, T, c, cd, beta):
    x = c/PITCH; mu = 1/np.sqrt(1 - (N - 1)/N*x/(x + beta))
    return cd*2*np.pi*B*c*p0/np.sqrt(R_AIR*T)*TABLE(np.c_[np.clip(pN/p0, R_GRID[0], R_GRID[-1]), np.clip(mu, 1.0, 1.8)])


def lag(Tg, tau, h=1.0):
    """First-order response to a piecewise-linear gas temperature sampled every h seconds, from a settled start (exact)."""
    e = np.exp(-h/tau); g = tau*(1 - e)/h
    y, _ = lfilter([1 - g, g - e], [1.0, -e], Tg, zi=[g*Tg[0]])
    return y


def metal(t, rpm, Tg, taus_fn, wind_fn, sub=4):
    """Ring, land and disc temperatures for a varying speed: the disc time constant follows the speed, and land and disc are
    driven by the gas temperature plus the windage excess of the current speed; settled at the start."""
    out = np.empty((len(t), 3)); y = np.array([Tg[0], Tg[0] + wind_fn(rpm[0]), Tg[0] + wind_fn(rpm[0])])
    out[0] = y
    for i in range(1, len(t)):
        h = (t[i] - t[i-1])/sub
        for j in range(sub):
            f = (j + 0.5)/sub; g = Tg[i-1] + f*(Tg[i] - Tg[i-1]); n = rpm[i-1] + f*(rpm[i] - rpm[i-1])
            w = wind_fn(n); drive = np.array([g, g + w, g + w])
            y = drive + (y - drive)*np.exp(-h/taus_fn(n))
        out[i] = y
    return out


def read(fn):
    d = np.genfromtxt(os.path.join(DATA, fn), delimiter=',', names=True)
    return d, (d['upstream_gauge_kPa'] + d['barometer_kPa'])*1e3, (d['downstream_gauge_kPa'] + d['barometer_kPa'])*1e3, d['flow_slpm']/60e3*RHO_STD


st, sp0, spN, sm = read(rig['test_file'])
TR = [read(f) for f in rig['transient_files'].values()]
TR = [(d, a[::5], b[::5], m[::5], d['inlet_temperature_K'], d['speed_rpm']) for d, a, b, m in TR]   # flows every 5 s for the fit
rpm_s = st['speed_rpm']; T_s = st['inlet_temperature_K']
cands = [i for i in range(1, len(rpm_s)) if abs(rpm_s[i] - rpm_s[i-1]) > 500]


NAMES = ['cd', 'beta', 'a', 'bs', 'br', 'kappa', 'ts', 'tl', 'tref', 'hax', 'delta', 'wind']


def taus_of(q):
    cd, beta, a, bs, br, kap, ts, tl, tref, hax, delta, wind = q
    return lambda n: np.array([ts, tl, tref/(hax + (1 - hax)*(abs(n)/1e4)**0.8)])


def wind_of(q):
    """Settled windage excess of the rotor metal over the gas: wind (K at 12500 rpm) x (n / 12500)^2."""
    return lambda n: q[11]*(np.asarray(n, float)/12500.0)**2


def clearance(rpm, M, q, after):
    """M: ring, land, disc temperatures (columns)."""
    cd, beta, a, bs, br, kap, ts, tl, tref, hax, delta, wind = q
    Trot = kap*M[:, 1] + (1 - kap)*M[:, 2]
    return C0 + np.where(after, delta*1e-6, 0.0) - a*1e-6*(rpm/1e4)**2 + bs*1e-6*(M[:, 0] - 293.15) - br*1e-6*(Trot - 293.15)


def residuals(q, i0):
    cd, beta = q[0], q[1]
    after = np.arange(len(sm)) >= i0
    tf, wf = taus_of(q), wind_of(q)
    ws = wf(rpm_s); Ms = np.column_stack([T_s, T_s + ws, T_s + ws])           # settled: rotor carries the windage excess
    out = [mdot(sp0, spN, T_s, clearance(rpm_s, Ms, q, after), cd, beta)/sm - 1]
    for d, p0, pN, m, Tg, n in TR:
        if np.ptp(n) < 500:                       # constant speed: exact lags with that speed's time constants
            tau = tf(np.median(n)); w = wf(np.median(n))
            M = np.column_stack([lag(Tg, tau[0]), lag(Tg + w, tau[1]), lag(Tg + w, tau[2])])[::5]
        else:                                     # speed ramp: integrate with the speed-dependent time constant and windage
            M = metal(d['time_s'], n, Tg, tf, wf, sub=1)[::5]
        out.append(mdot(p0, pN, Tg[::5], clearance(n[::5], M, q, True), cd, beta)/m - 1)
    return np.concatenate(out)


X0 = [0.7, 0.02, 25.0, 2.0, 1.5, 0.3, 45.0, 120.0, 600.0, 0.2, 20.0, 5.0]
LO = [0.3, 1e-4, -50, -5, -5, 0.0, 5, 20, 50, 0.0, -50, -20]; HI = [1.0, 1.0, 100, 10, 10, 1.0, 400, 2000, 5000, 1.0, 150, 80]
XS = [0.01, 0.005, 2, 0.1, 0.1, 0.05, 5, 20, 50, 0.05, 2, 1]
best = None
for i0 in cands:
    r = least_squares(residuals, X0, args=(i0,), bounds=(LO, HI), x_scale=XS)
    if best is None or r.cost < best[0].cost: best = (r, i0)
fit, i_rub = best
for kap0, tl0, tr0 in ((0.2, 80.0, 400.0), (0.5, 200.0, 900.0), (0.3, 120.0, 1500.0)):
    x0 = list(fit.x); x0[5], x0[7], x0[8] = kap0, tl0, tr0
    r = least_squares(residuals, x0, args=(i_rub,), bounds=(LO, HI), x_scale=XS)
    if r.cost < fit.cost: fit = r
q = fit.x
print('# rub before test', i_rub + 1, {k: round(float(v), 4) for k, v in zip(NAMES, q)}, f'rms misfit {100*np.std(fit.fun):.2f} %')
su = rig['start_up_target']
t = np.arange(0, max(su['report_times_s']) + 1, 1.0)
n = su['speed_rpm']['start'] + (su['speed_rpm']['end'] - su['speed_rpm']['start'])*np.clip(t/su['speed_rpm']['ramp_s'], 0, 1)
Tg = su['inlet_temperature_K']['start'] + (su['inlet_temperature_K']['end'] - su['inlet_temperature_K']['start'])*np.clip(t/su['inlet_temperature_K']['ramp_s'], 0, 1)
c = clearance(n, metal(t, n, Tg, taus_of(q), wind_of(q), sub=8), q, True)
m = mdot(np.full(len(t), su['upstream_absolute_kPa']*1e3), np.full(len(t), su['downstream_absolute_kPa']*1e3), Tg, c, q[0], q[1])
out = {f't{tt}': float(1e3*m[tt]) for tt in su['report_times_s']}
print('#', {k: round(v, 3) for k, v in out.items()})
os.makedirs(OUT, exist_ok=True)
json.dump({'leakage_g_per_s': out}, open(os.path.join(OUT, 'results.json'), 'w'), indent=2)
