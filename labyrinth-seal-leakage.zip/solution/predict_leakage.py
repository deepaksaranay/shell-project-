"""Reference solution: labyrinth-seal leakage during an engine start-up, from steady and transient rig records.

1. Readings: absolute pressure = gauge + barometer; mass flow = standard litres per minute x air density at 273.15 K and
   101.325 kPa.
2. Flow model, tooth by tooth: isentropic throttles of area 2 pi b c with one discharge coefficient Cd, a Hodkinson-type
   carry-over factor mu = [1 - (N-1)/N x/(x + beta)]^-1/2 (x = c / pitch) on teeth 2..N, constant gas temperature, choking of
   the last tooth. For speed, m = Cd 2 pi b c p0 / sqrt(R T) * Phi(pN/p0, mu), with Phi tabulated once by the exact
   tooth-by-tooth march and interpolated.
3. Running clearance: c = c0 + delta (after the rub) - a (n/10^4 rpm)^2 + b_s (T_ring - 293.15)
   - b_r [kappa (T_land - 293.15) + (1 - kappa) (T_disc - 293.15)]. The rotor is a thin seal-land flange on a forged disc, so
   its growth follows two metal temperatures. Ring, land and disc temperatures are first-order lags. Land and disc are driven
   by the gas temperature plus a windage excess W (n/12500)^2: disc friction heats the rotor metal, and in settled points
   this extra growth scales with speed squared like the centrifugal growth, so only its lag (the slow drift after the speed
   ramp of TR3) separates the two. The disc faces are swept by the air upstream of the seal, in turbulent flow, so the
   convection coefficient goes with Nu ~ Re^0.8 in the rotational Reynolds number Re = rho omega b^2 / mu of the current
   speed, pressure and gas temperature (ideal-gas density, Sutherland viscosity), on top of a part independent of Re:
   tau_disc = tau_ref / (h_ax + (1 - h_ax) Re^0.8), Re relative to 10000 rpm, 200 kPa, 320 K.
4. All parameters (Cd, beta, a, b_s, b_r, kappa, tau_s, tau_land, tau_ref, h_ax, delta, W) are fitted to the steady points
   and the transient records together (relative least squares on mass flow); the disc time constant changes along every
   record, so the disc response is integrated with the current time constant; the rub opening starts at the speed change
   with the smallest misfit.
5. The start-up is in the engine: 12500 rpm and 12.2 bar, beyond the rig records (3000 to 9000 rpm, 160 to 200 kPa), so the
   disc time constant there follows from the Reynolds number of the engine state, about 5 times the rig's reference state.
   The metal temperatures are integrated along the start-up and the leakage is reported at the requested times.
"""
import json, os
import numpy as np
from scipy.optimize import brentq, least_squares
from scipy.interpolate import RegularGridInterpolator
from scipy.signal import lfilter

DATA = os.environ.get('DATA_DIR', '/app/data'); OUT = os.environ.get('OUT_DIR', '/app/output')
rig = json.load(open(os.path.join(DATA, 'seal_rig.json'))); S = rig['seal']
N = S['number_of_teeth']; PITCH = S['tooth_pitch_mm']*1e-3; B = S['rotor_radius_at_teeth_mm']*1e-3; C0 = S['radial_clearance_mm']*1e-3
R_AIR, GAM = 287.05, 1.4; RHO_STD = 101325.0/(R_AIR*273.15); RC = (2/(GAM + 1))**(GAM/(GAM - 1))


def phi(r):
    r = max(r, RC); return np.sqrt(2*GAM/(GAM - 1)*(r**(2/GAM) - r**((GAM + 1)/GAM)))


PMAX, PEPS = phi(RC), phi(1 - 1e-12)


def phi_seal(rN, mu):
    """Dimensionless mass flow m sqrt(R T) / (Cd A p0) of the N-tooth seal at pressure ratio rN = pN/p0."""
    mus = [1.0] + [mu]*(N - 1)
    def endp(m):
        p = 1.0
        for mm in mus:
            need = m/(mm*p)
            if need >= PMAX: return None
            p *= 1.0 if need <= PEPS else brentq(lambda r: phi(r) - need, RC, 1 - 1e-12)
        return p
    lo, hi = 0.0, mus[-1]*PMAX
    for _ in range(60):
        mid = 0.5*(lo + hi)
        if endp(mid) is None: hi = mid
        else: lo = mid
    if rN <= endp(lo): return lo
    return brentq(lambda m: endp(m) - rN, 1e-9*lo, lo, xtol=1e-14, rtol=1e-12)


R_GRID = np.linspace(0.08, 0.995, 120); MU_GRID = np.linspace(1.0, 1.8, 33)
TABLE = RegularGridInterpolator((R_GRID, MU_GRID), np.array([[phi_seal(r, m) for m in MU_GRID] for r in R_GRID]))


def mdot(p0, pN, T, c, cd, beta):
    x = c/PITCH; mu = 1/np.sqrt(1 - (N - 1)/N*x/(x + beta))
    return cd*2*np.pi*B*c*p0/np.sqrt(R_AIR*T)*TABLE(np.c_[np.clip(pN/p0, R_GRID[0], R_GRID[-1]), np.clip(mu, 1.0, 1.8)])


def lag(Tg, tau, h=1.0):
    """First-order response to a piecewise-linear gas temperature sampled every h seconds, from a settled start (exact)."""
    e = np.exp(-h/tau); g = tau*(1 - e)/h
    y, _ = lfilter([1 - g, g - e], [1.0, -e], Tg, zi=[g*Tg[0]])
    return y


P_RE, T_RE = 200e3, 320.0                          # reference state for the disc Reynolds number: 10000 rpm, 200 kPa, 320 K


def viscosity(T):
    """Air, Sutherland's law (Pa s)."""
    return 1.716e-5*(T/273.15)**1.5*(273.15 + 110.4)/(T + 110.4)


def reynolds_ratio(rpm, p0, T):
    """Rotational Reynolds number rho omega b^2 / mu of the disc relative to the reference state; the disc faces are swept by
    the air upstream of the seal (density p0 / (R T), viscosity at T)."""
    return np.maximum((np.abs(rpm)/1e4)*(p0/P_RE)*(T_RE/T)*(viscosity(T_RE)/viscosity(T)), 1e-4)   # floor: rotor at rest


def varlag(drive, tau, h=1.0):
    """First-order response with a time constant that changes along the record (settled start): on every step the midpoint
    drive and time constant, y_i = d + (y_(i-1) - d) exp(-h/tau), evaluated for the whole record with cumulative products."""
    dm = 0.5*(drive[1:] + drive[:-1]); a = np.exp(-h/(0.5*(tau[1:] + tau[:-1])))
    P = np.cumprod(a)
    y = np.empty(len(drive)); y[0] = drive[0]
    y[1:] = P*(drive[0] + np.cumsum((1 - a)*dm/P))
    return y


def metal(rpm, Tg, p0, q):
    """Ring, land and disc temperatures along a 1 Hz history, settled at its start. Ring and land: constant time constants.
    Disc: convection on a rotating disc, 1/tau = (h_ax + (1 - h_ax) Re^0.8)/tau_ref with the Reynolds number of the current
    speed, pressure and gas temperature. Land and disc are driven by the gas temperature plus the windage excess."""
    w = q[11]*(rpm/12500.0)**2
    tau_d = q[8]/(q[9] + (1 - q[9])*reynolds_ratio(rpm, p0, Tg)**0.8)
    return np.column_stack([lag(Tg, q[6]), lag(Tg + w, q[7]), varlag(Tg + w, tau_d)])


def read(fn):
    d = np.genfromtxt(os.path.join(DATA, fn), delimiter=',', names=True)
    return d, (d['upstream_gauge_kPa'] + d['barometer_kPa'])*1e3, (d['downstream_gauge_kPa'] + d['barometer_kPa'])*1e3, d['flow_slpm']/60e3*RHO_STD


st, sp0, spN, sm = read(rig['test_file'])
TR = [read(f) for f in rig['transient_files'].values()]
TR = [(d, a[::5], b[::5], m[::5], d['inlet_temperature_K'], d['speed_rpm'], a) for d, a, b, m in TR]   # flows every 5 s for the fit
rpm_s = st['speed_rpm']; T_s = st['inlet_temperature_K']
cands = [i for i in range(1, len(rpm_s)) if abs(rpm_s[i] - rpm_s[i-1]) > 500]


NAMES = ['cd', 'beta', 'a', 'bs', 'br', 'kappa', 'ts', 'tl', 'tref', 'hax', 'delta', 'wind']


def clearance(rpm, M, q, after):
    """M: ring, land, disc temperatures (columns)."""
    cd, beta, a, bs, br, kap, ts, tl, tref, hax, delta, wind = q
    Trot = kap*M[:, 1] + (1 - kap)*M[:, 2]
    return C0 + np.where(after, delta*1e-6, 0.0) - a*1e-6*(rpm/1e4)**2 + bs*1e-6*(M[:, 0] - 293.15) - br*1e-6*(Trot - 293.15)


def residuals(q, i0):
    cd, beta = q[0], q[1]
    after = np.arange(len(sm)) >= i0
    ws = q[11]*(rpm_s/12500.0)**2; Ms = np.column_stack([T_s, T_s + ws, T_s + ws])   # settled: rotor carries the windage excess
    out = [mdot(sp0, spN, T_s, clearance(rpm_s, Ms, q, after), cd, beta)/sm - 1]
    for d, p0, pN, m, Tg, n, p0_full in TR:
        M = metal(n, Tg, p0_full, q)[::5]
        out.append(mdot(p0, pN, Tg[::5], clearance(n[::5], M, q, True), cd, beta)/m - 1)
    return np.concatenate(out)


X0 = [0.7, 0.02, 25.0, 2.0, 1.5, 0.3, 45.0, 120.0, 600.0, 0.2, 20.0, 5.0]
LO = [0.3, 1e-4, -50, -5, -5, 0.0, 5, 20, 50, 0.0, -50, -20]; HI = [1.0, 1.0, 100, 10, 10, 1.0, 400, 2000, 5000, 1.0, 150, 80]
XS = [0.01, 0.005, 2, 0.1, 0.1, 0.05, 5, 20, 50, 0.05, 2, 1]
best = None
for i0 in cands:
    r = least_squares(residuals, X0, args=(i0,), bounds=(LO, HI), x_scale=XS)
    if best is None or r.cost < best[0].cost: best = (r, i0)
fit, i_rub = best
for kap0, tl0, tr0 in ((0.2, 80.0, 400.0), (0.5, 200.0, 900.0), (0.3, 120.0, 1500.0)):
    x0 = list(fit.x); x0[5], x0[7], x0[8] = kap0, tl0, tr0
    r = least_squares(residuals, x0, args=(i_rub,), bounds=(LO, HI), x_scale=XS)
    if r.cost < fit.cost: fit = r
q = fit.x
print('# rub before test', i_rub + 1, {k: round(float(v), 4) for k, v in zip(NAMES, q)}, f'rms misfit {100*np.std(fit.fun):.2f} %')
su = rig['start_up_target']
t = np.arange(0, max(su['report_times_s']) + 1, 1.0)
n = su['speed_rpm']['start'] + (su['speed_rpm']['end'] - su['speed_rpm']['start'])*np.clip(t/su['speed_rpm']['ramp_s'], 0, 1)
Tg = su['inlet_temperature_K']['start'] + (su['inlet_temperature_K']['end'] - su['inlet_temperature_K']['start'])*np.clip(t/su['inlet_temperature_K']['ramp_s'], 0, 1)
p_up = np.full(len(t), su['upstream_absolute_kPa']*1e3)
c = clearance(n, metal(n, Tg, p_up, q), q, True)   # the disc responds at the Reynolds number of the engine pressure
m = mdot(p_up, np.full(len(t), su['downstream_absolute_kPa']*1e3), Tg, c, q[0], q[1])
out = {f't{tt}': float(1e3*m[tt]) for tt in su['report_times_s']}
print('#', {k: round(v, 3) for k, v in out.items()})
os.makedirs(OUT, exist_ok=True)
json.dump({'leakage_g_per_s': out}, open(os.path.join(OUT, 'results.json'), 'w'), indent=2)
