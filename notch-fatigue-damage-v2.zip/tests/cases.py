"""Service of a notched component (shared by the hidden test cases and the authoring generator).

A case is a service schedule of two records: the duty cycle (record A, repeated n_A times) and a rare severe event
(record B), and the schedule repeats end to start. Each record is one run from standstill to standstill: operating states
(a mean load with a random load on top, in one or more frequency bands, with smooth transitions), half-sine overload
pulses, and the machine stops again. The load cell is read through a 16-bit telemetry channel in ADC counts. Two
acquisition faults are built in: the load cell's zero is offset (the reading at standstill is not zero), and the telemetry
corrupts single samples (a sample replaced by an unrelated reading). Truth is computed from the true load.

    build(name) -> dict(load_A, counts_A, load_B, counts_B, q, cfg)
"""
import numpy as np

BANDS = {'low': (0.3, 3.0), 'mid': (2.0, 12.0), 'wide': (0.5, 40.0), 'hf': (25.0, 150.0)}   # Hz

MATERIALS = {   # cyclic properties: E, K', n' (Ramberg-Osgood); sf', b, ef', c (strain-life)
    'SAE 1045 Q&T':        dict(E=202000.0, K=1258.0, n=0.208, sf=948.0,  b=-0.092, ef=0.260, c=-0.445),
    'AISI 4340 Q&T':       dict(E=200000.0, K=1655.0, n=0.131, sf=1879.0, b=-0.0859, ef=0.640, c=-0.636),
    'SAE 1020 hot-rolled': dict(E=203000.0, K=772.0,  n=0.180, sf=896.0,  b=-0.120, ef=0.410, c=-0.510),
    'Al 7075-T6':          dict(E=71000.0,  K=977.0,  n=0.106, sf=1466.0, b=-0.143, ef=0.262, c=-0.619),
    'Ti-6Al-4V STA':       dict(E=117000.0, K=1772.0, n=0.106, sf=2030.0, b=-0.104, ef=0.841, c=-0.688),
    'Al 2024-T3':          dict(E=73100.0,  K=662.0,  n=0.070, sf=1294.0, b=-0.142, ef=0.327, c=-0.645),
}


def _band_process(rng, n, band, FS):
    """Unit-variance Gaussian process with a flat spectrum between the band edges (FFT filtering of white noise)."""
    f_lo, f_hi = BANDS[band]
    w = rng.standard_normal(n)
    W = np.fft.rfft(w)
    f = np.fft.rfftfreq(n, 1.0/FS)
    W[(f < f_lo) | (f > f_hi)] = 0.0
    x = np.fft.irfft(W, n)
    return x/np.std(x)


def _ramp_profile(n, knots, FS):
    """Piecewise-constant profile with 2 s raised-cosine transitions. knots: list of (start_s, value)."""
    t = np.arange(n)/FS
    out = np.zeros(n)
    prev = 0.0
    for ts, v in knots:
        s = np.clip((t - ts)/2.0, 0.0, 1.0)
        out += (v - prev)*0.5*(1 - np.cos(np.pi*s))
        prev = v
    return out




def _load(cfg, seed, peaks_abs=None):
    """True load (kN) of one record; peaks_abs: absolute overload pulses (time s, peak kN, duration s) added to the cfg's."""
    rng = np.random.default_rng(seed)
    FS = cfg['fs']
    t_run = sum(seg[0] for seg in cfg['segments'])
    n = int(round((cfg['standstill_s'][0] + t_run + cfg['standstill_s'][1] + 4.0)*FS))
    t0 = cfg['standstill_s'][0]
    bands = sorted({b for seg in cfg['segments'] for b in seg[2]})
    mean_knots, rms_knots = [], {b: [] for b in bands}
    ts = t0
    for dur, mean, rms_by_band in cfg['segments']:
        mean_knots.append((ts, mean))
        for b in bands:
            rms_knots[b].append((ts, rms_by_band.get(b, 0.0)))
        ts += dur
    mean_knots.append((ts, 0.0))
    for b in bands:
        rms_knots[b].append((ts, 0.0))
    load = _ramp_profile(n, mean_knots, FS)
    for b in bands:
        load += _ramp_profile(n, rms_knots[b], FS)*_band_process(rng, n, b, FS)
    t = np.arange(n)/FS
    for (te, peak, dur) in list(cfg.get('overloads', [])) + list(peaks_abs or []):
        s = (t - te)/dur
        m = (s >= 0) & (s <= 1)
        load[m] += peak*np.sin(np.pi*s[m])
    load[np.abs(load) < 1e-12] = 0.0
    return load, rng


def _counts(load, rng, q, offset, spikes, FS):
    counts = np.rint((load + offset)/q)
    assert np.abs(counts).max() < 32000, 'load channel would saturate'
    counts = np.clip(counts, -32767, 32767)
    if spikes:
        n = len(load)
        k = rng.choice(np.arange(int(5*FS), n - int(5*FS)), size=spikes['count'], replace=False)
        mag = rng.uniform(spikes['min_kN'], spikes['max_kN'], size=spikes['count'])*rng.choice([-1.0, 1.0], size=spikes['count'])
        counts[k] = np.clip(np.rint(mag/q), -32767, 32767)
    return counts.astype(np.int16)


def build(cfg):
    """Both records of a case: the duty cycle A and the severe event B (whose overload pulses exceed every load of A)."""
    FS = cfg['fs']
    la, rng_a = _load(cfg['A'] | dict(fs=FS), cfg['A']['seed'])
    peak_a = float(np.abs(la).max())
    sign = 1.0 if np.mean(la) >= 0 else -1.0
    pulses = [(t, sgn*sign*fac*peak_a, d) for (t, fac, sgn, d) in cfg['B']['events']]
    lb, rng_b = _load(cfg['B'] | dict(fs=FS), cfg['B']['seed'], pulses)
    assert np.abs(lb).max() > 1.25*peak_a, 'the severe event must exceed every duty-cycle load'
    top = max(np.abs(la).max(), np.abs(lb).max()) + abs(cfg['zero_offset_kN'])
    q = round(float(np.ceil(top/27000.0/0.0005)*0.0005), 4)
    ca = _counts(la, rng_a, q, cfg['zero_offset_kN'], cfg['A'].get('spikes'), FS)
    cb = _counts(lb, rng_b, q, cfg['zero_offset_kN'], cfg['B'].get('spikes'), FS)
    return dict(load_A=la, counts_A=ca, load_B=lb, counts_B=cb, q=q)


def case_json(cfg, q):
    """The case description the solver's program receives (no truth, no fault parameters)."""
    return {
        'component': cfg['component'],
        'material': cfg['material'],
        'cyclic_properties': {k: MATERIALS[cfg['material']][k] for k in ('E', 'K', 'n', 'sf', 'b', 'ef', 'c')},
        'stress_concentration_factor_Kt': cfg['Kt'],
        'nominal_stress_MPa_per_kN': cfg['MPa_per_kN'],
        'load_channel': {'dtype': 'int16', 'kN_per_count': q, 'sample_rate_Hz': cfg['fs'],
                         'acquisition': '16-bit load cell signal sent over a wireless telemetry link from the rotating/moving part'},
        'service': {'schedule': [{'record': 'duty cycle', 'file': 'duty_counts.npy', 'repeats': cfg['n_A']},
                                 {'record': 'severe event', 'file': 'event_counts.npy', 'repeats': 1}],
                    'rule': ('each record is one run from standstill to standstill; in service the schedule is run '
                             'once through, then repeated end to start without a break'),
                    'load_cell': 'the same load cell and channel for both records'},
    }


def _seg(spec):
    return [(d, m, r) for d, m, r in spec]


def _case(component, material, Kt, MPa, offset, fs, n_A, A, B):
    return dict(component=component, material=material, Kt=Kt, MPa_per_kN=MPa, zero_offset_kN=offset, fs=fs, n_A=n_A, A=A, B=B)


def _event(first_neg, tB):
    """Severe-event pulses (time, factor on the duty cycle's largest load, sign, duration): two big pulses of opposite sign."""
    s1, s2 = (-1.0, 1.0) if first_neg else (1.0, -1.0)
    return [(0.35*tB, 1.45, s1, 0.5), (0.7*tB, 1.35, s2, 0.5)]


def _B(seed, tB, mean, bands, standstill, events, spikes=None, hf=0.0):
    bd = {k: 0.8*v for k, v in bands.items()}
    if hf:
        bd['hf'] = hf
    return dict(seed=seed, standstill_s=standstill, segments=_seg([(tB, mean, bd)]), events=events, spikes=spikes)


# ---------------------------------------------------------------------------------------------------------------------
# Hidden test cases. They are deliberately unlike the visible ones (environment/data/cases): materials never seen
# (aluminium alloys, titanium), notch strains well beyond the visible range, compressive pulses in the severe events
# (the visible events are tensile first), mostly compressive mean load, spikes of a size never seen, larger and negative
# load cell offsets, a duty cycle repeated 60 times in the schedule (visible: 4) and records of 3 million samples at
# 2 kHz with high-frequency vibration.
N_HID = 60
HIDDEN = {
    'H1': _case('wing-attachment lug', 'Al 7075-T6', 2.6, 4.2, -2.35, 2000.0, N_HID,
                dict(seed=9101, standstill_s=(9.0, 7.0), segments=_seg([(480, 18.0, {'mid': 9.0, 'low': 6.0, 'hf': 3.0}), (560, 10.0, {'wide': 7.5, 'hf': 3.0}), (420, 22.0, {'mid': 11.0, 'hf': 3.0})]),
                     overloads=[(360.0, -34.0, 0.6), (930.0, -38.0, 0.5)], spikes=dict(count=25, min_kN=20.0, max_kN=60.0)),
                _B(9501, 90.0, 20.0, {'mid': 9.0}, (6.0, 6.0), _event(True, 90.0), dict(count=6, min_kN=20.0, max_kN=60.0), 3.0)),
    'H2': _case('connecting-rod shank', 'Ti-6Al-4V STA', 2.1, 6.5, 1.85, 2000.0, N_HID,
                dict(seed=9102, standstill_s=(6.0, 6.0), segments=_seg([(760, 25.0, {'wide': 20.0, 'hf': 5.0}), (740, 30.0, {'mid': 22.0, 'low': 10.0, 'hf': 5.0})]),
                     overloads=[(900.0, -50.0, 0.4)], spikes=dict(count=30, min_kN=8.0, max_kN=30.0)),
                _B(9502, 80.0, 27.0, {'wide': 18.0}, (6.0, 6.0), _event(False, 80.0), dict(count=6, min_kN=8.0, max_kN=30.0), 5.0)),
    'H3': _case('landing-gear torque link', 'Al 2024-T3', 2.9, 3.6, -3.10, 2000.0, N_HID,
                dict(seed=9103, standstill_s=(8.0, 10.0), segments=_seg([(480, 5.0, {'wide': 11.0, 'hf': 3.5}), (600, -4.0, {'mid': 12.0, 'hf': 3.5}), (450, 8.0, {'low': 9.0, 'wide': 6.0, 'hf': 3.5})]),
                     overloads=[(270.0, 34.0, 0.5), (780.0, -36.0, 0.5)], spikes=dict(count=25, min_kN=15.0, max_kN=45.0)),
                _B(9503, 90.0, 6.0, {'wide': 9.0}, (8.0, 8.0), _event(False, 90.0), dict(count=6, min_kN=15.0, max_kN=45.0), 3.5)),
    'H4': _case('axle fillet', 'SAE 1045 Q&T', 2.4, 5.5, -4.20, 2000.0, N_HID,
                dict(seed=9104, standstill_s=(7.0, 7.0), segments=_seg([(600, 15.0, {'wide': 24.0, 'hf': 6.0}), (780, 12.0, {'mid': 26.0, 'hf': 6.0})]),
                     overloads=[(510.0, -62.0, 0.6), (1170.0, -58.0, 0.6)], spikes=dict(count=28, min_kN=25.0, max_kN=80.0)),
                _B(9504, 90.0, 14.0, {'wide': 22.0}, (7.0, 7.0), _event(True, 90.0), dict(count=6, min_kN=25.0, max_kN=80.0), 6.0)),
    'H5': _case('crankshaft web', 'AISI 4340 Q&T', 2.7, 5.0, 2.65, 2000.0, N_HID,
                dict(seed=9105, standstill_s=(10.0, 8.0), segments=_seg([(900, 20.0, {'wide': 21.0, 'hf': 5.5}), (840, 26.0, {'mid': 20.0, 'low': 12.0, 'hf': 5.5})]),
                     overloads=[(660.0, 60.0, 0.4), (1410.0, -52.0, 0.4)], spikes=dict(count=40, min_kN=5.0, max_kN=15.0)),
                _B(9505, 100.0, 22.0, {'wide': 18.0}, (6.0, 6.0), _event(False, 100.0), dict(count=6, min_kN=5.0, max_kN=15.0), 5.5)),
    'H6': _case('press-frame tie (mostly compressive)', 'SAE 1020 hot-rolled', 2.3, 4.8, -1.40, 2000.0, N_HID,
                dict(seed=9106, standstill_s=(6.0, 9.0), segments=_seg([(660, -25.0, {'mid': 14.0, 'hf': 4.0}), (720, -18.0, {'wide': 16.0, 'low': 6.0, 'hf': 4.0})]),
                     overloads=[(300.0, 26.0, 0.5), (1050.0, -38.0, 0.5)], spikes=dict(count=24, min_kN=10.0, max_kN=40.0)),
                _B(9506, 90.0, -22.0, {'mid': 13.0}, (6.0, 6.0), _event(True, 90.0), dict(count=6, min_kN=10.0, max_kN=40.0), 4.0)),
    'H7': _case('bracket under preload', 'Al 7075-T6', 2.2, 4.0, 3.05, 2000.0, N_HID,
                dict(seed=9107, standstill_s=(8.0, 8.0), segments=_seg([(750, 45.0, {'wide': 10.0, 'hf': 3.0}), (690, 52.0, {'mid': 12.0, 'hf': 3.0})]),
                     overloads=[(420.0, 50.0, 0.5), (1080.0, -24.0, 0.5)], spikes=dict(count=22, min_kN=30.0, max_kN=90.0)),
                _B(9507, 90.0, 48.0, {'wide': 9.0}, (8.0, 8.0), _event(False, 90.0), dict(count=6, min_kN=30.0, max_kN=90.0), 3.0)),
    'H8': _case('hydraulic cylinder eye', 'Ti-6Al-4V STA', 2.5, 5.8, -2.80, 2000.0, N_HID,
                dict(seed=9108, standstill_s=(12.0, 12.0), segments=_seg([(450, 30.0, {'low': 18.0, 'hf': 5.0}), (450, 0.0, {'wide': 24.0, 'hf': 5.0}), (510, 34.0, {'mid': 22.0, 'hf': 5.0})]),
                     overloads=[(240.0, -50.0, 0.5), (690.0, 62.0, 0.5), (1200.0, -55.0, 0.5)], spikes=dict(count=30, min_kN=6.0, max_kN=20.0)),
                _B(9508, 100.0, 32.0, {'wide': 20.0}, (12.0, 12.0), _event(True, 100.0), dict(count=6, min_kN=6.0, max_kN=20.0), 5.0)),
}

# Visible cases (environment/data/cases), with their damage given to the solver. Every effect that matters for the
# hidden cases occurs in at least one of them: plasticity at the notch (V2), overload pulses (V4, and the severe event of
# every case), the memory carried from the severe event into the duty cycles (every case), telemetry spikes (V3, V5),
# load-cell zero offset (all), a negative mean load (V5) and a 2 kHz record with high-frequency vibration (V2).
N_VIS = 4
VISIBLE = {
    'V1': _case('axle fillet', 'SAE 1045 Q&T', 2.2, 5.0, 0.95, 1000.0, N_VIS,
                dict(seed=8101, standstill_s=(5.0, 5.0), segments=_seg([(125, 12.0, {'low': 14.0, 'mid': 6.0}), (100, 8.0, {'mid': 15.0})]), overloads=[]),
                _B(8501, 40.0, 11.0, {'low': 12.0}, (5.0, 5.0), _event(False, 40.0))),
    'V2': _case('crankshaft web', 'AISI 4340 Q&T', 2.6, 5.0, -1.20, 2000.0, N_VIS,
                dict(seed=8102, standstill_s=(5.0, 5.0), segments=_seg([(150, 22.0, {'wide': 22.0, 'hf': 4.0}), (125, 25.0, {'mid': 21.0, 'hf': 5.0})]), overloads=[]),
                _B(8502, 40.0, 23.0, {'wide': 18.0}, (5.0, 5.0), _event(False, 40.0), None, 4.0)),
    'V3': _case('suspension link', 'SAE 1020 hot-rolled', 2.0, 4.5, 0.60, 1000.0, N_VIS,
                dict(seed=8103, standstill_s=(5.0, 6.0), segments=_seg([(200, 6.0, {'wide': 12.0})]), overloads=[],
                     spikes=dict(count=6, min_kN=60.0, max_kN=120.0)),
                _B(8503, 40.0, 7.0, {'wide': 10.0}, (5.0, 5.0), _event(False, 40.0), dict(count=2, min_kN=60.0, max_kN=120.0))),
    'V4': _case('axle fillet', 'SAE 1045 Q&T', 2.3, 5.0, 1.75, 1000.0, N_VIS,
                dict(seed=8104, standstill_s=(6.0, 5.0), segments=_seg([(110, 10.0, {'mid': 18.0}), (115, 14.0, {'wide': 16.0})]), overloads=[(90.0, 40.0, 0.5)]),
                _B(8504, 40.0, 12.0, {'mid': 15.0}, (5.0, 5.0), _event(False, 40.0))),
    'V5': _case('press-frame tie', 'AISI 4340 Q&T', 2.4, 5.0, -0.85, 1000.0, N_VIS,
                dict(seed=8105, standstill_s=(5.0, 5.0), segments=_seg([(150, -10.0, {'mid': 20.0}), (100, 4.0, {'low': 15.0})]), overloads=[],
                     spikes=dict(count=5, min_kN=50.0, max_kN=110.0)),
                _B(8505, 40.0, -9.0, {'mid': 17.0}, (5.0, 5.0), _event(True, 40.0), dict(count=2, min_kN=50.0, max_kN=110.0))),
}
