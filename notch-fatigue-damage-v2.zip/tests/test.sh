#!/usr/bin/env bash
# Writes /logs/verifier/reward.txt: 1 if every test in test_fatigue.py passes, 0 otherwise; CTRF via the pytest plugin.
# The solver's program runs as an unprivileged user, so the test files are made unreadable to others first.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
chmod -R go-rwx /tests /logs 2>/dev/null
cd /tests || exit 0
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest /tests/test_fatigue.py --rootdir=/tests -c /dev/null \
    -p no:cacheprovider -p ctrf --ctrf /logs/verifier/ctrf.json -q && echo 1 > /logs/verifier/reward.txt
exit 0
