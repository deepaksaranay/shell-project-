A durability team needs a program that turns the measured load records of a notched machine part into the fatigue damage that one pass through its service schedule does at the notch root.

Each case is a directory with `case.json` and two load records, `duty_counts.npy` and `event_counts.npy`. `case.json` gives the part (its stress concentration factor `Kt`, the nominal stress per kN of load at the notch section), the cyclic properties of its material, the load channel and the service schedule. A record is the load-cell channel in ADC counts (`int16`; load in kN = counts times `kN_per_count`) of one run of the machine from standstill to standstill: the duty cycle is a normal run, the severe event is a rare run with much larger loads. In service the machine runs the duty cycle `repeats` times in a row, then the severe event once, and this schedule is repeated end to start without a break. Five example cases are in `/app/data/cases/`, and the damage per schedule of each is in `/app/data/visible_damage.json`.

Use the strain-life method:

- Nominal stress at the notch section: $ S = L \, k $, with $ L $ the load in kN and $ k $ the value `nominal_stress_MPa_per_kN`.
- Notch-root stress and strain from Neuber's rule, $ \sigma \varepsilon = (K_t S)^2 / E $, with the cyclic stress-strain curve $ \varepsilon = \sigma/E + (\sigma/K')^{1/n'} $ for the first loading. Every later branch follows the Masing curve $ \Delta\varepsilon = \Delta\sigma/E + 2\,(\Delta\sigma/(2K'))^{1/n'} $, with $ \Delta\sigma\,\Delta\varepsilon = (K_t\,\Delta S)^2 / E $ measured from the reversal where the branch began. The material has memory: when a hysteresis loop closes, the material continues on the branch it was on before the loop.
- Cycles by rainflow counting of the whole service, in the stabilised state of the repeated schedule: report the damage per schedule of the repeated loading, as if the schedule had already been applied many times.

The life $ N $ of each closed cycle follows from Smith-Watson-Topper:

$$
\sigma_{\max}\,\varepsilon_a = \frac{\sigma_f'^{\,2}}{E}\,(2N)^{2b} + \sigma_f'\,\varepsilon_f'\,(2N)^{b+c}
$$

Here $ \sigma_{\max} $ is the larger notch-root stress of the cycle and $ \varepsilon_a $ is half its strain range. A cycle with $ \sigma_{\max} \le 0 $ does no damage. The damage per schedule is $ \sum 1/N $ over the closed cycles of one pass through the schedule.

In `case.json`, `cyclic_properties` holds $ E $, $ K' $, $ n' $, $ \sigma_f' $, $ b $, $ \varepsilon_f' $ and $ c $ as `E`, `K`, `n`, `sf`, `b`, `ef` and `c` (stresses in MPa), and `stress_concentration_factor_Kt` is $ K_t $.

Write the program as one self-contained Python file, `/app/fatigue/predict.py`, using only the standard library, NumPy and SciPy. It is run as `python3 /app/fatigue/predict.py <case_dir> <output_json>` and must write to `<output_json>` a JSON object with the single key `damage_per_schedule`, mapping to a finite positive number.

It will be run on other cases than the examples: other parts, materials and service, with records of up to about 4 million samples and duty cycles that repeat up to about 60 times. Each run of `/app/fatigue/predict.py` must finish within 6 seconds on 1 CPU, and each damage must meet the relative-error requirement against the damage that the load the part actually carried produces in the simulation that made the records.

You have 28800 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
