#!/usr/bin/env bash
# Installs the reference program where the tests run it, and runs it once on the visible cases as a check.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p /app/fatigue
cp "$here/predict.py" /app/fatigue/predict.py
for d in /app/data/cases/*/; do
    OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python3 /app/fatigue/predict.py "$d" "/tmp/$(basename "$d").json"
done
