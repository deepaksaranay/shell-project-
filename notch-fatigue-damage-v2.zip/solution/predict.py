"""Reference program: fatigue damage per service schedule at a notch from measured load records.

    python3 predict.py <case_dir> <output_json>

1. Read the ADC counts of both records (duty cycle A, severe event B) and convert them to kN.
2. Telemetry corruption: single samples replaced by an unrelated reading. The load is band-limited and densely sampled, so
   a real sample lies close to the mean of its two neighbours; a corrupted one does not. The half second difference
   r = x[i] - (x[i-1] + x[i+1])/2 is compared with a threshold (12 robust standard deviations of r, at least 1 % of the
   load range), and a flagged sample is replaced by the mean of its neighbours.
3. Load-cell zero: both records start and end at standstill (no load), so the median reading over the first and last two
   seconds is the zero offset, removed from every sample.
4. Nominal stress; turning points of each record from its first to its last significant one. The standstill between two
   records is a turning point (zero) exactly when the load approaches it and leaves it from the same side.
5. The schedule repeated end to start, in its stabilised state: the circular sequence B, A x n, B is started at the largest
   |S| (in B). Rainflow with the Neuber/Masing memory is a stack walk. A duty cycle that is run again from the same stack
   state does exactly what it did before, so the walk follows duty cycles only until the stack after one equals the stack
   after the one before; the damage of that cycle is then added for every remaining copy (the cycles it closes get that
   multiplicity). Neuber is inverted by interpolation in tables built once from the explicit forward relations (the
   branch table on a uniform grid in log x, so the walk finds its interval by direct indexing).
6. Smith-Watson-Topper life per closed cycle (none for sig_max <= 0), inverted by interpolation in a table of log(2N);
   Miner's sum is the damage per schedule.
"""
import json, sys
from math import log, exp
import numpy as np

EPS_S = 0.2     # MPa: turning points smaller than this next to the standstill ends are below the channel's resolution


def despike(x):
    r = x[1:-1] - 0.5*(x[:-2] + x[2:])
    rs = r[::7]                                  # robust statistics from every 7th sample (enough, and fast)
    s = 1.4826*np.median(np.abs(rs - np.median(rs)))
    lo, hi = np.percentile(x[::7], [0.1, 99.9])
    thr = max(12.0*s, 0.01*(hi - lo))
    bad = np.zeros(len(x), bool)
    bad[1:-1] = np.abs(r) > thr
    ar = np.zeros(len(x)); ar[1:-1] = np.abs(r)
    bad &= (ar >= np.roll(ar, 1)) & (ar >= np.roll(ar, -1))
    y = x.copy()
    k = np.where(bad)[0]
    y[k] = 0.5*(x[k - 1] + x[k + 1])
    return y, len(k)


def zero_offset(x, fs):
    m = int(2*fs)
    return float(np.median(np.r_[x[:m], x[-m:]]))


def core_points(S):
    nz = np.flatnonzero(S)
    s = S[nz[0] - 1:nz[-1] + 2]
    s = s[np.r_[True, s[1:] != s[:-1]]]
    d = np.diff(s)
    tp = s[np.r_[True, d[:-1]*d[1:] < 0, True]]
    i = 1
    while i < len(tp) - 1 and abs(tp[i]) < EPS_S:
        i += 1
    j = len(tp) - 2
    while j > i and abs(tp[j]) < EPS_S:
        j -= 1
    return tp[i:j + 1]


def junction(x_end, y_start):
    return [0.0] if (x_end > 0) == (y_start > 0) else []


def tables(m, xmax):
    E, K, n = m['E'], m['K'], m['n']
    sig = np.geomspace(1e-4, 4*xmax + 10, 20000)
    eps_c = sig/E + (sig/K)**(1/n)
    eps_d = sig/E + 2*(sig/(2*K))**(1/n)
    xc = np.sqrt(E*sig*eps_c)                    # x = Kt*S for which Neuber gives sig on the cyclic curve
    xd = np.sqrt(E*sig*eps_d)                    # x = Kt*dS for the doubled curve
    lxu = np.linspace(np.log(xd[0]), np.log(xd[-1]), 6000)
    lsu = np.interp(lxu, np.log(xd), np.log(sig))
    return (np.log(xc), np.log(sig)), (lxu, lsu)


def damage_from_schedule(SA, SB, n_a, Kt, m):
    E, K, n = m['E'], m['K'], m['n']
    A, B = core_points(SA), core_points(SB)
    ib = int(np.argmax(np.abs(B)))
    xmax = Kt*2*float(max(np.abs(A).max(), np.abs(B).max()))
    (lxc, lsc), (lxd_a, lsd_a) = tables(m, xmax)
    lxd, lsd = lxd_a.tolist(), lsd_a.tolist()
    x0, dl0, n_tab = lxd[0], lxd[1] - lxd[0], len(lxd)

    def first(x):                                # cyclic curve: stress for Kt*S = x
        return float(np.copysign(np.exp(np.interp(np.log(abs(x)), lxc, lsc)), x)) if x != 0 else 0.0

    stx, sts = [], []
    cyc_dx, cyc_smax = [], []
    add_dx, add_sm = cyc_dx.append, cyc_smax.append

    def feed(points):
        for P in points:
            while len(stx) >= 2:
                a, b = stx[-2], stx[-1]
                r = b - a if b > a else a - b
                if (P - b if P > b else b - P) < r:
                    break
                add_dx(r)
                sa, sb = sts[-2], sts[-1]
                add_sm(sb if sb > sa else sa)
                del stx[-2:], sts[-2:]
            if not stx:                          # first loading, or back on the cyclic curve
                stx.append(P); sts.append(first(P))
                continue
            o = stx[-1]
            dx = P - o if P > o else o - P
            if dx > 0.0:                         # branch stress range: table lookup (uniform grid in log x)
                L = log(dx)
                j = int((L - x0)/dl0)
                if j < 0:
                    d = dx
                else:
                    if j >= n_tab - 1:
                        j = n_tab - 2
                    f = (L - lxd[j])/(lxd[j + 1] - lxd[j])
                    d = exp(lsd[j] + f*(lsd[j + 1] - lsd[j]))
            else:
                d = 0.0
            stx.append(P)
            sts.append(sts[-1] + d if P > o else sts[-1] - d)

    xA = (Kt*A).tolist(); xB = (Kt*B).tolist()
    jba = [Kt*v for v in junction(B[-1], A[0])]
    jaa = [Kt*v for v in junction(A[-1], A[0])]
    jab = [Kt*v for v in junction(A[-1], B[0])]
    feed(xB[ib:])
    feed(jba)
    ranges = []                                  # (first cycle, last cycle + 1, extra copies) of a duty cycle that repeats
    prev = None
    k = 0
    while k < n_a - 1:
        lo = len(cyc_dx)
        feed(xA)
        feed(jaa)
        k += 1
        if prev is not None and stx == prev:     # same stack as after the previous copy: all remaining copies are alike
            ranges.append((lo, len(cyc_dx), n_a - 1 - k))
            k = n_a - 1
            break
        prev = list(stx)
    feed(xA)
    feed(jab)
    feed(xB[:ib + 1])
    mult = np.ones(len(cyc_dx))
    for lo, hi, extra in ranges:
        mult[lo:hi] += extra
    dx = np.asarray(cyc_dx); smax = np.asarray(cyc_smax)
    keep = (dx > 0) & (smax > 0)                 # SWT: no damage for sig_max <= 0
    dx, smax, mult = dx[keep], smax[keep], mult[keep]
    lxdn, lsdn = np.array(lxd), np.array(lsd)
    ds = np.exp(np.interp(np.log(dx), lxdn, lsdn))
    ds = np.where(np.log(dx) < lxdn[0], dx, ds)
    ea = 0.5*(ds/E + 2*(ds/(2*K))**(1/n))
    L = np.linspace(-2.0, 90.0, 20000)           # log(2N)
    sf, b, ef, c = m['sf'], m['b'], m['ef'], m['c']
    lP = np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L))   # decreasing in L
    Lc = np.interp(-np.log(smax*ea), -lP, L, left=L[0], right=np.inf)
    return float(np.sum(mult*2.0*np.exp(-Lc))), len(cyc_dx), len(xA), len(xB)


def load_record(d, fname, q, fs):
    x = np.load(f'{d}/{fname}').astype(np.float64)*q
    x, ns = despike(x)
    return x - zero_offset(x, fs), ns


def main(case_dir, out):
    cfg = json.load(open(f'{case_dir}/case.json'))
    ch = cfg['load_channel']; q = ch['kN_per_count']; fs = ch['sample_rate_Hz']
    sched = cfg['service']['schedule']
    (fa, n_a), (fb, n_b) = [(it['file'], it['repeats']) for it in sched]
    xa, nsa = load_record(case_dir, fa, q, fs)
    xb, nsb = load_record(case_dir, fb, q, fs)
    k = cfg['nominal_stress_MPa_per_kN']
    D, ncyc, na, nb = damage_from_schedule(xa*k, xb*k, n_a, cfg['stress_concentration_factor_Kt'], cfg['cyclic_properties'])
    json.dump({'damage_per_schedule': D}, open(out, 'w'))
    print(f'# spikes removed {nsa + nsb}, turning points A {na} B {nb}, cycles {ncyc}, damage per schedule {D:.6e}', file=sys.stderr)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
