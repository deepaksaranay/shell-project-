"""Exact damage per block (authoring only; slow on purpose: every reversal and every cycle is solved by root finding).

Nominal stress S = load x MPa_per_kN. Notch root by Neuber's rule with the cyclic Ramberg-Osgood curve
eps = sig/E + (sig/K')^(1/n'); the first loading follows the cyclic curve, every later branch is the Masing-doubled curve
from the reversal where it started, and a closed hysteresis loop returns the material to the branch it left (memory).
The block repeats end to start, so the stabilised state is analysed: the cyclic sequence is started at the reversal of
largest |S| (which lies on the cyclic curve) and closed by returning to it, and rainflow counting (ASTM E1049, three-point)
then leaves only closed cycles. Damage per cycle from Smith-Watson-Topper, sig_max eps_a = sf'^2/E (2N)^(2b) +
sf' ef' (2N)^(b+c), none when sig_max <= 0; Miner's sum.
"""
import numpy as np
from scipy.optimize import brentq


def reversal_points(x):
    """Turning points of the block repeated end to start, starting and ending at the sample of largest |x|."""
    i = int(np.argmax(np.abs(x)))
    s = np.concatenate([x[i:], x[:i + 1]])
    keep = np.r_[True, np.diff(s) != 0]
    s = s[keep]
    d = np.diff(s)
    turn = np.r_[True, d[:-1]*d[1:] < 0, True]
    return s[turn]


def neuber_cyclic(x, m):
    """sig with sig*eps(sig) = x^2/E on the cyclic curve; x = Kt*S (signed)."""
    E, K, n = m['E'], m['K'], m['n']
    a = abs(x)
    if a == 0.0:
        return 0.0
    f = lambda s: s*(s/E + (s/K)**(1/n)) - a*a/E
    if f(a) <= 0.0:                      # plastic term below double precision: elastic
        return x
    s = brentq(f, 0.0, a, xtol=1e-12, rtol=1e-14)
    return np.copysign(s, x)


def neuber_branch(dx, m):
    """(dsig, deps) on the doubled curve with dsig*deps = dx^2/E; dx = Kt*|dS| >= 0."""
    E, K, n = m['E'], m['K'], m['n']
    if dx == 0.0:
        return 0.0, 0.0
    f = lambda s: s*(s/E + 2*(s/(2*K))**(1/n)) - dx*dx/E
    if f(dx) <= 0.0:
        return dx, dx/E
    ds = brentq(f, 0.0, dx, xtol=1e-12, rtol=1e-14)
    return ds, ds/E + 2*(ds/(2*K))**(1/n)


def swt_cycles(smax, ea, m):
    """Cycles to crack initiation from SWT; inf when smax <= 0."""
    if smax <= 0.0 or ea <= 0.0:
        return np.inf
    E, sf, b, ef, c = m['E'], m['sf'], m['b'], m['ef'], m['c']
    P = smax*ea
    g = lambda L: np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L)) - np.log(P)
    lo, hi = -5.0, 120.0
    if g(lo) < 0:
        return 0.5*np.exp(lo)
    if g(hi) > 0:
        return np.inf
    L = brentq(g, lo, hi, xtol=1e-13)
    return 0.5*np.exp(L)


EPS_S = 0.2          # MPa: turning points smaller than this next to the standstill ends are below the load channel's resolution


def core_points(S, eps=EPS_S):
    """Turning points of one record, from the first to the last significant one (the standstill ends are cut off)."""
    nz = np.flatnonzero(S)
    s = S[nz[0] - 1:nz[-1] + 2]                       # one exact zero at each end
    s = s[np.r_[True, s[1:] != s[:-1]]]
    d = np.diff(s)
    tp = s[np.r_[True, d[:-1]*d[1:] < 0, True]]
    i = 1
    while i < len(tp) - 1 and abs(tp[i]) < eps:
        i += 1
    j = len(tp) - 2
    while j > i and abs(tp[j]) < eps:
        j -= 1
    return tp[i:j + 1]


def junction(x_end, y_start):
    """The standstill (zero load) between two records is a turning point exactly when the load approaches it and leaves it
    from the same side: [0.0], else nothing."""
    return [0.0] if (x_end > 0) == (y_start > 0) else []


class Walk:
    """Rainflow stack with the Neuber/Masing memory; feed turning points (nominal stress), read the damage."""

    def __init__(self, Kt, m):
        self.Kt, self.m = Kt, m
        self.stx, self.sts = [], []
        self.D = 0.0

    def feed(self, points):
        Kt, m = self.Kt, self.m
        stx, sts = self.stx, self.sts
        for P in points:
            P = float(P)
            while len(stx) >= 2 and abs(P - stx[-1]) >= abs(stx[-1] - stx[-2]):
                a, b_ = stx[-2], stx[-1]
                ds, de = neuber_branch(Kt*abs(b_ - a), m)
                self.D += 1.0/swt_cycles(max(sts[-1], sts[-2]), de/2, m)
                del stx[-2:], sts[-2:]
            if not stx:                               # first loading, or back on the cyclic curve
                stx.append(P)
                sts.append(neuber_cyclic(Kt*P, m))
                continue
            o, so = stx[-1], sts[-1]
            ds, de = neuber_branch(Kt*abs(P - o), m)
            stx.append(P)
            sts.append(so + np.sign(P - o)*ds)


def damage_schedule(SA, SB, n, Kt, m, fast_forward=True):
    """Damage per schedule repetition: n duty cycles A, then one severe event B, repeated end to start. The stabilised
    (repeated) state is analysed: the circular sequence starts at the largest |S|, which lies in B."""
    A, B = core_points(SA), core_points(SB)
    ib = int(np.argmax(np.abs(B)))
    assert abs(B[ib]) > np.abs(A).max(), 'the largest load must be in the severe event'
    w = Walk(Kt, m)
    w.feed(B[ib:])
    w.feed(junction(B[-1], A[0]))
    jaa = junction(A[-1], A[0])
    prev = None
    k = 0
    while k < n - 1:                                   # the first n - 1 duty cycles, each followed by the standstill
        before = w.D
        w.feed(A)
        w.feed(jaa)
        k += 1
        if fast_forward and prev is not None and w.stx == prev:
            w.D += (w.D - before)*(n - 1 - k)          # identical memory state: every remaining copy does the same
            k = n - 1
            break
        prev = list(w.stx)
    w.feed(A)                                          # the last duty cycle
    w.feed(junction(A[-1], B[0]))
    w.feed(B[:ib + 1])
    return w.D


def damage(S, Kt, m, return_cycles=False):
    R = reversal_points(np.asarray(S, float))
    st_S = [R[0]]
    st_sig = [neuber_cyclic(Kt*R[0], m)]
    D = 0.0
    cyc = []
    for P in R[1:]:
        while len(st_S) >= 2 and abs(P - st_S[-1]) >= abs(st_S[-1] - st_S[-2]):
            a, b_ = st_S[-2], st_S[-1]
            sa, sb = st_sig[-2], st_sig[-1]
            ds, de = neuber_branch(Kt*abs(b_ - a), m)
            N = swt_cycles(max(sa, sb), de/2, m)
            D += 1.0/N
            if return_cycles:
                cyc.append((a, b_, sa, sb, de, N))
            del st_S[-2:], st_sig[-2:]
        if not st_S:
            # the largest |S| was reached again: the material is back on the cyclic curve there
            st_S.append(P)
            st_sig.append(neuber_cyclic(Kt*P, m))
            continue
        o, so = st_S[-1], st_sig[-1]
        ds, de = neuber_branch(Kt*abs(P - o), m)
        st_S.append(P)
        st_sig.append(so + np.sign(P - o)*ds)
    return (D, cyc) if return_cycles else D
