"""Builds the visible cases and the expected damages (authoring only).

    python generate.py            (run from anywhere; paths are relative to the task directory)

Visible cases -> environment/data/cases/<V>/{case.json, duty_counts.npy, event_counts.npy} and environment/data/visible_damage.json.
Hidden cases are not written: tests/cases.py regenerates them at test time from the same code; only their expected
damage is stored, in tests/expected_hidden.json. The damage is the exact one (truth.py: root finding for every branch and
every cycle) of the true load, i.e. without the load-cell zero offset, the telemetry corruption and the ADC rounding.
"""
import json, os, sys
from pathlib import Path
import numpy as np

TOP = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(TOP/'tests'), str(Path(__file__).parent)]
import cases, truth


def damage_of(cfg, b):
    f = cfg['MPa_per_kN']
    return truth.damage_schedule(b['load_A']*f, b['load_B']*f, cfg['n_A'], cfg['Kt'], cases.MATERIALS[cfg['material']])


def main():
    vis = {}
    for name, cfg in cases.VISIBLE.items():
        d = TOP/'environment'/'data'/'cases'/name
        d.mkdir(parents=True, exist_ok=True)
        b = cases.build(cfg)
        np.save(d/'duty_counts.npy', b['counts_A'])
        np.save(d/'event_counts.npy', b['counts_B'])
        (d/'case.json').write_text(json.dumps(cases.case_json(cfg, b['q']), indent=2) + '\n')
        vis[name] = damage_of(cfg, b)
        print(name, len(b['counts_A']), len(b['counts_B']), vis[name], flush=True)
    (TOP/'environment'/'data'/'visible_damage.json').write_text(json.dumps({'damage_per_schedule': vis}, indent=2) + '\n')
    hid, info = {}, {}
    for name, cfg in cases.HIDDEN.items():
        b = cases.build(cfg)
        hid[name] = damage_of(cfg, b)
        info[name] = {'samples_duty_cycle': int(len(b['counts_A'])), 'samples_event': int(len(b['counts_B'])), 'repeats': cfg['n_A'],
                      'material': cfg['material'], 'Kt': cfg['Kt'], 'zero_offset_kN': cfg['zero_offset_kN'],
                      'spikes': [cfg['A'].get('spikes'), cfg['B'].get('spikes')], 'damage_per_schedule': hid[name]}
        print(name, len(b['counts_A']), hid[name], flush=True)
    (TOP/'tests'/'expected_hidden.json').write_text(json.dumps({'damage_per_schedule': hid}, indent=2) + '\n')
    vinfo = {n: {'material': c['material'], 'zero_offset_kN': c['zero_offset_kN'], 'repeats': c['n_A'],
                 'spikes': [c['A'].get('spikes'), c['B'].get('spikes')], 'damage_per_schedule': vis[n]} for n, c in cases.VISIBLE.items()}
    (TOP/'authoring'/'evidence'/'generator_truth.json').write_text(json.dumps({'visible': vinfo, 'hidden': info}, indent=2) + '\n')


if __name__ == '__main__':
    main()
