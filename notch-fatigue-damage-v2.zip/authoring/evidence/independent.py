"""Independent program (no code shared with solution/predict.py or the generator), same interface:

    python independent.py <case_dir> <output_json>

Different choices from the reference:
* corrupted samples found from the pattern of second differences (large at the sample, opposite sign and about half the
  size at both neighbours; a real peak has neighbours of the same sign), threshold 2 % of the load range;
* the load-cell zero from the mode of the readings (the standstill readings repeat one value), not from the ends;
* the repeated schedule is not walked with a state-equality test. A duty cycle that is run again from a settled memory
  does the same each time, so the damage of the schedule is linear in the number of duty cycles once the first copy is
  over: D(n) = D(2) + (n - 2) (D(3) - D(2)), with D(m) the damage of the circular sequence B, A x m (started at the largest
  load, in B), each walked in full;
* the rainflow walk records, for every turning point, the point its branch started from; Neuber's rule and the SWT life
  are then solved by vectorised Newton iterations on all branches and cycles at once (no interpolation tables).
"""
import json, sys
import numpy as np


def clean(x):
    d2 = np.zeros(len(x))
    d2[1:-1] = x[:-2] - 2*x[1:-1] + x[2:]
    span = np.subtract(*np.percentile(x, [99.9, 0.1]))
    thr = max(0.02*span, 1e-9)
    l, r = np.roll(d2, 1), np.roll(d2, -1)
    bad = (np.abs(d2) > thr) & (np.sign(l) == -np.sign(d2)) & (np.sign(r) == -np.sign(d2)) \
        & (np.abs(l) > 0.3*np.abs(d2)) & (np.abs(r) > 0.3*np.abs(d2))
    bad[[0, -1]] = False
    k = np.where(bad)[0]
    y = x.copy()
    y[k] = 0.5*(x[k - 1] + x[k + 1])
    return y, len(k)


def zero(x, q):
    v, cnt = np.unique(np.rint(x/q).astype(np.int64), return_counts=True)
    return float(v[np.argmax(cnt)]*q)


def significant_turning_points(s, eps=0.2):
    """Turning points of a record between its standstill ends, from the first to the last one larger than eps (MPa)."""
    nz = np.flatnonzero(s)
    w = s[nz[0] - 1:nz[-1] + 2]
    w = w[np.r_[True, w[1:] != w[:-1]]]
    dw = np.diff(w)
    tp = w[np.r_[True, dw[:-1]*dw[1:] < 0, True]]
    big = np.flatnonzero(np.abs(tp[1:-1]) >= eps) + 1
    return tp[big[0]:big[-1] + 1]


def standstill(x_last, y_first):
    """A zero-load turning point between two records exists if the load comes to rest and leaves from the same side."""
    return np.array([0.0]) if x_last*y_first > 0 else np.empty(0)


def newton_sig(target, E, K, n, doubled):
    """Solve sig*eps(sig) = target (> 0) for sig, vectorised Newton on log(sig)."""
    a = 2.0 if doubled else 1.0
    kk = 2*K if doubled else K
    u = np.log(np.sqrt(target*E))
    for _ in range(60):
        s = np.exp(u)
        p = a*(s/kk)**(1/n)
        f = np.log(s*(s/E + p)) - np.log(target)
        df = 1 + (s/E + p/n)/(s/E + p)
        u_new = u - f/df
        if np.max(np.abs(u_new - u)) < 1e-13:
            u = u_new; break
        u = u_new
    s = np.exp(u)
    return s, s/E + a*(s/kk)**(1/n)


def swt_life(P, E, sf, b, ef, c):
    A, B = sf*sf/E, sf*ef
    L = np.full(P.shape, 10.0)
    for _ in range(200):
        g1, g2 = A*np.exp(2*b*L), B*np.exp((b + c)*L)
        f = np.log(g1 + g2) - np.log(P)
        df = (2*b*g1 + (b + c)*g2)/(g1 + g2)
        Ln = np.clip(L - f/df, -10, 200)
        if np.max(np.abs(Ln - L)) < 1e-12:
            L = Ln; break
        L = Ln
    return np.exp(L)


def circular_damage(T, E, K, n, m):
    """Damage of the closed circular sequence T (nominal-stress-times-Kt turning points; T[0] == T[-1] is the largest)."""
    Tl = T.tolist()
    origin = np.full(len(T), -1, np.int64)       # -1: on the cyclic curve
    stack = []
    cyc = []
    for i, p in enumerate(Tl):
        while len(stack) >= 2 and abs(p - Tl[stack[-1]]) >= abs(Tl[stack[-1]] - Tl[stack[-2]]):
            cyc.append((stack[-2], stack[-1])); del stack[-2:]
        if stack:
            origin[i] = stack[-1]
        stack.append(i)
        if len(stack) == 1:
            origin[i] = -1
    sig = np.zeros(len(T))
    oc = origin < 0
    sig[oc] = np.sign(T[oc])*newton_sig(T[oc]**2/E, E, K, n, False)[0]
    br = np.where(origin >= 0)[0]
    dx = np.abs(T[br] - T[origin[br]])
    dsg = np.zeros(len(br))
    nz = dx > 0
    dsg[nz] = newton_sig(dx[nz]**2/E, E, K, n, True)[0]
    sgn = np.sign(T[br] - T[origin[br]])
    sl, ol = sig.tolist(), origin.tolist()
    for k, i in enumerate(br.tolist()):
        sl[i] = sl[ol[i]] + sgn[k]*dsg[k]
    sig = np.array(sl)
    C = np.array(cyc, np.int64)
    a, b_ = C[:, 0], C[:, 1]
    rng = np.abs(T[b_] - T[a])
    smax = np.maximum(sig[a], sig[b_])
    keep = (smax > 0) & (rng > 0)
    ds, de = newton_sig(rng[keep]**2/E, E, K, n, True)
    twoN = swt_life(smax[keep]*de/2, E, m['sf'], m['b'], m['ef'], m['c'])
    return float(np.sum(2.0/twoN))


def main(d, out):
    cfg = json.load(open(f'{d}/case.json'))
    ch = cfg['load_channel']; q = ch['kN_per_count']
    (fa, n_a), (fb, _) = [(it['file'], it['repeats']) for it in cfg['service']['schedule']]
    m = cfg['cyclic_properties']; Kt = cfg['stress_concentration_factor_Kt']
    E, K, n = m['E'], m['K'], m['n']
    rec, nsp = [], 0
    for f in (fa, fb):
        x = np.load(f'{d}/{f}').astype(float)*q
        x, k = clean(x); nsp += k
        x = x - zero(x, q)
        rec.append(Kt*significant_turning_points(cfg["nominal_stress_MPa_per_kN"]*x))
    A, B = rec
    ib = int(np.argmax(np.abs(B)))
    unit = np.r_[A, standstill(A[-1], A[0])]
    to_a = standstill(B[-1], A[0]); to_b = standstill(A[-1], B[0])

    def damage(mcopies):
        T = np.concatenate([B[ib:], to_a] + [unit]*(mcopies - 1) + [A, to_b, B[:ib + 1]])
        return circular_damage(T, E, K, n, m)

    d2, d3 = damage(2), damage(3)
    D = d2 + (n_a - 2)*(d3 - d2)
    json.dump({'damage_per_schedule': float(D)}, open(out, 'w'))
    print(f'# spikes {nsp}, damage {D:.6e}', file=sys.stderr)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
