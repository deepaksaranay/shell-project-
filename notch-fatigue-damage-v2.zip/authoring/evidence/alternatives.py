"""Shortcut programs, each a complete submission with the same interface as solution/predict.py:

    python alternatives.py <route> <case_dir> <output_json>

Routes (one change each from the reference):
  spikes_kept                        telemetry corruption not removed
  spike_threshold_20kN               corrupted samples found with a fixed 20 kN threshold (enough for the visible records)
  zero_offset_kept                   load-cell zero at standstill not removed
  damage_per_record_summed           n x (damage of the duty cycle repeated alone) + (damage of the severe event repeated
                                     alone): each record on its own, the memory carried from one record to the next ignored
  expanded_schedule_without_fast_forward   every duty cycle of the schedule walked in turn (correct, but 60 walks of the
                                     duty cycle with the reference's own fast table walk)
"""
import os, sys
from math import log, exp
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'solution'))
import predict as P


def single_record_damage(S, Kt, m):
    """Damage of one record repeated alone (circular, started at its largest |S|)."""
    E, K, n = m['E'], m['K'], m['n']
    core = P.core_points(S)
    ib = int(np.argmax(np.abs(core)))
    pts = np.r_[core[ib:], core[:ib + 1]]
    (lxc, lsc), (lxd_a, lsd_a) = P.tables(m, Kt*2*float(np.abs(core).max()))
    lxd, lsd = lxd_a.tolist(), lsd_a.tolist()
    x0, dl0, nt = lxd[0], lxd[1] - lxd[0], len(lxd)
    first = lambda x: float(np.copysign(np.exp(np.interp(np.log(abs(x)), lxc, lsc)), x)) if x != 0 else 0.0
    stx, sts, cdx, csm = [], [], [], []
    for p in (Kt*pts).tolist():
        while len(stx) >= 2 and abs(p - stx[-1]) >= abs(stx[-1] - stx[-2]):
            cdx.append(abs(stx[-1] - stx[-2])); csm.append(max(sts[-1], sts[-2])); del stx[-2:], sts[-2:]
        if not stx:
            stx.append(p); sts.append(first(p)); continue
        o = stx[-1]
        dx = abs(p - o)
        if dx > 0:
            L = log(dx); j = int((L - x0)/dl0)
            if j < 0:
                dd = dx
            else:
                j = min(j, nt - 2); f = (L - lxd[j])/(lxd[j + 1] - lxd[j]); dd = exp(lsd[j] + f*(lsd[j + 1] - lsd[j]))
        else:
            dd = 0.0
        stx.append(p); sts.append(sts[-1] + dd if p > o else sts[-1] - dd)
    dx, sm = np.array(cdx), np.array(csm)
    k = (dx > 0) & (sm > 0)
    dx, sm = dx[k], sm[k]
    ds = np.exp(np.interp(np.log(dx), lxd_a, lsd_a)); ds = np.where(np.log(dx) < lxd_a[0], dx, ds)
    ea = 0.5*(ds/E + 2*(ds/(2*K))**(1/n))
    Lg = np.linspace(-2.0, 90.0, 20000)
    lP = np.log(m['sf']**2/E*np.exp(2*m['b']*Lg) + m['sf']*m['ef']*np.exp((m['b'] + m['c'])*Lg))
    Lc = np.interp(-np.log(sm*ea), -lP, Lg, left=Lg[0], right=np.inf)
    return float(np.sum(2.0*np.exp(-Lc)))


def main(route, d, out):
    import json
    if route == 'spikes_kept':
        P.despike = lambda x: (x, 0)
    elif route == 'spike_threshold_20kN':
        def despike(x):
            r = np.zeros(len(x)); r[1:-1] = x[1:-1] - 0.5*(x[:-2] + x[2:])
            k = np.where(np.abs(r) > 20.0)[0]
            k = k[(k > 0) & (k < len(x) - 1)]
            k = k[np.abs(r[k]) >= np.maximum(np.abs(r[k - 1]), np.abs(r[k + 1]))]
            y = x.copy(); y[k] = 0.5*(x[k - 1] + x[k + 1])
            return y, len(k)
        P.despike = despike
    elif route == 'zero_offset_kept':
        # the standstill is still found (against the true zero) but the stresses keep the offset: the load is read as
        # offset + load, so the mean stress is shifted by the offset
        import json as _j
        _cfg = _j.load(open(f'{d}/case.json')); _ch = _cfg['load_channel']
        _k = _cfg['nominal_stress_MPa_per_kN']
        _z = P.zero_offset(np.load(f"{d}/{_cfg['service']['schedule'][0]['file']}").astype(np.float64)*_ch['kN_per_count'], _ch['sample_rate_Hz'])
        _core, _junc = P.core_points, P.junction
        P.core_points = lambda S: _core(S) + _z*_k
        P.junction = lambda a, b: [_z*_k] if _junc(a - _z*_k, b - _z*_k) else []
    elif route == 'expanded_schedule_without_fast_forward':
        src = open(P.__file__).read()
        assert 'prev is not None and stx == prev' in src
        ns = {'__name__': 'predict_noff'}
        exec(compile(src.replace('prev is not None and stx == prev', 'False'), 'predict_noff', 'exec'), ns)
        P.damage_from_schedule = ns['damage_from_schedule']
    if route == 'damage_per_record_summed':
        cfg = json.load(open(f'{d}/case.json')); ch = cfg['load_channel']
        (fa, n_a), (fb, _) = [(it['file'], it['repeats']) for it in cfg['service']['schedule']]
        k = cfg['nominal_stress_MPa_per_kN']; Kt = cfg['stress_concentration_factor_Kt']; m = cfg['cyclic_properties']
        xa, _ = P.load_record(d, fa, ch['kN_per_count'], ch['sample_rate_Hz'])
        xb, _ = P.load_record(d, fb, ch['kN_per_count'], ch['sample_rate_Hz'])
        D = n_a*single_record_damage(xa*k, Kt, m) + single_record_damage(xb*k, Kt, m)
        json.dump({'damage_per_schedule': D}, open(out, 'w'))
    else:
        P.main(d, out)


if __name__ == '__main__':
    main(*sys.argv[1:4])
