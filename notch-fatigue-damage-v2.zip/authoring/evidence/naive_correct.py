"""A correct but unoptimised program (same physics and the same answers as solution/predict.py, to 0.01 %): plain Python
loops over the samples to clean the records and find the turning points, the whole schedule expanded (every duty cycle
walked in turn) and a root finder (scipy brentq) for every branch of Neuber's rule and every cycle's SWT life.

    python naive_correct.py <case_dir> <output_json>

On the visible cases (a duty cycle repeated 4 times) it finishes in seconds and gives the visible damages; on the hidden
cases (60 repeats, 0.3 million turning points per duty cycle) it runs for many minutes.
"""
import json, sys
import numpy as np
from scipy.optimize import brentq


def main(d, out):
    cfg = json.load(open(f'{d}/case.json'))
    ch = cfg['load_channel']; q = ch['kN_per_count']; fs = ch['sample_rate_Hz']
    m = cfg['cyclic_properties']; Kt = cfg['stress_concentration_factor_Kt']
    E, K, n, sf, b, ef, c = (m[k] for k in ('E', 'K', 'n', 'sf', 'b', 'ef', 'c'))
    (fa, n_a), (fb, _) = [(it['file'], it['repeats']) for it in cfg['service']['schedule']]

    def record(fn):
        x = (np.load(f'{d}/{fn}').astype(float)*q).tolist()
        N = len(x)
        r = [0.0]*N
        for i in range(1, N - 1):
            r[i] = x[i] - 0.5*(x[i - 1] + x[i + 1])
        rr = np.array(r[1:-1])
        s = 1.4826*float(np.median(np.abs(rr[::7] - np.median(rr[::7]))))
        lo, hi = np.percentile(x[::7], [0.1, 99.9])
        thr = max(12*s, 0.01*(hi - lo))
        y = list(x)
        for i in range(1, N - 1):
            if abs(r[i]) > thr and abs(r[i]) >= abs(r[i - 1]) and abs(r[i]) >= abs(r[i + 1]):
                y[i] = 0.5*(x[i - 1] + x[i + 1])
        k = int(2*fs)
        z = float(np.median(y[:k] + y[-k:]))
        S = [(v - z)*cfg['nominal_stress_MPa_per_kN'] for v in y]
        nz = [i for i, v in enumerate(S) if v != 0.0]
        S = S[nz[0] - 1:nz[-1] + 2]
        pts = [S[0]]
        for v in S[1:]:
            if v != pts[-1]:
                pts.append(v)
        tp = [pts[0]] + [pts[j] for j in range(1, len(pts) - 1) if (pts[j] - pts[j - 1])*(pts[j + 1] - pts[j]) < 0] + [pts[-1]]
        i = 1
        while i < len(tp) - 1 and abs(tp[i]) < 0.2:
            i += 1
        j = len(tp) - 2
        while j > i and abs(tp[j]) < 0.2:
            j -= 1
        return tp[i:j + 1]

    A, B = record(fa), record(fb)
    ib = max(range(len(B)), key=lambda i: abs(B[i]))

    def join(xe, ys):
        return [0.0] if (xe > 0) == (ys > 0) else []

    seq = B[ib:] + join(B[-1], A[0])
    for _ in range(n_a - 1):
        seq += A + join(A[-1], A[0])
    seq += A + join(A[-1], B[0]) + B[:ib + 1]

    def first(xx):
        a = abs(xx)
        if a == 0:
            return 0.0
        f = lambda q_: q_*(q_/E + (q_/K)**(1/n)) - a*a/E
        return np.copysign(brentq(f, 0.0, a) if f(a) > 0 else a, xx)

    def branch(dx):
        if dx == 0:
            return 0.0
        f = lambda q_: q_*(q_/E + 2*(q_/(2*K))**(1/n)) - dx*dx/E
        return brentq(f, 0.0, dx) if f(dx) > 0 else dx

    def life(smax, ea):
        if smax <= 0:
            return float('inf')
        g = lambda L: np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L)) - np.log(smax*ea)
        if g(120.0) > 0:
            return float('inf')
        return 0.5*np.exp(brentq(g, -5.0, 120.0)) if g(-5.0) > 0 else 0.5

    stx, sts = [], []
    D = 0.0
    for P in seq:
        P = Kt*P
        while len(stx) >= 2 and abs(P - stx[-1]) >= abs(stx[-1] - stx[-2]):
            ds = branch(abs(stx[-1] - stx[-2]))
            D += 1.0/life(max(sts[-1], sts[-2]), 0.5*(ds/E + 2*(ds/(2*K))**(1/n)))
            del stx[-2:], sts[-2:]
        if not stx:
            stx.append(P); sts.append(first(P)); continue
        o = stx[-1]
        stx.append(P); sts.append(sts[-1] + np.sign(P - o)*branch(abs(P - o)))
    json.dump({'damage_per_schedule': float(D)}, open(out, 'w'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
