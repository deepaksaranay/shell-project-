# notch-fatigue-damage

A durability team needs a program that turns the measured load records of a notched machine part into the fatigue damage that one pass through its service schedule does at the notch root. The solver writes `/app/fatigue/predict.py`. The tests run it on eight hidden cases, each run limited to 6 s on one CPU, and require the damage per schedule of every case to be within the bound of the simulation's damage. Reward is binary: all eight cases must pass.

A case has two load records, each one run of the machine from standstill to standstill: the **duty cycle** (a normal run, repeated 60 times in the hidden cases, 4 in the visible ones) and the **severe event** (a rare run whose largest load is 1.6–2.0 times that of the duty cycle), run once. The schedule, the duty cycle repeated, then the event, repeats end to start.

The method is stated in the instruction: Neuber's rule with the cyclic Ramberg-Osgood curve, Masing branches with material memory, rainflow counting of the whole service in the stabilised state, Smith-Watson-Topper life (no damage for σ_max ≤ 0) and Miner's sum. The difficulty is in applying it to real records, and to a schedule, fast enough.

## Difficulty

**Who does this work:** durability and fatigue engineers in the automotive, rail, aerospace and machinery industries. They turn load-cell and strain-gauge records of instrumented machines into notch damage (local strain approach after SAE/ASTM practice), and a service is a schedule of recorded duty cycles with occasional severe events, not one record.

**The decisive part: the memory of the severe event reaches into the duty cycles.** The material remembers the largest loops. A duty cycle that follows the event is walked on top of the event's residue, and its biggest cycles pair with the event's loops instead of with themselves; the same duty cycle run again straight after itself behaves differently. So the damage of the schedule is not the sum of the damages of its records. Adding them (n × the duty cycle repeated alone + the event repeated alone) misses by 0.8–57 % on the visible cases and by 7.4–285 % on the hidden ones (the 60-fold repeat shrinks the effect of the event only where the duty cycle's own damage dominates; it is largest where the event dominates).

**Speed: the schedule cannot be expanded.** A hidden duty cycle has 0.27–0.34 million turning points, so the schedule has 16–21 million. A correct program that walks the whole schedule, even with the reference's own tight table-lookup walk, needs 14 s on the first hidden case (`expanded_schedule_without_fast_forward`), and a plain-Python version with a root finder for every branch and cycle (`naive_correct.py`) needs minutes. It gives the visible damages exactly, so the visible cases do not show the problem. The way out is to use the structure of the memory. The rainflow stack after a duty cycle is a state. A duty cycle run again from the same state does exactly what it did the time before, closes the same cycles and leaves the same state. The first copy after the event is different, the second and every later copy identical: the stack after copy 2 equals the stack after copy 1 in all 13 cases. The damage of the schedule is therefore the damage of the first copy, plus that of the second copy for every remaining one, plus the rest of the schedule. The reference follows the walk only until the stack repeats and counts the cycles of the repeating copy with a multiplicity (about 1.0–1.2 s per case); the independent program gets the same result by walking the circular schedule with 2 and with 3 duty cycles and extrapolating linearly.

**Hidden effects in the records, unflagged (each occurs in the visible examples):**

1. **Load-cell zero offset.** Every record starts and ends at standstill, where the true load is zero, but the reading there is not (−4.2 to +3.1 kN in the hidden cases, −1.2 to +1.75 kN in the visible). The offset shifts the mean stress and with it the SWT damage. Leaving it in misses the hidden cases by 0.7–2.7 %, and fails because of the larger ones.
2. **Telemetry corruption.** The channel comes over a wireless telemetry link, and single samples are replaced by unrelated readings. A real sample of this band-limited, densely sampled load lies close to its neighbours; a corrupted one does not. Kept as data, the spikes add cycles: +18 % and +22 % in the two visible cases that have them with large spikes, +212 % on the hidden case H7 and +38 % on H1.

**The hidden cases are deliberately unlike the visible ones** (`tests/cases.py`, `HIDDEN`; the visible configurations are `VISIBLE` in the same file):

| | Visible (5 cases) | Hidden (8 cases) |
|---|---|---|
| Materials | SAE 1045, AISI 4340, SAE 1020 steels | also Al 7075-T6, Al 2024-T3, Ti-6Al-4V (never seen) |
| Largest elastic notch stress Kt·S (duty cycle / event) | 480–1480 / 880–2910 MPa | 790–2080 / 1370–4010 MPa (beyond the visible range) |
| Duty cycle repeats | 4 | 60 |
| Records | 0.2–0.6 million samples (1 and 2 kHz), event 0.05–0.11 million | 2.8–3.5 million samples at 2 kHz with high-frequency vibration, event 0.19–0.26 million |
| Severe event | tensile pulse first (or compressive first for a compressive duty cycle) | compressive-first events for tensile duty cycles and the other way round, mean-load signs mixed |
| Mean load | mostly tensile, one negative (V5) | also mostly compressive (H6) and high tensile preload (H7) |
| Telemetry spikes | 5–8 per record, 50–120 kN readings | 6–30 per record, 5–90 kN readings, some close to the signal |
| Zero offset | −1.2 to +1.75 kN | −4.2 to +3.1 kN |

No visible case appears in the hidden set. A program that is exact on every visible case, walking the schedule in full, times out on every hidden one.

**Instrument noise and hidden data:** the hidden records are generated inside the verifier from `tests/cases.py` and never reach the solver's container. The program runs as an unprivileged user that cannot read `/tests`.

## Reference solution

`solution/solve.sh` installs `solution/predict.py` as `/app/fatigue/predict.py` and runs it on the visible cases:

1. Counts → kN. Corrupted samples: the half second difference r = x[i] − (x[i−1] + x[i+1])/2 is compared with 12 robust standard deviations of r (at least 1 % of the load range), and a flagged local maximum of |r| is replaced by the mean of its neighbours.
2. Zero offset: the median reading over the first and last 2 s of each record (standstill), subtracted.
3. Turning points of each record between its first and last significant ones (larger than 0.2 MPa). The standstill between two records is a turning point exactly when the load approaches it and leaves it from the same side.
4. The circular schedule B, A × n, B is started at the largest |S| (in the severe event, which is the global maximum by construction), the state in which the repeated schedule is stabilised.
5. A rainflow stack carries the notch-root stress of every turning point: the cyclic curve at the start, the Masing branch from the point where each branch began, memory through the stack. The walk follows duty cycles until the stack after one equals the stack after the one before, and the cycles closed by that copy get the multiplicity of all remaining copies. Neuber is inverted by interpolation in a table on a uniform grid in log x built once from the explicit forward relation.
6. SWT life per closed cycle (none for σ_max ≤ 0), inverted in a table of log(2N); Miner's sum.

It reproduces the exact damage (root finding for every branch and cycle, no fast-forward, `authoring/provenance/truth.py`; the fast-forward is checked against the full expansion in the visible cases to 1e-15) to within 0.005 % on all 13 cases.

## Verification

`tests/test_fatigue.py` generates the eight hidden cases and runs the program on each:

- as `nobody`, with OMP/OpenBLAS/MKL/NumExpr threads set to 1;
- in its own session (process group), with its output in files, not pipes; the whole group is killed when the run ends or times out, so no child process can outlive the run;
- with a 6 s timeout per run.

A run that is killed, exits with an error, or writes no valid `{"damage_per_schedule": <finite positive number>}` fails its test. Otherwise the damage must be within the bound of the expected damage (`tests/expected_hidden.json`, from the exact solution of the true loads). The instruction states the limit and that each damage must meet a relative-error requirement; the size of the bound (1 %) appears in no file the solver sees. There is a separately named test for each hidden case, plus one test that the program file exists. Reward is 1 only if all nine pass.

**Calibration:** `authoring/evidence/score_submissions.py` grades complete submissions with the unchanged test file through pytest and the CTRF plugin, as `tests/test.sh` does. Each keeps its `reward.txt` and `ctrf.json`, and the summary is in `authoring/evidence/grading_results.txt`. Errors and run times of every program on every case are in `authoring/evidence/case_errors.txt`.

**Reward 1 (9/9 tests):**

| Submitter | Largest error (13 cases) | Run time on hidden cases |
|---|---|---|
| Reference | 0.005 % | 0.85–1.11 s |
| `authoring/evidence/independent.py`, an independent program with no shared code: spikes found from the sign pattern of second differences, zero from the most frequent reading, the circular schedule walked with 2 and with 3 duty cycles and extrapolated linearly (no state-equality test), vectorised Newton for Neuber and SWT | 0.006 % | 1.8–2.4 s |
| Spikes removed with a fixed 20 kN threshold, otherwise as the reference | 0.0 % | as the reference |

The bound (1 %) is 150 times the largest error of the two correct programs, which differ in every step. The nearest wrong route (the zero offset kept) misses by 0.7 % on its best case and by 1.0–2.7 % on the others.

**Reward 0:**

| Submitter | Tests passed | What fails |
|---|---|---|
| Correct but unoptimised (`naive_correct.py`): Python loops, the schedule expanded, a root finder per branch and cycle | 1/9 | every hidden case times out (more than 2 minutes); visible damages exact |
| Correct and tight, but the schedule expanded without the fast-forward (`expanded_schedule_without_fast_forward`) | 1/9 | every hidden case times out (11.8–14.7 s against 6 s); visible damages exact |
| Damage of each record on its own, summed (n × duty cycle + event) | 1/9 | all eight, 7.4–285 % |
| Load-cell zero offset kept | 2/9 | seven cases, 1.0–2.7 % (H2 passes at 0.7 %) |
| Telemetry spikes kept | 7/9 | H1 (+38 %) and H7 (+212 %) |

Every route that fails on the hidden set also misses at least one visible case by more than the bound, apart from the timing: the visible schedules are short enough for the full expansion.

**Trivial answers:** the hidden damages range from 4.1 to 119 per schedule. With a 1 % bound no constant passes more than one case, and the reward needs all eight.

The generator settings of every case (offsets, spikes, repeats, materials) and the damages are in `authoring/evidence/generator_truth.json`.
