# battery-pad-preload

A battery-module designer needs to know how much preload an EPDM compression pad keeps after long service. The pad sits between the cells of an EV battery module: 5.33 mm thick, 40 × 40 mm, compressed by 10 % between steel end plates and tie rods. The answer is needed both hot and after the module has been moved into cold air.

The data are seven compression-stress-relaxation (CSR) logs after ISO 3384: five on the production pad at 40–120 °C for 300–3000 h, and two on a thinner 1.78 mm pad of the same compound at 100 and 120 °C. The campaign file also gives the compound's thermal expansion (datasheet, dilatometer). It also states the ageing mechanism from the datasheet: chain scission, with intermittent and continuous stress relaxation coinciding. No new crosslinks form in the compressed state, so ageing lowers the stiffness of the whole network alike. This fixes how the aged pad answers a later change of compression, which the logs alone do not show.

The solver must give F/F0 at four service conditions:

- S1: 40 °C for 5 years, read at 40 °C;
- S4: 23 °C for 10 years, read at 23 °C;
- S2: 70 °C for 1 year, read 24 h after the module is moved into 23 °C air;
- S3: an accelerated-ageing qualification of 2000 h at 100 °C, followed by a −40 °C cold soak and a reading 4 h later.

The cold-soak preload decides whether the cell stack stays clamped in winter after a hot duty cycle. The logs and the truth come from a seeded model (`authoring/provenance/generate.py`).

## Difficulty

**Who does this work:** mechanical engineers designing battery modules and packs at automotive and energy-storage suppliers. They qualify a pad compound from CSR tests and predict the stack preload at the end of the design life: at the operating temperature, after cooling and at a winter cold soak. Too little preload lets the cells move and swell unevenly, which costs cycle life and loosens the electrical connections.

**The decisive physics: the thermal strain has to be superposed in time.** The rubber expands about 17 times more than the steel, so heating raises the compression and cooling lowers it. At 10 % compression this is large: the compression is 0.1135 at 100 °C and 0.0886 at −40 °C. The pad is linear-viscoelastic, so each change of compression relaxes from the moment it is applied (Boltzmann superposition in WLF reduced time):

- the extra compression gained on heating relaxes at the service temperature like a fresh load;
- the compression lost on cooling to −40 °C acts through the almost unrelaxed modulus, because relaxation is frozen in the cold.

Scaling the relaxed force by the compression ratio and the entropic factor (T + 273.15)/296.15 is the usual multiplicative shortcut. It fits every log at the logger noise, but it removes the cold-soak compression loss at the relaxed modulus. The S3 reading then comes out 17 % too high (8.6 times the 2 % bound), and S2 2.5 % too high.

Two coarser shortcuts are worse. Taking the measured heating step off as reversible misses by up to 62 %. Taking off only the entropic factor misses by up to 50 %.

The superposition is not hidden: every log shows it in the first hours at temperature. The force jumps with the pad temperature and then falls back by 20–60 N within about 2 h, as the fresh thermal increment relaxes on its own clock. A model fitted to these transients, with the jig and pad heating lags, carries over to the cold soak. The reference reproduces the generator to 0.01 % at the true parameters.

**Hidden effects in the logs (none flagged):**

- **Load-cell zero drift.** The load cell sits in the jig, inside the oven, and its zero drifts by 0.40 N/K. Only the 10 minutes logged after each jig was opened read it: 7 N at 40 °C and 39 N at 120 °C, a large fraction of the thin-pad force. Ignoring it misses by more than the whole S3 preload (the cold-soak value turns negative).
- **Re-zero after a power cut.** In the 80 °C log the sampling suddenly returns to 1 min steps at 422.5 h. The logger restarted and the load cell re-zeroed, so every later reading is 34 N lower, a step that looks like a burst of relaxation. Taking it as real misses by up to 4.7 %.
- **Diffusion-limited oxidation.** At high temperature the oxygen is consumed before it reaches the core of the thick pad, so the production pad ages more slowly than the thin pad: 1.6 times slower at 100 °C and 2.1 times at 120 °C. The modulus grows with the thickness and with temperature at its own activation energy. Ignoring it misses by up to 12.8 %. Dropping the thin-pad tests and fitting one Arrhenius law misses by up to 10.4 %.
- **Chemical and physical relaxation shift differently with temperature.** One Arrhenius shift for both misses by up to 3.2 %. One WLF shift misses by up to 26 %.

**Trivial answers:** reward needs all four values within 2 %. Checked against `tests/expected.json`:

- 1.0, the mean (0.542) and the median (0.611) of the four true values pass none;
- 0.75, or any constant from 0.738 to 0.751, passes S1 and S4 only.

No constant passes S2 or S3, so no constant earns the reward. Zero, negative values and values above 1.5 are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver cannot reproduce the noise and subtract it.

Data are SYNTHETIC but built like a real campaign:

- the pad temperature follows the oven air through a jig lag and slab conduction across the thickness;
- the force is K bT(T) exp(−D) times the Boltzmann superposition, in WLF reduced time, of the compression history with the relaxation function (1 + xi/tau0)^−n;
- the compression changes with the differing expansion of rubber and steel;
- Arrhenius oxidative relaxation is weighted by tanh(beta)/beta for diffusion-limited oxidation;
- the logs carry multiplicative and additive noise, the load-cell zero drift and the re-zero.

## Reference solution

`solution/solve.sh` runs `solution/pad_preload.py`:

1. Normalise each log by its own F0, the mean force over 0.4–0.5 h at the end of the 23 °C hold. Find the logging restart in the 80 °C log from the sudden return to 1 min steps, and give the readings after it a free offset. Read the unloaded rows after each test as the load-cell zero.
2. Pad temperature: the jig follows the oven air with a first-order lag. The pad follows the jig plates by slab conduction (odd modes, time constants proportional to the thickness squared).
3. Force model F/K = bT exp(−D) [eps0 Phi(xi(t)) + Σ Phi(xi(t) − xi(s)) Δeps(s)]. The compression is eps = 1 − (1 − eps0)(1 + a_steel ΔTj)/(1 + a_rubber ΔTs), with both expansion coefficients given. The load-cell drift, proportional to the jig temperature rise, is added to the model of the reading. Fit all the parameters to the seven logs and their unloaded tails together: WLF C1 and C2, tau0, n, Ea, k100, the two lags, the DLO modulus and its activation, the offset and the drift.
4. Targets: apply the service temperature at 0.5 h with the same thermal response. For a reading in other air, change the air at the end of the service time and keep superposing the compression changes until the reading time.

It recovers the drift (0.399 N/K, generated 0.40), the offset (−34 N), Ea (96.0 kJ/mol, generated 96), beta (1.60, generated 1.6) and its activation (60.6 kJ/mol, generated 61). The fit rms is 1.15 times the logger noise. It runs in about 5 minutes on two CPUs.

## Verification

`tests/preload_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `S1`–`S4`, each holding exactly `retained_force_fraction` as a finite number. Malformed output fails every test as a test failure. Four separately named tests then require each value to be positive, at most 1.5 and within 2 % (relative) of the model truth. Reward is 1 only if all five pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign and the truth for seeds 1–5 (new logger noise) beside the shipped seed 0. Every submitter writes `results.json` in its own folder, and the unchanged check file runs through pytest with the CTRF plugin, as `tests/test.sh` does (`SCORE_ONLY=1` rescoring the saved submissions). Each submission keeps its `reward.txt` and `ctrf.json`. The summary is in `authoring/evidence/grading_results.txt`.

**Reward 1 on all six data sets (5/5 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.12–0.47 % (0.06–0.24× the bound) |
| `authoring/evidence/independent_reduction.py`, an independent reduction with no shared code: F0 as the median of the end of the hold, the re-zero found from the jump of the force, two first-order lags in series for the jig and the pad, the Boltzmann sum taken directly over the compression increments, diffusion-limited oxidation from a finite-difference solution of oxygen diffusion and consumption, and a dogbox least-squares search on log-parameters | 0.10–0.51 % (0.05–0.26× the bound) |
| Pad temperature as a single first-order lag behind the jig, otherwise as the reference (`alternatives.py`) | 0.72–0.81 % (0.36–0.41× the bound) |

The 2 % bound leaves the correct-physics reductions a margin of at least 2.4 times, and it is 1.5 times tighter than the nearest wrong route (one Arrhenius shift, 3.1–3.2 %).

**Reward 0 on every data set run (same file, `authoring/evidence/alternatives.py`):**

| Route | Data sets | Tests passed | Largest error |
|---|---|---|---|
| Thermal strain not superposed (multiplicative shortcut) | 6 | 3/5 | 16.6–17.2 % (8.3–8.6×) |
| One Arrhenius shift for both relaxations | 6 | 3/5 | 3.1–3.2 % (1.5–1.6×) |
| One WLF shift for both relaxations | 6 | 1/5 | 26.1–26.3 % (13.0–13.2×) |
| Diffusion-limited oxidation ignored | 6 | 1/5 | 12.5–12.8 % (6.3–6.4×) |
| Thin-pad tests dropped, one Arrhenius law | 6 | 2/5 | 10.1–10.4 % (5.1–5.2×) |
| Chemical relaxation ignored | 6 | 1/5 | 79.3–79.6 % (39.7–39.8×) |
| Thermal expansion of the rubber ignored | 5 | 3/5 | 100 % and more (cold-soak value not positive) |
| Entropic factor ignored | 2 | 1/5 | 83.5–83.9 % (41.8–41.9×) |
| Re-zero after the power cut taken as real relaxation | 2 | 2/5 | 4.6–4.7 % (2.3–2.4×) |
| Load-cell zero drift ignored | 1 | 3/5 | 100 % and more (cold-soak value not positive) |
| Pad at the oven air temperature (no heating lag) | 1 | 1/5 | 29.6 % (14.8×) |
| Other-air reading: only the entropic factor taken as reversible | 1 | 3/5 | 49.9 % (25.0×) |
| Other-air reading: the whole measured heating step taken as reversible | 1 | 3/5 | 62.3 % (31.1×) |

Each fit takes 20–60 minutes, so the routes whose error is far from the bound were run on fewer data sets (shipped seed 0 first). The routes near the bound and the decisive shortcut were run on all six. The summary lists the 67 graded submissions.

The generated parameters and the targets are in `authoring/evidence/generator_truth.json`.
