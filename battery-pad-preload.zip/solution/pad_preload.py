"""Reference solution: long-term preload of an EPDM battery-module compression pad from compression-stress-relaxation tests.

1. Readings. Each test is normalised by its own F0 (mean force over 0.4-0.5 h, end of the 30 min hold at 23 C). The load cell
   sits in the oven and its zero drifts with temperature: the 10 min logged after each jig was opened read that zero, and a
   drift proportional to the jig temperature rise is fitted to all logs. In the 80 C log the sampling suddenly returns to
   1 min steps at 422.5 h: the logger restarted (power cut) and the load cell re-zeroed, so the force sits lower by a constant
   from there and a free offset is fitted for the samples after the restart (the unloaded tail reads it too).
2. Temperatures. The jig follows the oven air with a first-order lag; the pad follows the jig plates by heat
   conduction (slab series, odd modes n with time constants tau_s/n^2, weights 8/(n^2 pi^2), tau_s ~ thickness^2).
3. Force model (linear viscoelasticity): F/K = bT exp(-D) [eps0 Phi(xi(t)) + sum over s of Phi(xi(t) - xi(s)) d eps(s)], i.e. the
   compression applied at t = 0 and every later change of compression relax from the moment they are applied, in WLF reduced
   time xi, with Phi = (1 + xi/tau0)^-n; bT = (Ts + 273.15)/296.15 (entropic elasticity); eps = 1 - (1 - eps0) (1 + a_j dTj)
   /(1 + a_r dTs) (both expansion coefficients given: the rubber expands far more than the steel, so heating raises the
   compression and cooling lowers it); chemical (oxidative) relaxation exp(-D), D = int k(T) tanh(beta)/beta dt with Arrhenius k
   and diffusion-limited oxidation (modulus beta ~ thickness, its own activation; the thin pads separate it). A change of
   compression made in the cold acts through the nearly unrelaxed modulus, which a relaxed-modulus scaling misses.
4. All parameters (C1, C2, tau0, n, Ea, k100, tau_jig, tau_pad, beta, dE, the 80 C offset, the zero drift) are fitted to the
   seven normalised logs together; the heating transients (force rising with the pad temperature, then relaxing within hours)
   fix the superposition.
5. Targets: the same model with the service temperature applied at 0.5 h (same thermal response). For a reading in other air,
   the air changes at the end of the service time and the superposition continues until the reading time.
"""
import json, os
import numpy as np
from scipy.optimize import least_squares

DATA = os.environ.get('DATA_DIR', '/app/data'); OUT = os.environ.get('OUT_DIR', '/app/output')
cfg = json.load(open(os.path.join(DATA, 'csr_campaign.json')))
A_J = cfg['jig']['steel_linear_expansion_per_K']; A_R = cfg['pad']['rubber_linear_expansion_per_K']; EPS0 = cfg['pad']['compression_fraction']; R = 8.314
NM = 2*np.arange(25) + 1; WM = 8/(NM**2*np.pi**2); WM = WM/WM.sum()

tests = []
for e in cfg['tests']:
    d = np.loadtxt(os.path.join(DATA, e['file']), delimiter=',', skiprows=1)
    t, F = d[:, 0], d[:, 1]
    F0 = np.mean(F[(t > 0.4) & (t <= 0.5 + 1e-9)])
    dt = np.diff(t)                                                 # a restart of the logger's schedule mid-test: the sampling
    rst = [i for i in range(1, len(dt)) if 3.0 < t[i] < 0.5 + e['duration_h'] - 1e-6 and dt[i] < 0.1*dt[i-1]]   # suddenly drops back to 1 min steps
    after = np.zeros(len(t), bool)
    if rst: after[rst[0] + 1:] = True
    cool = e.get('hours_in_23C_air_before_opening', 0.0)             # closed jig moved to 23 C air before opening
    tail = t > 0.5 + e['duration_h'] + cool + 1e-6                   # jig opened: the load cell reads its zero
    tests.append(dict(T=e['oven_temperature_C'], d=e['pad_thickness_mm'], t=t, y=F/F0, after=after, F0=F0, tail=tail,
                      cool=(0.5 + e['duration_h']) if cool else None, Topen=23.0 if cool else e['oven_temperature_C']))
print('# logging gaps (re-zeroed load cell):', [(x['T'], round(x['t'][x['after']][0], 2)) for x in tests if x['after'].any()])


def superpose(tf, xi, eps, tau0, n, e0=EPS0, g=4, t_cool=None):
    """Boltzmann superposition in reduced time: the compression e0 applied at t = 0 relaxes as Phi(xi); every later change of the
    compression (rubber and steel expanding differently with temperature) relaxes from the moment it is applied. Increments are
    summed in groups of g grid steps (one by one after a move to other air, where the reduced-time rate changes by orders of
    magnitude within a few steps) and the sum is evaluated on every g-th grid point, then interpolated."""
    Phi = lambda x: (1 + x/tau0)**(-n)
    de = np.diff(eps); xm = 0.5*(xi[1:] + xi[:-1])
    ic = len(de) if t_cool is None else int(np.searchsorted(tf, t_cool))
    idx = np.r_[np.arange(0, ic, g), np.arange(ic, len(de))].astype(int)
    gs = np.diff(np.r_[idx, len(de)]); deg = np.add.reduceat(de, idx); xmg = xm[np.minimum(idx + gs//2, len(xm) - 1)]; k = np.abs(deg) > 1e-13
    sel = np.unique(np.r_[np.arange(0, len(xi), g), np.arange(min(ic, len(xi)), len(xi)), len(xi) - 1])
    arg = xi[sel, None] - xmg[None, k]
    hs = e0*Phi(xi[sel]) + np.sum(np.where(arg >= 0, Phi(np.maximum(arg, 0.0))*deg[None, k], 0.0), axis=1)
    return np.interp(tf, tf[sel], hs)


def history(T_set, t_out, p, t_ins=0.5, d=5.33, t_cool=None, T_cool=23.0):
    ar, C1, C2, tau0, n, Ea, k100, tj, ts, b0, dE = p
    ar = A_R                                                       # given (dilatometer); p[0] is not used
    ts = ts*(d/5.33)**2                                            # conduction time ~ thickness squared
    tf = np.unique(np.r_[np.linspace(0, t_ins + 3, 1500), np.geomspace(t_ins + 3, max(t_out[-1], t_ins + 4), 1500)])
    if t_cool is not None: tf = np.unique(np.r_[tf[tf < t_cool], t_cool - np.geomspace(1e-4, 2.0, 100), t_cool + np.r_[0, np.geomspace(1e-4, t_out[-1] - t_cool, 1500)]])   # moved to the reading air
    Tair = np.where(tf < t_ins, 23.0, T_set)
    if t_cool is not None: Tair = np.where(tf > t_cool, T_cool, Tair)
    Tj = np.empty_like(tf); Tj[0] = 23.0; md = np.full(len(NM), 23.0); Ts = np.empty_like(tf); Ts[0] = 23.0
    for i in range(1, len(tf)):
        h = tf[i] - tf[i-1]
        Tj[i] = Tair[i] + (Tj[i-1] - Tair[i])*np.exp(-h/tj)
        dv = 0.5*(Tj[i] + Tj[i-1]); md = dv + (md - dv)*np.exp(-h*NM**2/ts); Ts[i] = WM@md
    Tm = 0.5*(Ts[1:] + Ts[:-1]); h = np.diff(tf)
    xi = np.r_[0, np.cumsum(h*3600*10**(C1*(Tm - 23)/(C2 + Tm - 23)))]
    beta = b0*(d/5.33)*np.exp(-dE/(2*R)*(1/(Tm + 273.15) - 1/373.15))   # diffusion-limited oxidation modulus
    D = np.r_[0, np.cumsum(h*k100*np.exp(-Ea/R*(1/(Tm + 273.15) - 1/373.15))*np.tanh(beta)/beta)]
    eps = 1 - (1 - EPS0)*(1 + A_J*(Tj - 23))/(1 + ar*(Ts - 23))
    F = (Ts + 273.15)/296.15*superpose(tf, xi, eps, tau0, n, t_cool=t_cool)*np.exp(-D)
    return np.interp(t_out, tf, F), np.interp(t_out, tf, Tj)


def residuals(q):
    p, off, ztc = q[:11], q[11], q[12]
    out = []
    for x in tests:
        ld = ~x['tail']; tl = x['t'][ld]
        m, Tj = history(x['T'], tl, p, d=x['d'], t_cool=x['cool']); m = m/np.interp(0.5, tl, m) + ztc*(Tj - 23)/x['F0']   # load-cell zero drift
        y = x['y'][ld] - np.where(x['after'][ld], off, 0.0)
        out.append((m - y)/0.0015)
        if x['tail'].any():                                             # unloaded readings: zero drift (+ the re-zero offset)
            yt = x['y'][x['tail']] - np.where(x['after'][x['tail']], off, 0.0)
            out.append((ztc*(x['Topen'] - 23)/x['F0'] - yt)*x['F0']/0.4)
    return np.concatenate(out)


x0 = [2e-4, 9.0, 110.0, 2.0, 0.02, 9e4, 6e-4, 0.4, 0.15, 1.0, 6e4, 0.0, 0.0]
lo = [0, 2, 30, 1e-3, 1e-3, 3e4, 1e-6, 0.02, 0.01, 1e-3, 0, -0.2, -5]; hi = [1e-3, 30, 400, 1e4, 0.2, 2e5, 1e-1, 3, 3, 20, 2e5, 0.2, 5]
xs = [2e-5, 0.5, 5, 0.5, 0.002, 2e3, 5e-5, 0.05, 0.02, 0.1, 5e3, 0.005, 0.05]
best = None
for st in (x0, [1.5e-4, 7, 90, 10, 0.03, 8e4, 1e-3, 0.3, 0.3, 2.0, 4e4, 0, 0], [2.5e-4, 12, 140, 0.5, 0.015, 1.1e5, 3e-4, 0.6, 0.08, 0.5, 8e4, 0, 0]):
    r = least_squares(residuals, st, bounds=(lo, hi), x_scale=xs)
    if best is None or r.cost < best.cost: best = r
q = best.x
print('# a_r %.3g /K (given), WLF C1 %.2f C2 %.1f, tau0 %.3g s, n %.4f, Ea %.1f kJ/mol, k100 %.3g /h, lags %.3f / %.3f h, DLO beta %.3f dE %.1f kJ/mol, '
      'offset %.4f, load-cell zero drift %.3f N/K; rms %.3f' % (A_R, q[1], q[2], q[3], q[4], q[5]/1e3, q[6], q[7], q[8], q[9], q[10]/1e3, q[11], q[12], np.sqrt(np.mean(best.fun**2))))
out = {}
for c in cfg['targets']['conditions']:
    hr, Tr = c['reading_hours_after_service'], c['reading_air_temperature_C']   # reading after the module is moved to other air
    tt = np.array([0.5, 0.5 + c['service_time_h'] + hr])
    m, _ = history(c['service_temperature_C'], tt, q[:11], t_cool=0.5 + c['service_time_h'] if hr > 0 else None, T_cool=Tr)
    out[c['name']] = {'retained_force_fraction': float(m[1]/m[0])}
print('#', {k: round(v['retained_force_fraction'], 4) for k, v in out.items()})
os.makedirs(OUT, exist_ok=True)
json.dump(out, open(os.path.join(OUT, 'results.json'), 'w'), indent=2)
