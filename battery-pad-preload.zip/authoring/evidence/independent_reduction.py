"""Independent reduction of the CSR campaign (no code shared with solution/pad_preload.py or the generator).

Differences from the reference:
* F0 as the median of the last ten minutes of the 23 C hold, instead of the mean of the last six minutes;
* the load-cell re-zero located from the jump of the force between consecutive samples relative to its neighbours (the
  reference uses the restart of the logging schedule), with the offset estimated from the jump and then refined in the fit;
* pad temperature as two first-order lags in series, jig then pad with its lag ~ thickness squared (the reference uses
  the jig lag plus a slab-conduction mode series);
* diffusion-limited oxidation from a finite-difference solution of steady oxygen diffusion and consumption across the
  thickness (c'' = beta^2 c, c = 1 at the faces, the mean c weights the oxidation), tabulated against beta, instead of the
  closed form tanh(beta)/beta;
* the model normalised like the data, by its median over the end of the hold;
* time integration on the logger's own samples with trapezoids, and a dogbox least-squares search on log-parameters from
  three starts (the reference uses trust-region least squares on the linear parameters).
* the changes of compression superposed in reduced time (each relaxes from when it occurs), summed directly over the
  significant increments on the sample grid (the reference groups increments on its own grid);
Physics kept, as in any correct reduction: physical relaxation (power law in WLF reduced time), chemical relaxation
(Arrhenius) weighted by the oxidised fraction, entropic factor (T + 273.15)/296.15, compression change from the differing
expansion of rubber and steel.

    python independent_reduction.py <data_dir> <results.json>
"""
import json, os, sys
import numpy as np
from scipy.optimize import least_squares
from scipy.linalg import solve_banded

data_dir, out_file = sys.argv[1], sys.argv[2]
cfg = json.load(open(os.path.join(data_dir, 'csr_campaign.json')))
a_steel = cfg['jig']['steel_linear_expansion_per_K']; a_rub = cfg['pad']['rubber_linear_expansion_per_K']; e0 = cfg['pad']['compression_fraction']; Rg = 8.314

# oxidised fraction against the diffusion-reaction modulus, by finite differences on the half thickness
_bg = np.geomspace(1e-3, 30, 120); _fr = []
for bb in _bg:
    nn = 200; z = np.linspace(0, 1, nn + 1); hz = z[1] - z[0]
    ab = np.zeros((3, nn)); ab[1] = -2 - (bb*hz)**2; ab[0, 1:] = 1; ab[2, :-1] = 1; ab[0, 1] = 2   # node 0 mid-plane (symmetry)
    rhs = np.zeros(nn); rhs[-1] = -1.0                                                             # face concentration 1
    c = np.r_[solve_banded((1, 1), ab, rhs), 1.0]
    _fr.append(np.trapezoid(c, z))
_fr = np.array(_fr)
oxidised = lambda b: np.interp(np.log(b), np.log(_bg), _fr)

runs = []
for e in cfg['tests']:
    a = np.loadtxt(os.path.join(data_dir, e['file']), delimiter=',', skiprows=1)
    t, F, Ta = a[:, 0], a[:, 1], a[:, 2]
    F0 = np.median(F[(t > 0.33) & (t <= 0.5 + 1e-9)])
    y = F/F0
    cool = e.get('hours_in_23C_air_before_opening', 0.0)
    unl = t > 0.5 + e['duration_h'] + cool + 1e-6                     # the readings after the jig was opened: load-cell zero
    dy = np.diff(y); jump = None
    for i in range(5, len(dy) - 5):
        if 50 < t[i] and t[i + 1] < 0.5 + e['duration_h'] - 1e-6 and abs(dy[i]) > 8*np.median(np.abs(dy[i-5:i+5])) and abs(dy[i]) > 0.01:
            jump = i; break
    runs.append(dict(T=e['oven_temperature_C'], d=e['pad_thickness_mm'], t=t, y=y, jump=jump, F0=F0, unl=unl,
                     tc=(0.5 + e['duration_h']) if cool else None, To=23.0 if cool else e['oven_temperature_C'],
                     j0=(y[jump + 1] - y[jump]) if jump is not None else 0.0))
print('re-zero jumps:', [(r['T'], r['d'], round(r['t'][r['jump'] + 1], 1), round(r['j0'], 4)) for r in runs if r['jump'] is not None])


def predict(T_set, d, t, p, t_cool=None, T_cool=23.0):
    ar, c1, c2, tau0, n, Ea, k100, lag, b0, dE, lag2 = p
    ar = a_rub                                                       # given by the compound datasheet; p[0] unused
    tt = np.unique(np.r_[t, np.linspace(0, 3.5, 800), np.linspace(0.33, 0.5, 40)])
    if t_cool is not None: tt = np.unique(np.r_[tt, np.geomspace(0.5 + 1e-3, t_cool, 3000), t_cool - np.geomspace(1e-4, 2.0, 100), t_cool + np.geomspace(1e-4, t[-1] - t_cool, 800)])
    Tair = np.where(tt < 0.5, 23.0, T_set)
    if t_cool is not None: Tair = np.where(tt > t_cool, T_cool, Tair)
    lagd = lag2*(d/5.33)**2                                           # pad lag behind the jig, ~ thickness squared
    Tj = np.empty_like(tt); Tj[0] = 23.0; Ts = np.empty_like(tt); Ts[0] = 23.0
    for i in range(1, len(tt)):
        h = tt[i] - tt[i-1]
        Tj[i] = Tair[i] + (Tj[i-1] - Tair[i])*np.exp(-h/lag)
        Ts[i] = Tj[i] + (Ts[i-1] - Tj[i])*np.exp(-h/lagd)
    dt = np.diff(tt); Tm = 0.5*(Ts[1:] + Ts[:-1])
    xi = np.r_[0, np.cumsum(dt*3600*10**(c1*(Tm - 23)/(c2 + Tm - 23)))]
    beta = b0*(d/5.33)*np.exp(-dE/(2*Rg)*(1/(Tm + 273.15) - 1/373.15))
    D = np.r_[0, np.cumsum(dt*k100*np.exp(-Ea/Rg*(1/(Tm + 273.15) - 1/373.15))*oxidised(beta))]
    comp = 1 - (1 - e0)*(1 + a_steel*(Tj - 23))/(1 + ar*(Ts - 23))
    G = lambda x: (1 + x/tau0)**(-n)                                 # relaxation function in reduced time
    dc = np.diff(comp); big = np.nonzero(np.abs(dc) > 1e-6*np.abs(dc).max())[0] if np.any(dc) else np.array([], int)
    xs = 0.5*(xi[big] + xi[big + 1])                                  # each change of compression relaxes from when it occurs
    lag_x = xi[:, None] - xs[None, :]
    hist = e0*G(xi) + np.sum(np.where(lag_x >= 0, G(np.maximum(lag_x, 0.0))*dc[big][None, :], 0.0), axis=1)
    f = (Ts + 273.15)/296.15*hist*np.exp(-D)
    ref = np.median(f[(tt > 0.33) & (tt <= 0.5 + 1e-9)])            # normalised like the data (median over the end of the hold)
    return np.interp(t, tt, f)/ref, np.interp(t, tt, Tj)          # load cell at the jig temperature


def resid(lp):
    p = np.exp(lp[:11]); off, ztc = lp[11], lp[12]                  # ztc: load-cell zero drift, N/K
    out = []
    for r in runs:
        y = r['y'].copy()
        if r['jump'] is not None: y[r['jump'] + 1:] -= off
        ld = ~r['unl']
        m, Tc = predict(r['T'], r['d'], r['t'][ld], p, t_cool=r['tc'])
        w = np.ones(ld.sum()) if r['tc'] is None else ((r['t'][ld] < r['tc']) | (r['t'][ld] > r['tc'] + 3)).astype(float)   # skip the cooling transient
        out.append(w*(m + ztc*(Tc - 23)/r['F0'] - y[ld])/0.0015)
        out.append((ztc*(r['To'] - 23)/r['F0'] - y[r['unl']])*r['F0']/0.4)
    return np.concatenate(out)


off0 = next((r['j0'] for r in runs if r['jump'] is not None), 0.0)
lo = np.r_[np.log([3e-5, 3, 30, 0.05, 0.005, 5e4, 1e-4, 0.05, 0.1, 2e4, 0.01]), -0.2, -2.0]   # bounds on log-parameters
hi = np.r_[np.log([1e-3, 25, 300, 100, 0.08, 1.5e5, 5e-3, 2.0, 10, 1.5e5, 2.0]), 0.2, 2.0]
best = None
for st in ([2e-4, 9, 110, 2, 0.02, 9e4, 6e-4, 0.3, 1.0, 6e4, 0.1], [1.2e-4, 7, 80, 5, 0.025, 1e5, 7e-4, 0.5, 2.5, 4e4, 0.2],
           [3e-4, 12, 150, 1, 0.018, 8e4, 5e-4, 0.4, 1.5, 8e4, 0.05]):
    x0 = np.clip(np.r_[np.log(st), off0, 0.3], lo + 1e-9, hi - 1e-9)
    r = least_squares(resid, x0, bounds=(lo, hi), method='dogbox', diff_step=1e-4)
    r.fun2 = float(np.sum(r.fun**2)); r.fun_v = r.fun
    print('start', st[:3], 'chi2/N %.3f' % (r.fun2/len(r.fun)), flush=True)
    if best is None or r.fun2 < best.fun2: best = r
best.fun = best.fun2
p = np.exp(best.x[:11])
print('a_r %.3g (given), WLF %.2f/%.1f, tau0 %.3g, n %.4f, Ea %.1f kJ/mol, k100 %.3g, lags %.3f/%.3f h, beta %.3f, dE %.1f kJ/mol, offset %.4f, '
      'zero drift %.3f N/K, chi2/N %.3f' % (a_rub, *p[1:5], p[5]/1e3, p[6], p[7], p[10], p[8], p[9]/1e3, best.x[11], best.x[12], best.fun/len(best.fun_v)))
res = {}
for c in cfg['targets']['conditions']:
    hr, Tr = c['reading_hours_after_service'], c['reading_air_temperature_C']
    tt = np.array([0.5, 0.5 + c['service_time_h'] + hr])
    tt = np.unique(np.r_[tt, np.geomspace(0.5 + 1e-3, tt[-1], 3000)])
    f = predict(c['service_temperature_C'], 5.33, tt, p, t_cool=0.5 + c['service_time_h'] if hr > 0 else None, T_cool=Tr)[0]
    res[c['name']] = {'retained_force_fraction': float(f[-1]/np.interp(0.5, tt, f))}   # F0 at 0.5 h, as the targets define it
print({k: round(v['retained_force_fraction'], 4) for k, v in res.items()})
json.dump(res, open(out_file, 'w'), indent=2)
