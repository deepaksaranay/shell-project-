"""Synthetic compression-stress-relaxation (CSR) campaign of an EPDM battery-module compression pad (authoring only).

    python generate.py <env_data_dir> <tests_dir> [<evidence_dir>]        (CSR_SEED redraws the noise)

The pad is compressed between the plates of a steel CSR jig at 23 C, held 30 min (the force there is the reference force
F0), then the jig goes into an oven at the test temperature and the preload force is logged for weeks. Force model:
    F = K bT(Ts) eps(Ts, Tj) Phi(xi) exp(-D)
    bT = (Ts + 273.15)/296.15                                   entropic rubber elasticity
    eps = 1 - g0 (1 + a_j (Tj - 23)) / (h0 (1 + a_r (Ts - 23)))  compression: rubber expands more than the steel jig
    Phi = (1 + xi/tau0)^-n,  xi = int dt / aT(Ts),  log10 aT = -C1 (Ts - 23)/(C2 + Ts - 23)     physical relaxation (WLF)
    D = int k(Ts) dt,  k = k23 exp(-Ea/R (1/Ts - 1/296.15))                                      chemical (oxidative) relaxation
The chemical rate is reduced by diffusion-limited oxidation: only the fraction tanh(beta)/beta of the thickness oxidises at the
full rate, beta ~ thickness x exp(-dE/(2R)(1/T - 1/373.15)) (two tests use a thinner pad of the same compound).
Jig temperature Tj follows the oven air with a first-order lag; the pad temperature Ts follows the jig plates by conduction
through the thickness (slab conduction series). Hidden: K, a_r, WLF, tau0, n, k23, Ea, the lags. Unflagged defect: in the
80 C test a power cut re-zeroed the load cell; the logger restarted its schedule afterwards (1 min steps for 30 min in the
middle of the log) and the force reads low by a constant from then on.
The load cell sits inside the oven and its zero drifts with its (jig) temperature by ZTC N/K (hidden); after each test the jig is
opened in the oven and the logger records the load-cell zero for 10 min. The thin pads have a smaller face (lower forces).
Noise from a 128-bit secret entropy. Truth: retained preload F/F0 of the pad in service at the target temperatures and times.
"""
import json, os, sys
from pathlib import Path
import numpy as np

NOISE_ENTROPY = 70920296046439984327927927498078724822
SEED = int(os.environ.get('CSR_SEED', 0))
R = 8.314
T_REF = 23.0
K = 10625                     # N per unit strain (hidden)
EPS0 = 0.10                    # stated compression
A_RUBBER, A_JIG = 2.1e-4, 1.2e-5      # 1/K linear expansion of the EPDM (hidden) and the steel jig (given)
C1, C2 = 9.5, 105.0            # WLF (hidden)
TAU0, N_EXP = 2.0, 0.022       # s, physical relaxation (hidden)
EA = 96e3                      # J/mol (hidden)
K100 = 6.5e-4                  # 1/h chemical rate at 100 C (hidden)
TAU_JIG, TAU_PAD = 0.45, 0.12 # h (hidden)
TESTS = [(40.0, 3000.0, 5.33), (60.0, 2000.0, 5.33), (80.0, 1500.0, 5.33), (100.0, 1000.0, 5.33), (120.0, 300.0, 5.33),
         (100.0, 1000.0, 1.78), (120.0, 300.0, 1.78)]      # oven C, duration h, pad thickness mm
COOLED = {}                     # test: hours logged in 23 C air with the jig still closed, after the stated duration (none)
BETA_REF, DE_DLO = 1.6, 61e3   # hidden: diffusion-limited oxidation modulus of the 5.33 mm pad at 100 C, and its activation
                               # energy (oxidation minus oxygen diffusion); beta ~ thickness x exp(-dE/(2R)(1/T - 1/373.15))
ZTC = 0.40                     # N/K hidden: zero drift of the load cell (inside the oven) with its temperature
UNLOAD_MIN = 10                # min logged after the jig is opened in the oven at the end of each test
ZERO_SHIFT = {80.0: (420.0, 2.0, -34.0)}   # test: (time of the power cut h, logging gap h, load-cell offset N) (hidden)
TARGETS = [('S1', 40.0, 43800.0, 40.0, 0.0), ('S2', 70.0, 8760.0, 23.0, 24.0), ('S3', 100.0, 2000.0, -40.0, 4.0), ('S4', 23.0, 87600.0, 23.0, 0.0)]
#          name, service C, service h, air C of the reading, hours after the end of service (0: read at the service temperature)
NMODE = 2*np.arange(30) + 1


def k_chem(T):
    return K100*np.exp(-EA/R*(1/(T + 273.15) - 1/373.15))


def log_aT(T):
    return -C1*(T - T_REF)/(C2 + T - T_REF)


def time_grid(t_end, t_ins=0.5):
    """Log of the controller: 1 min steps for the first 2 h after insertion, then logarithmic."""
    a = np.arange(0, t_ins, 1/60)
    b = t_ins + np.arange(0, 2.0, 1/60)
    c = t_ins + np.geomspace(2.0, t_end, 420)
    return np.unique(np.r_[a, b, c])


def dlo_factor(T, d_mm):
    """Fraction of the thickness that oxidises at the full rate: tanh(beta)/beta (oxygen consumed faster than it diffuses in)."""
    beta = BETA_REF*(d_mm/5.33)*np.exp(-DE_DLO/(2*R)*(1/(T + 273.15) - 1/373.15))
    return np.tanh(beta)/beta


def simulate(T_oven, t_out, t_ins=0.5, steady=False, d_mm=5.33, t_cool=None, T_cool=23.0):
    """Pad history on a fine internal grid: compression at t = 0 (23 C), oven at T_oven from t_ins (or, if steady, the service
    temperature applied at t_ins with the same thermal response). Returns F/K at the output times and the pad temperature."""
    tf = np.unique(np.r_[np.linspace(0, t_ins + 3, 4000), np.geomspace(t_ins + 3, max(t_out[-1], t_ins + 4), 6000)])
    if t_cool is not None: tf = np.unique(np.r_[tf[tf < t_cool], t_cool - np.geomspace(1e-4, 2.0, 200), t_cool + np.r_[0, np.geomspace(1e-4, t_out[-1] - t_cool, 3000)]])
    Tair = np.where(tf < t_ins, 23.0, T_oven)
    if t_cool is not None: Tair = np.where(tf > t_cool, T_cool, Tair)   # the step ending at t_cool is still in the hot air
    Tj = np.empty_like(tf); Tj[0] = 23.0
    modes = np.full(len(NMODE), 23.0); Ts = np.empty_like(tf); Ts[0] = 23.0
    w = 8/(NMODE**2*np.pi**2)
    xi = np.zeros_like(tf); D = np.zeros_like(tf)
    for i in range(1, len(tf)):
        h = tf[i] - tf[i-1]
        Tj[i] = Tair[i] + (Tj[i-1] - Tair[i])*np.exp(-h/TAU_JIG)
        drive = 0.5*(Tj[i] + Tj[i-1])
        modes = drive + (modes - drive)*np.exp(-h*NMODE**2/(TAU_PAD*(d_mm/5.33)**2))   # each mode relaxes to the plate temperature
        Ts[i] = 23.0 + np.sum(w*(modes - 23.0))/np.sum(w)
        Tm = 0.5*(Ts[i] + Ts[i-1])
        xi[i] = xi[i-1] + h*3600/10**log_aT(Tm)
        D[i] = D[i-1] + h*k_chem(Tm)*dlo_factor(Tm, d_mm)
    eps = 1 - (1 - EPS0)*(1 + A_JIG*(Tj - 23))/(1 + A_RUBBER*(Ts - 23))
    # linear viscoelasticity (Boltzmann superposition in reduced time): the compression applied at t = 0 relaxes as Phi(xi), each
    # later change of compression (thermal expansion of rubber vs steel) relaxes from the moment it is applied
    Phi = lambda x: (1 + x/TAU0)**(-N_EXP)
    de = np.diff(eps); xm = 0.5*(xi[1:] + xi[:-1]); jj = np.nonzero(np.abs(de) > 1e-12)[0]
    hist = EPS0*Phi(xi)
    for a in range(0, len(tf), 400):
        b = min(a + 400, len(tf)); arg = xi[a:b, None] - xm[None, jj]
        hist[a:b] += np.sum(np.where(arg >= 0, Phi(np.maximum(arg, 0))*de[None, jj], 0.0), axis=1)
    F = (Ts + 273.15)/296.15*hist*np.exp(-D)
    return np.interp(t_out, tf, F), np.interp(t_out, tf, Ts), np.interp(t_out, tf, Tair), np.interp(t_out, tf, Tj)


def main(env_dir, tests_dir, evidence_dir=None):
    env_dir, tests_dir = Path(env_dir), Path(tests_dir); (env_dir/'tests').mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(np.random.SeedSequence([NOISE_ENTROPY, SEED]))
    files = []
    for T_oven, dur, d_mm in TESTS:
        t = time_grid(dur)                                             # ends at 0.5 h + duration
        if T_oven in ZERO_SHIFT and d_mm == 5.33:    # the logger restarts its schedule after the power cut: 1 min steps for 30 min
            tc, gap, _ = ZERO_SHIFT[T_oven]
            t = np.unique(np.r_[t, 0.5 + tc + gap + np.arange(0, 0.5, 1/60)])
        cool = COOLED.get((T_oven, d_mm), 0.0)
        if cool:                                     # closed jig moved into 23 C air at the end of the duration: 1 min steps, then log
            t = np.unique(np.r_[t, 0.5 + dur + np.arange(1, 150)/60, 0.5 + dur + np.geomspace(2.5, cool, 60)])
        Fk, Ts, Tair, Tj = simulate(T_oven, t, d_mm=d_mm, t_cool=0.5 + dur if cool else None, T_cool=23.0)
        Ksize = K*(d_mm/5.33)*((47.22 + d_mm)/(47.22 + 5.33))          # thin pads: 22.3 x 22.3 mm face, 0.311 of the 40 x 40 mm face
        F = Ksize*Fk*(1 + rng.normal(0, 0.0012, len(t))) + rng.normal(0, 0.4, len(t)) + ZTC*(Tj - 23.0)
        tu = t[-1] + np.arange(1, UNLOAD_MIN + 1)/60                    # jig opened in the oven: the load cell reads its zero
        T_open = 23.0 if cool else T_oven
        t = np.r_[t, tu]; F = np.r_[F, ZTC*(T_open - 23.0) + rng.normal(0, 0.4, len(tu))]; Tair = np.r_[Tair, np.full(len(tu), T_open)]
        keep = np.ones(len(t), bool)
        if T_oven in ZERO_SHIFT and d_mm == 5.33:
            tc, gap, off = ZERO_SHIFT[T_oven]
            keep &= ~((t >= 0.5 + tc) & (t < 0.5 + tc + gap))
            F = np.where(t >= 0.5 + tc + gap, F + off, F)
        Tlog = Tair + rng.normal(0, 0.3, len(t))
        fn = f'tests/csr_{int(T_oven):03d}C_{str(d_mm).replace(".", "p")}mm.csv'
        files.append(dict(file=fn, oven_temperature_C=T_oven, duration_h=dur, pad_thickness_mm=d_mm))
        with open(env_dir/fn, 'w') as fh:
            fh.write('time_h,force_N,oven_air_C\n')
            for a, b, c in zip(t[keep], F[keep], Tlog[keep]):
                fh.write(f'{a:.4f},{b:.2f},{c:.2f}\n')
    meta = {
        'pad': {'type': 'compression pad between the cells of an EV battery module, peroxide-cured EPDM, 70 Shore A, one compound batch',
                'production_pad': {'thickness_mm': 5.33, 'face_mm': [40.0, 40.0]},
                'rubber_linear_expansion_per_K': A_RUBBER, 'rubber_expansion_note': 'compound datasheet, dilatometer, -40 to 150 C',
                'second_size': 'two tests use pads of the same compound 1.78 mm thick with a 22.3 x 22.3 mm face (same 10 % compression)',
                'compression': 'compressed by 10 % of its thickness between flat plates (spacer-controlled)', 'compression_fraction': EPS0},
        'jig': {'type': 'CSR jig after ISO 3384, plates and spacers of stainless steel', 'steel_linear_expansion_per_K': A_JIG,
                'force': 'built-in load cell measuring the preload force at the test temperature, N'},
        'procedure': ('each test: the pad is compressed in the jig at 23 C at time 0 and held for 30 min at 23 C; the force at 0.5 h '
                      'is the reference force F0 of that test; at 0.5 h the jig goes into the preheated oven at the test temperature, '
                      'whose air is at the setpoint from then on (logged), and stays there for the stated duration; the logger records '
                      'every minute for the first 2.5 h, then on a logarithmic schedule; at the end of the stated duration the jig is '
                      'opened inside the oven, the pad is taken out and the logger records for another 10 min (rows after the stated '
                      'duration); the load cell sits in the jig, inside the oven'),
        'tests': files,
        'targets': {
            'quantity': ('retained preload F/F0 of the production pad in the module stack (steel end plates and tie rods, same '
                         'compression), where F0 is the force 30 min after compression at 23 C; the pad goes to the service temperature '
                         'at 0.5 h exactly as in the tests (step of the surrounding air, same thermal response), and service time is '
                         'counted from then; the reading: if reading_hours_after_service is 0, F at the end of the service time at '
                         'the service temperature; otherwise, at the end of the service time the module, still compressed, is moved '
                         'into air at reading_air_temperature_C (same thermal response) and F is read that many hours later'),
            'conditions': [dict(name=n, service_temperature_C=T, service_time_h=th, reading_air_temperature_C=Tr, reading_hours_after_service=hr)
                           for n, T, th, Tr, hr in TARGETS]},
    }
    (env_dir/'csr_campaign.json').write_text(json.dumps(meta, indent=2) + '\n')
    truth = {}
    for n, T, th, Tr, hr in TARGETS:
        tout = np.array([0.5, 0.5 + th + hr])
        Fk, _, _, _ = simulate(T, tout, t_cool=0.5 + th if hr > 0 else None, T_cool=Tr)
        truth[n] = {'retained_force_fraction': float(Fk[1]/Fk[0])}
    (tests_dir/'expected.json').write_text(json.dumps(truth, indent=2) + '\n')
    if evidence_dir:
        Path(evidence_dir).mkdir(parents=True, exist_ok=True)
        (Path(evidence_dir)/'generator_truth.json').write_text(json.dumps({
            'targets': truth, 'K_N': K, 'rubber_expansion_per_K': A_RUBBER, 'wlf': {'C1': C1, 'C2_K': C2, 'T_ref_C': T_REF},
            'physical_relaxation': {'tau0_s': TAU0, 'n': N_EXP}, 'chemical': {'Ea_J_per_mol': EA, 'k_100C_per_h': K100},
            'thermal_lags_h': {'jig': TAU_JIG, 'pad_slab_first_mode_5p33mm': TAU_PAD}, 'dlo': {'beta_5p33mm_100C': BETA_REF, 'dE_J_per_mol': DE_DLO}, 'load_cell_zero_shift': {str(k): v for k, v in ZERO_SHIFT.items()}, 'load_cell_zero_drift_N_per_K': ZTC}, indent=2) + '\n')


if __name__ == '__main__':
    main(*sys.argv[1:4])
