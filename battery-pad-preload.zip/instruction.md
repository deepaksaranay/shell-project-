A battery-module supplier ran compression-stress-relaxation tests on the peroxide-cured EPDM compression pads that sit between the cells of an EV battery module and keep the cell stack under preload. In each test a pad was compressed by 10 % of its thickness in a steel jig at 23 C, held for 30 minutes, and then aged in an oven at a fixed temperature for up to a few thousand hours while the jig's load cell logged the force. Most tests used the production pad; two used a thinner pad of the same compound. `/app/data/csr_campaign.json` describes the pads, the jig, the test procedure, the test files and the service conditions; the logs are in `/app/data/tests/` (time in hours from compression, force in N, oven air temperature in C).

The module designer needs to know how much preload the production pad will retain in service at the four conditions `S1` to `S4` listed in `csr_campaign.json`, expressed as F/F0 in the sense defined there.

Write `/app/output/results.json` as a regular file containing a JSON object, without duplicate keys, with exactly the keys `S1`, `S2`, `S3` and `S4`. Each must map to an object with exactly one finite number, `retained_force_fraction`.

You have 28800 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
