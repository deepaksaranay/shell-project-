#!/usr/bin/env bash
set -euo pipefail
dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DATA_DIR="${DATA_DIR:-/app/data}" OUT_DIR="${OUT_DIR:-/app/output}"
mkdir -p "$OUT_DIR"
python3 "$dir/ecm_gap_model.py"
