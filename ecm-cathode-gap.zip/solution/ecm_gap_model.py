"""Reference solution: equilibrium ECM gap and current at target conditions from transient sinking runs.

Gap history: the stated initial gaps are set by touching off and retracting; the retract reverses the feed axis, so every run
starts closer by the backlash of the feed screw, fitted as one common offset. The anode carries a resistive film (passive/salt
film in nitrate) in series with the electrolyte: J = (U - dU)/(g/kappa + R_f). In a flat run it acts like an extra gap
kappa R_f, which changes with the conductivity (electrolyte temperature, hydrogen), unlike a touch-off error, so R_f and the
backlash separate across the runs; in production it is a Robin condition phi + kappa R_f dphi/dn = U - dU on the anode; the tool advance is taken from the logged tool
position (the servo held the feed for 45 s in run R9), not from the nominal feed rate.
Physics (planar frontal gap g, feed f):  dg/dt = eta(J) kv J - f,  J = kappa (U - dU) / g, with the electrolyte conductivity
kappa = kappa20 (1 + alpha (T_mean - 20)) G at the mean gap temperature, T_mean = T_in + J U A / (2 rho_c Q). G < 1 is the
loss of conductance to the hydrogen the cathode evolves (I/(2F) mol/s): at the modest flows of the characterisation runs the
gas occupies a few to over ten per cent of the gap by the outlet, so G is computed from Faraday's law, the ideal-gas volume at
the local pressure (falling linearly from the inlet pressure to atmosphere along the 20 mm flow path, no slip) and Bruggeman's
relation kappa (1 - void)^1.5, averaged along the path. Ignoring it pushes the bubble loss into the fitted overpotential and
efficiency, which then do not apply to the gas-free production gap. The gap is never
measured during a run, but its history is fixed by the initial gap and the ODE, so the current traces determine the unknowns:
the overpotential dU and a current efficiency that rises with current density in nitrate electrolyte,
eta(J, T) = (e25 + s (T - 25 C)) (1 - exp(-(J - J0)/Jc)) (J in A/cm^2, T the mean electrolyte temperature): the saturated
efficiency falls as the electrolyte gets hotter (more oxygen evolution), which the five runs with preheated electrolyte reveal and
which matters because production runs at 50 C, at the top of the range of the runs. All seventeen runs are simulated and fitted together to their currents
(relative least squares); runs stopped before the gap settled are used through their transients. For the production
cathode, whose corrugation wavelength is only a few gaps long, the gap cannot be treated as locally plane-parallel: the
potential in the gap is solved as a 2-D Laplace problem (boundary-fitted finite differences, periodic in x) and the anode,
a free boundary, is marched in time from a flat workpiece until it recedes along the feed exactly as fast as the tool
advances, eta(J) kv J sqrt(1 + slope^2) = f at every point. The gap along the feed is read at the requested positions.
"""
import json, os
import numpy as np
from scipy.optimize import least_squares, brentq

DATA = os.environ.get('DATA_DIR', '/app/data'); OUT = os.environ.get('OUT_DIR', '/app/output')
cfg = json.load(open(os.path.join(DATA, 'ecm_campaign.json')))
A = cfg['tool_face']['width_mm']*cfg['tool_face']['length_mm']*1e-6
KV = cfg['workpiece']['volumetric_electrochemical_equivalent_mm3_per_C']*1e-9
el = cfg['electrolyte']; K20, ALPHA, RHOC = el['conductivity_at_20C_S_per_m'], el['conductivity_temperature_coefficient_per_K'], el['volumetric_heat_capacity_J_per_m3K']


def eff(J, p, T):
    """Current efficiency: rises with current density (J in A/m^2) and its saturated value e25 + s (T - 25) changes with the
    electrolyte temperature T (C)."""
    e25, J0, Jc, sT = p
    return np.maximum((e25 + sT*(T - 25.0))*(1 - np.exp(-(J/1e4 - J0)/Jc)), 0.0)


F_FARADAY, R_GAS, P_ATM = 96485.0, 8.314, 1.013
ZG, WG = np.polynomial.legendre.leggauss(24); ZG = 0.5*(ZG + 1); WG = 0.5*WG


def gas_factor(I, Q, Tm, pin):
    """Conductance factor of the bubbly gap in a characterisation run: the cathode evolves H2 at I/(2F) mol/s uniformly over
    the face; along the 20 mm flow path the gas volume flow grows with distance and expands as the pressure falls linearly from
    the inlet to atmosphere (ideal gas, no slip); local conductivity kappa (1 - void)^1.5 (Bruggeman), averaged along the path."""
    p = (P_ATM + pin)*(1 - ZG) + P_ATM*ZG
    qg = I/(2*F_FARADAY)*R_GAS*(Tm + 273.15)*ZG/(p*1e5)
    return float(np.sum(WG*(1 - qg/(qg + Q))**1.5))


def j_of_gap(g, U, dU, Tin, Q, pin, J=None, iters=10, rf=0.0):
    J = (U - dU)/(g/K20 + rf) if J is None else J
    for _ in range(iters):
        Tm = Tin + 0.5*J*U*A/(RHOC*Q)
        J = (U - dU)/(g/(K20*(1 + ALPHA*(Tm - 20))*gas_factor(J*A, Q, Tm, pin)) + rf)   # gap and anodic film in series
    return J


RUNS = []
for name, r in cfg['runs'].items():
    d = np.loadtxt(os.path.join(DATA, r['file']), delimiter=',', skiprows=1)
    RUNS.append((d[:, 0], d[:, 1], d[:, 2].mean(), d[:, 3]*1e-3, r['initial_gap_mm']*1e-3,
                 d[:, 4].mean(), r['electrolyte_flow_L_per_min']/60e3, r['electrolyte_inlet_pressure_bar_gauge']))   # logged tool position


def simulate(run, p):
    """Gap history from Faraday's law with the logged tool advance (the servo can hold the feed), starting from the stated
    gap less the common backlash p[5] lost on the retract after touch-off."""
    t, I, U, pos, g0, Tin, Q, pin = run; dU = p[0]; pe = p[1:5]; rf = p[6]*1e-6
    dt = 0.05; n = int(round(t[-1]/dt)) + 1; g = g0 - p[5]*1e-3; out = np.empty(n); J = None
    tt = np.arange(n)*dt; feed = np.interp(tt + dt, t, pos) - np.interp(tt, t, pos)   # tool advance in each step
    for i in range(n):
        J = j_of_gap(g, U, dU, Tin, Q, pin, J, 10 if J is None else 3, rf); out[i] = J*A
        g += dt*eff(J, pe, Tin + 0.5*J*U*A/(RHOC*Q))*KV*J - feed[i]
    return np.interp(t, tt, out)


def res(p):
    return np.concatenate([(simulate(r, p) - r[1])/r[1] for r in RUNS])


fit = least_squares(res, [2.0, 0.9, 5.0, 10.0, 0.0, 0.0, 0.5], bounds=([0.0, 0.3, -20, 1.0, -0.03, -0.1, 0.0], [6.0, 1.0, 30, 100, 0.03, 0.1, 20.0]),
                    x_scale=[0.1, 0.01, 1.0, 1.0, 0.001, 0.002, 0.2])
p = fit.x
print(f'# backlash {p[5]*1e3:.1f} um; anodic film {p[6]:.3f} ohm mm^2; overpotential {p[0]:.3f} V, efficiency ({p[1]:.3f} {p[4]:+.5f} (T - 25)) (1 - exp(-(J - {p[2]:.2f})/{p[3]:.2f})), rms misfit {100*np.std(fit.fun):.2f} %')
import scipy.sparse as sps
from scipy.sparse.linalg import splu


def field_flux(yc, h, dx, ns, delta=0.0):
    """Unit-potential Laplace problem between cathode y = yc(x) (0) and anode y = yc + h (1), periodic in x. The gap is mapped
    to a rectangle (x, s), y = yc + s h; the transformed operator is discretised with central differences and solved directly.
    Returns |grad phi| on the anode."""
    nx = len(yc); s = np.linspace(0.0, 1.0, ns); ds = 1.0/(ns - 1)
    dxf = lambda q: (np.roll(q, -1, 0) - np.roll(q, 1, 0))/(2*dx)
    ycx, hx = dxf(yc), dxf(h)
    A_ = (ycx[:, None] + s[None, :]*hx[:, None])/h[:, None]          # x-derivative coupling of the mapping
    Ax = dxf(A_)
    Css = A_**2 + 1.0/h[:, None]**2; Cs = A_*(hx/h)[:, None] - Ax; Cxs = -2*A_
    N = nx*ns; idx = np.arange(N).reshape(nx, ns)
    I, Jn = np.meshgrid(np.arange(nx), np.arange(1, ns - 1), indexing='ij')
    c = idx[I, Jn]
    def at(di, dj): return idx[(I + di) % nx, Jn + dj]
    entries = [(c, -2/dx**2 - 2*Css[I, Jn]/ds**2), (at(-1, 0), np.full(c.shape, 1/dx**2)), (at(1, 0), np.full(c.shape, 1/dx**2)),
               (at(0, -1), Css[I, Jn]/ds**2 - Cs[I, Jn]/(2*ds)), (at(0, 1), Css[I, Jn]/ds**2 + Cs[I, Jn]/(2*ds)),
               (at(1, 1), Cxs[I, Jn]/(4*dx*ds)), (at(-1, -1), Cxs[I, Jn]/(4*dx*ds)),
               (at(1, -1), -Cxs[I, Jn]/(4*dx*ds)), (at(-1, 1), -Cxs[I, Jn]/(4*dx*ds))]
    r = np.concatenate([np.repeat(c.ravel()[None], 1, 0).ravel()]*len(entries))
    rr = np.concatenate([c.ravel() for _ in entries]); cc = np.concatenate([e[0].ravel() for e in entries])
    vv = np.concatenate([e[1].ravel() for e in entries])
    ya = yc + h; slope = dxf(ya); w = np.sqrt(1 + slope**2)
    top = idx[:, -1]; i = np.arange(nx)
    cs = delta*w/(2*ds*h); cx = -delta*slope/(w*2*dx)                # film: phi + delta dphi/dn = 1 on the anode
    rb = np.r_[idx[:, 0], top, top, top, top, top]
    cb = np.r_[idx[:, 0], top, idx[:, -2], idx[:, -3], top[(i + 1) % nx], top[(i - 1) % nx]]
    vb = np.r_[np.ones(nx), 1 + 3*cs, -4*cs, cs, cx, -cx]
    M = sps.csc_matrix((np.r_[vv, vb], (np.r_[rr, rb], np.r_[cc, cb])), shape=(N, N))
    rhs = np.zeros(N); rhs[top] = 1.0
    phi = splu(M).solve(rhs).reshape(nx, ns)
    dphids = (3*phi[:, -1] - 4*phi[:, -2] + phi[:, -3])/(2*ds); dphidx = dxf(phi[:, -1])
    return dphids*w/h - slope*dphidx/w, slope                         # normal derivative on the anode


def steady_profile(U, f, kap, Tg, nx=96, ns=49, dt=0.6):
    """Anode recedes along y at eta(J) kv J sqrt(1 + slope^2); the tool advances at f. March in time from a flat workpiece
    (the ECM gap is self-stabilising) until both speeds match everywhere."""
    pc = prod['cathode_face']; L, a = pc['L_mm']*1e-3, pc['a_mm']*1e-3
    dx = L/nx; xg = np.arange(nx)*dx; yc = a*np.cos(2*np.pi*xg/L); h = 0.5e-3 - yc
    for step in range(10000):
        g, slope = field_flux(yc, h, dx, ns, kap*p[6]*1e-6); J = kap*(U - p[0])*g
        vy = eff(J, p[1:5], Tg)*KV*J*np.sqrt(1 + slope**2)
        if np.max(np.abs(vy/f - 1)) < 2e-5: break
        h = h + dt*(vy - f)
    return xg/L, h


prod = cfg['production']; out = {}
for q, st in prod['settings'].items():
    U, f, Tg = st['gap_voltage_V'], st['tool_feed_rate_mm_per_min']/60e3, st['electrolyte_temperature_in_gap_C']
    kap = K20*(1 + ALPHA*(Tg - 20))
    xs, h = steady_profile(U, f, kap, Tg)
    out[q] = {f'{x:g}': float(np.interp(x, xs, h)*1e3) for x in prod['report_positions_x_over_L']}
    print('#', q, {k: round(v, 4) for k, v in out[q].items()})
os.makedirs(OUT, exist_ok=True)
json.dump({'gap_along_feed_mm': out}, open(os.path.join(OUT, 'results.json'), 'w'), indent=2)
