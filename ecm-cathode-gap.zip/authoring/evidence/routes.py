"""Variants of the ECM reduction for the corrugated cathode. alt_* are defensible choices (other efficiency laws, same 2-D
field, or a different treatment of the hydrogen in the runs); the others are shortcuts. Calibration: Faraday-integrated gap
(from the stated gap less a fitted common backlash, with the logged tool advance) and Ohm's law along each run, with the
gap and a fitted anodic film resistance in series and the path-averaged hydrogen conductance loss, unless the route says
otherwise;
production: periodic boundary-element field with a free anode, or the shortcut named. Each writes a complete submission
<out_dir>/<name>/results.json for grade.py.

    python routes.py <data_dir> <out_dir> [<route> ...]
"""
import json, os, sys
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import least_squares

src, OUTROOT = sys.argv[1], sys.argv[2]
from scipy.optimize import brentq
c = json.load(open(os.path.join(src, 'ecm_campaign.json')))
area = c['tool_face']['width_mm']*c['tool_face']['length_mm']/1e6
kv = c['workpiece']['volumetric_electrochemical_equivalent_mm3_per_C']/1e9
e = c['electrolyte']; k20, a_T = e['conductivity_at_20C_S_per_m'], e['conductivity_temperature_coefficient_per_K']


LAWS = {
    'rational': (lambda J, q: q[0]*np.maximum(J/1e4 - q[1], 0)/(np.maximum(J/1e4 - q[1], 0) + q[2]), [0.95, 5.0, 10.0], [0.3, -20, 0.5], [1.2, 25, 200]),
    'exp': (lambda J, q: np.maximum(q[0]*(1 - np.exp(-(J/1e4 - q[1])/q[2])), 0), [0.9, 5.0, 10.0], [0.3, -20, 1.0], [1.0, 30, 100]),
    'logistic': (lambda J, q: q[0]/(1 + np.exp(-(J/1e4 - q[1])/q[2])), [0.9, 20.0, 10.0], [0.3, -50, 0.5], [1.0, 80, 100]),
    'constant': (lambda J, q: np.full_like(np.asarray(J, float), q[0]), [0.8], [0.2], [1.0]),
    'unity': (lambda J, q: np.ones_like(np.asarray(J, float)), [], [], []),
}


runs = []
for nm, r in c['runs'].items():
    d = np.genfromtxt(os.path.join(src, r['file']), delimiter=',', names=True)
    runs.append(dict(t=d['time_s'], J=d['current_A']/area, U=d['gap_voltage_V'], Tm=0.5*(d['electrolyte_inlet_C'] + d['electrolyte_outlet_C']),
                     f=r['feed_rate_mm_per_min']/6e4, g0=r['initial_gap_mm']/1e3, Q=r['electrolyte_flow_L_per_min']/6e4,
                     pos=(d['tool_feed_mm'] - d['tool_feed_mm'][0])/1e3,
                     pin=r['electrolyte_inlet_pressure_bar_gauge']))


ZG, WG = np.polynomial.legendre.leggauss(24); ZG = 0.5*(ZG + 1); WG = 0.5*WG


def bubbles(r, gas):
    """Conductance factor for the cathodic hydrogen along each run (path-averaged Bruggeman), or a shortcut."""
    if gas == 'none': return np.ones_like(r['J'])
    pin = 0.0 if gas == 'atmospheric' else r['pin']; n = 1.0 if gas == 'linear' else 1.5
    p = ((1.013 + pin)*(1 - ZG) + 1.013*ZG)*1e5
    qg = (r['J']*area/(2*96485.0)*8.314*(r['Tm'] + 273.15))[:, None]*ZG[None, :]/p[None, :]
    return np.sum(WG*(1 - qg/(qg + r['Q']))**n, axis=1)


DEFECT = {'trust_gaps': False, 'nominal_feed': False, 'no_film': False, 'per_run_offsets': False}


def calibrate(law, with_dU=True, gas='path', temp=True):
    fe0, q0, lo, hi = LAWS[law]
    nq = len(q0)
    if temp:                                   # efficiency x (1 + c (T - 25 C)), c fitted
        fe = lambda J, q, T: fe0(J, q[:nq])*(1 + q[nq]*(T - 25.0)); q0 = q0 + [0.0]; lo = lo + [-0.03]; hi = hi + [0.03]
    else:
        fe = lambda J, q, T: fe0(J, q)
    bub = [bubbles(r, gas) for r in runs]
    fit_bl = not DEFECT['trust_gaps']; nbl = len(runs) if DEFECT['per_run_offsets'] else 1
    fit_rf = not (DEFECT['no_film'] or DEFECT['per_run_offsets'])
    def mismatch(p):
        rf = p[-1]*1e-6 if fit_rf else 0.0; p = p[:-1] if fit_rf else p
        bl = p[-nbl:]*1e-3 if fit_bl else np.zeros(1); p = p[:-nbl] if fit_bl else p
        dU = p[0] if with_dU else 0.0; q = p[1:] if with_dU else p; out = []
        for k, (r, b) in enumerate(zip(runs, bub)):
            adv = r['f']*(r['t'] - r['t'][0]) if DEFECT['nominal_feed'] else r['pos']     # tool advance
            g = np.maximum(r['g0'] - bl[k % len(bl)] + cumulative_trapezoid(fe(r['J'], q, r['Tm'])*kv*r['J'], r['t'], initial=0.0) - adv, 1e-6)
            out.append(r['J']*(g/(k20*(1 + a_T*(r['Tm'] - 20))*b) + rf)/(r['U'] - dU) - 1)   # gap and anodic film in series
        return np.concatenate(out)
    x0 = ([2.0] if with_dU else []) + q0; lb = ([0.0] if with_dU else []) + lo; ub = ([6.0] if with_dU else []) + hi
    if fit_bl: x0, lb, ub = x0 + [0.0]*nbl, lb + [-0.1]*nbl, ub + [0.1]*nbl    # backlash (mm) lost at touch-off: common, or per run
    if fit_rf: x0, lb, ub = x0 + [1.0], lb + [0.0], ub + [20.0]                # anodic film resistance, ohm mm^2
    p = least_squares(mismatch, x0, bounds=(lb, ub)).x if x0 else np.array([])
    rf = p[-1]*1e-6 if fit_rf else 0.0; p = p[:-1] if fit_rf else p
    if fit_bl: p = p[:-nbl]
    dU = p[0] if with_dU else 0.0; q = p[1:] if with_dU else p
    return (lambda J, T: fe(J, q, T)), dU, rf


GX, GW = np.polynomial.legendre.leggauss(8)


def bem_flux(xn, yc_n, ya_n, Lp, delta=0.0):
    """Normal flux d(phi)/dn (outward from the electrolyte) at element midpoints of cathode and anode for phi = 0 / 1."""
    def elements(xs, ys, reverse):
        X = np.r_[xs, xs[0] + Lp]; Y = np.r_[ys, ys[0]]
        if reverse: X, Y = X[::-1], Y[::-1]
        p0 = np.c_[X[:-1], Y[:-1]]; p1 = np.c_[X[1:], Y[1:]]
        return p0, p1
    c0, c1 = elements(xn, yc_n, False)          # cathode traversed in +x: electrolyte above -> outward normal points down
    a0, a1 = elements(xn, ya_n, True)           # anode traversed in -x: outward normal points up
    P0 = np.r_[c0, a0]; P1 = np.r_[c1, a1]; n_el = len(P0)
    mid = 0.5*(P0 + P1); tv = P1 - P0; ln = np.hypot(tv[:, 0], tv[:, 1]); tu = tv/ln[:, None]
    nrm = np.c_[tu[:, 1], -tu[:, 0]]           # outward normal for this traversal (domain on the left)
    phi_b = np.r_[np.zeros(len(c0)), np.ones(len(a0))]
    gp = P0[None, :, None, :] + (0.5*(GX + 1))[None, None, :, None]*tv[None, :, None, :]      # (1, el, gauss, 2)
    dxy = mid[:, None, None, :] - gp                                                           # (col, el, gauss, 2)
    k = 2*np.pi/Lp
    ch = np.cosh(k*dxy[..., 1]); co = np.cos(k*dxy[..., 0]); den = 2*(ch - co)
    G = -np.log(np.maximum(den, 1e-300))/(4*np.pi)
    dGdx = -(k*np.sin(k*dxy[..., 0]))*2/den/(4*np.pi)*(-1)         # derivative with respect to the source point
    dGdy = -(k*np.sinh(k*dxy[..., 1]))*2/den/(4*np.pi)*(-1)
    dGdn = dGdx*nrm[None, :, None, 0] + dGdy*nrm[None, :, None, 1]
    w = (0.5*GW)[None, None, :]*ln[None, :, None]
    Gm = np.sum(G*w, axis=2); Hm = np.sum(dGdn*w, axis=2)
    ii = np.arange(n_el)                         # own element: singular part -(1/2pi) ln r integrated exactly
    r_self = np.hypot(*(mid[:, None, None, :] - gp)[ii, ii].transpose(2, 0, 1)) if False else None
    sing_q = -(1/(2*np.pi))*np.log(np.maximum(np.hypot(dxy[ii, ii, :, 0], dxy[ii, ii, :, 1]), 1e-300))
    regular = np.sum((G[ii, ii] - sing_q)*w[0, ii], axis=1)
    Gm[ii, ii] = regular - (1/(2*np.pi))*ln*(np.log(ln/2) - 1)
    Hm[ii, ii] = 0.0
    # 0.5 phi_i + sum_j H_ij phi_j = sum_j G_ij q_j, with phi = 1 - delta q on the anode (film)
    D = np.r_[np.zeros(len(c0)), np.full(len(a0), delta)]
    qn = np.linalg.solve(Gm + (Hm + 0.5*np.eye(n_el))*D[None, :], 0.5*phi_b + Hm@phi_b)
    return qn[len(c0):][::-1], mid[len(c0):][::-1, 0]


prod = c['production']; Lp = prod['cathode_face']['L_mm']/1e3; amp = prod['cathode_face']['a_mm']/1e3
POS = prod['report_positions_x_over_L']


def production(eta_f, dU, mode, rf=0.0):
    res = {}
    for nm, st in prod['settings'].items():
        U, f, Tg = st['gap_voltage_V'], st['tool_feed_rate_mm_per_min']/6e4, st['electrolyte_temperature_in_gap_C']
        kap = k20*(1 + a_T*(Tg - 20)); n = 96; xn = np.arange(n)*Lp/n; yc_n = amp*np.cos(2*np.pi*xn/Lp)
        jf = lambda g: (U - dU)/(g/kap + rf)
        flat = lambda fn: brentq(lambda g: eta_f(jf(g), Tg)*kv*jf(g) - fn, 1e-7, 5e-2)
        if mode == 'field':
            ya_n = np.full(n, 0.5e-3)
            for it in range(20000):
                flux, xm = bem_flux(xn, yc_n, ya_n, Lp, kap*rf); Jm = kap*(U - dU)*np.abs(flux)
                slope_m = np.diff(np.r_[ya_n, ya_n[0]])/np.diff(np.r_[xn, Lp])
                vm = eta_f(Jm, Tg)*kv*Jm*np.sqrt(1 + slope_m**2); vn = 0.5*(vm + np.roll(vm, 1))
                if np.max(np.abs(vn/f - 1)) < 2e-5: break
                ya_n = ya_n + 0.5*(vn - f)
            gap = ya_n - yc_n
        elif mode == 'local_cos_theta':                 # local plane-parallel gap normal to the cathode, normal feed f cos(theta)
            slope = -amp*2*np.pi/Lp*np.sin(2*np.pi*xn/Lp); cth = 1/np.sqrt(1 + slope**2)
            gap = np.array([flat(f*cc)/cc for cc in cth])
        else:                                           # tool shape copied at the flat-tool equilibrium gap
            gap = np.full(n, flat(f))
        res[nm] = {f'{x:g}': float(np.interp(x*Lp, np.r_[xn, Lp], np.r_[gap, gap[0]])*1e3) for x in POS}
    return res


ROUTES = {
    'alt_exponential_efficiency': ('exp', True, 'field'),
    'gas_ignored': ('exp', True, 'field', 'none'),
    'stated_initial_gaps_trusted': ('exp', True, 'field', 'path', True, 'trust_gaps'),
    'nominal_feed_rate_assumed': ('exp', True, 'field', 'path', True, 'nominal_feed'),
    'efficiency_temperature_ignored': ('exp', True, 'field', 'path', False),
    'gas_and_temperature_ignored': ('exp', True, 'field', 'none', False),
    'gas_at_atmospheric_pressure': ('exp', True, 'field', 'atmospheric'),
    'gas_linear_conductivity_loss': ('exp', True, 'field', 'linear'),
    'alt_logistic_efficiency': ('logistic', True, 'field'),
    'local_cos_theta_gap': ('exp', True, 'local_cos_theta'),
    'tool_shape_copied_at_flat_gap': ('exp', True, 'copy'),
    'efficiency_taken_as_constant': ('constant', True, 'field', 'path', False),
    'efficiency_taken_as_100_percent': ('unity', True, 'field', 'path', False),
    'overpotential_ignored': ('exp', False, 'field'),
    'anodic_film_ignored_common_offset': ('exp', True, 'field', 'path', True, 'no_film'),
    'anodic_film_ignored_offset_per_run': ('exp', True, 'field', 'path', True, 'per_run_offsets'),
}
ONLY = sys.argv[3:]                                  # optional: names of the routes to run (default: all)
for name, spec in ROUTES.items():
    if ONLY and name not in ONLY: continue
    law, wdu, mode = spec[:3]; gas = spec[3] if len(spec) > 3 else 'path'; temp = spec[4] if len(spec) > 4 else True
    DEFECT.update({k: (len(spec) > 5 and spec[5] == k) for k in DEFECT})
    eta_f, dU, rf = calibrate(law, wdu, gas, temp)
    os.makedirs(os.path.join(OUTROOT, name), exist_ok=True)
    json.dump({'gap_along_feed_mm': production(eta_f, dU, mode, rf)}, open(os.path.join(OUTROOT, name, 'results.json'), 'w'), indent=2)
