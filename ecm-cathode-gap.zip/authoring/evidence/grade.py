"""Calibration of the 3 % bound with the real checks, on the shipped runs (seed 0) and regenerated campaigns (ECM_SEED).

Every submitter (solution/solve.sh, bem_reduction.py, each variant of routes.py) writes results.json in its own
folder; tests/ecm_checks.py is copied unchanged beside the campaign's expected.json and run by pytest with the CTRF plugin,
as tests/test.sh does; reward.txt and ctrf.json stay in the folder. Output: one line per submission.

    python grade.py <work_dir> <seed> [<seed> ...]        (GRADE_RESCORE=1: rerun the checks on existing submissions)
"""
import json, os, shutil, subprocess, sys
base = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
ev = os.path.join(base, 'authoring', 'evidence'); py = sys.executable; wd = os.path.abspath(sys.argv[1])
for seed in sys.argv[2:]:
    w = os.path.join(wd, f'seed{seed}'); ck = os.path.join(w, 'checks'); os.makedirs(ck, exist_ok=True)
    if seed == '0':
        data = os.path.join(base, 'environment', 'data'); shutil.copy(os.path.join(base, 'tests', 'expected.json'), ck)
    elif os.environ.get('GRADE_RESCORE') == '1':
        data = os.path.join(w, 'data')
    else:
        data = os.path.join(w, 'data')
        subprocess.run([py, os.path.join(base, 'authoring', 'provenance', 'generate.py'), data, ck], check=True, env={**os.environ, 'ECM_SEED': seed})
    shutil.copy(os.path.join(base, 'tests', 'ecm_checks.py'), ck)
    subs = {'reference': os.path.join(w, 'reference'), 'bem_independent': os.path.join(w, 'bem_independent')}
    for f in subs.values(): os.makedirs(f, exist_ok=True)
    if os.environ.get('GRADE_RESCORE') != '1':        # GRADE_RESCORE=1: keep the submissions, rerun only the checks
        subprocess.run(['bash', os.path.join(base, 'solution', 'solve.sh')], check=True, stdout=subprocess.DEVNULL,
                       env={**os.environ, 'DATA_DIR': data, 'OUT_DIR': subs['reference']})
        subprocess.run([py, os.path.join(ev, 'bem_reduction.py'), data, os.path.join(subs['bem_independent'], 'results.json')],
                       check=True, stdout=subprocess.DEVNULL)
        subprocess.run([py, os.path.join(ev, 'routes.py'), data, os.path.join(w, 'routes')], check=True)
    for n in sorted(os.listdir(os.path.join(w, 'routes'))): subs[n] = os.path.join(w, 'routes', n)
    truth = json.load(open(os.path.join(ck, 'expected.json')))['gap_along_feed_mm']
    for name, f in subs.items():
        r = subprocess.run([py, '-m', 'pytest', os.path.join(ck, 'ecm_checks.py'), '-q', '-p', 'no:cacheprovider', '--rootdir', ck, '-c', os.devnull,
                            '-p', 'ctrf', '--ctrf', os.path.join(f, 'ctrf.json')], capture_output=True, text=True,
                           env={**os.environ, 'RESULTS_PATH': os.path.join(f, 'results.json'), 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'})
        rw = int(r.returncode == 0); open(os.path.join(f, 'reward.txt'), 'w').write(f'{rw}\n')
        sm = json.load(open(os.path.join(f, 'ctrf.json')))['results']['summary']
        got = json.load(open(os.path.join(f, 'results.json')))['gap_along_feed_mm']
        eg = max(abs(got[q][a]/truth[q][a] - 1) for q in truth for a in truth[q])
        print(f'seed={seed} | {name:34s} | reward={rw} | tests {sm["passed"]}/{sm["tests"]} | worst gap error {100*eg:5.1f} % | '
              f'{eg/0.03:5.2f} x bound', flush=True)
