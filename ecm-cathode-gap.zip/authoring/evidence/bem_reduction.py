"""Independent reduction (no code shared with solution/ecm_gap_model.py or the generator).

Calibration: the gap of every characterisation run is rebuilt from the stated gap less one fitted touch-off offset common to
all runs, the logged tool advance and Faraday's law integrated over the measured current, and
Ohm's law, with the gap and a resistive anodic film in series, is imposed along every run with the conductivity at the logged mean temperature, reduced for the cathodic hydrogen
by the hydrogen the cathode evolves (I/(2F) mol/s, ideal gas at a pressure falling linearly from the inlet to atmosphere,
no slip, Bruggeman on the local liquid fraction, averaged along the path by the trapezoid rule on 41 points, where the
reference uses Gauss quadrature inside its run simulation); saturating-exponential efficiency law
eta = e (1 + c (T - 25 C)) (1 - exp(-(J - Ja)/Jb)), T the logged mean electrolyte temperature (a relative temperature slope,
where the reference uses an absolute one); unknowns dU, e, Ja, Jb, c, the film resistance R_f and the common touch-off offset by least squares on
Ohm's law along every run (the reference instead simulates every run and fits the current traces).
Production field: a boundary-element method instead of a finite-difference grid. With the periodic Green's function of the
Laplace operator, G = -(1/4 pi) ln[2 (cosh(2 pi dy / L) - cos(2 pi dx / L))], the potential is represented by its boundary
values: phi = 0 on the cathode, phi = U - dU - R_f J on the anode (the film); the unknown normal fluxes on both curves follow from collocation
at element midpoints (straight elements, 8-point Gauss quadrature, analytic integral of the logarithmic singularity on the
own element). The anode nodes are marched along the feed until eta(J) kv J sqrt(1 + slope^2) equals the feed everywhere.

    python bem_reduction.py <data_dir> <results.json>
"""
import json, os, sys
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import least_squares

src, dst = sys.argv[1], sys.argv[2]
c = json.load(open(os.path.join(src, 'ecm_campaign.json')))
area = c['tool_face']['width_mm']*c['tool_face']['length_mm']/1e6
kv = c['workpiece']['volumetric_electrochemical_equivalent_mm3_per_C']/1e9
e = c['electrolyte']; k20, a_T = e['conductivity_at_20C_S_per_m'], e['conductivity_temperature_coefficient_per_K']


def eta(J, q, T):
    """Saturating efficiency law e (1 - exp(-(J - Ja)/Jb)) scaled by (1 + c (T - 25 C)) for the electrolyte temperature
    (q = e, Ja, Jb, c); a relative temperature slope, where the reference uses an absolute one."""
    return np.maximum(q[0]*(1 + q[3]*(T - 25.0))*(1 - np.exp(-(J/1e4 - q[1])/q[2])), 0.0)


runs = []
for nm, r in c['runs'].items():
    d = np.genfromtxt(os.path.join(src, r['file']), delimiter=',', names=True)
    Tm = 0.5*(d['electrolyte_inlet_C'] + d['electrolyte_outlet_C']); Q = r['electrolyte_flow_L_per_min']/6e4
    z = np.linspace(0.0, 1.0, 41)                                             # along the flow path, trapezoid rule
    pz = (1.013 + r['electrolyte_inlet_pressure_bar_gauge']*(1 - z))*1e5        # pressure falls linearly to atmosphere
    gas = (d['current_A']/(2*96485.0)*8.314*(Tm + 273.15))[:, None]*z[None, :]/pz[None, :]   # H2 volume flow so far
    bub = np.trapezoid((Q/(Q + gas))**1.5, z, axis=1)                          # Bruggeman on the local liquid fraction
    runs.append(dict(t=d['time_s'], J=d['current_A']/area, U=d['gap_voltage_V'], Tm=Tm, bub=bub,
                     f=r['feed_rate_mm_per_min']/6e4, g0=r['initial_gap_mm']/1e3, pos=(d['tool_feed_mm'] - d['tool_feed_mm'][0])/1e3))


def mismatch(p):
    dU, q, g_off, rf = p[0], p[1:5], p[5]*1e-3, p[6]*1e-6; out = []
    for r in runs:                            # gap = stated gap - common touch-off offset + dissolved depth - logged tool advance
        g = np.maximum(r['g0'] - g_off + cumulative_trapezoid(eta(r['J'], q, r['Tm'])*kv*r['J'], r['t'], initial=0.0) - r['pos'], 1e-6)
        out.append(r['J']*(g/(k20*(1 + a_T*(r['Tm'] - 20))*r['bub']) + rf)/(r['U'] - dU) - 1)   # gap and anodic film in series
    return np.concatenate(out)


p = least_squares(mismatch, [2.0, 0.9, 5.0, 10.0, 0.0, 0.0, 1.0], bounds=([0, 0.3, -20, 0.5, -0.03, -0.1, 0.0], [6, 1.2, 30, 100, 0.03, 0.1, 20])).x
dU, q, rf = p[0], p[1:5], p[6]*1e-6
print('dU', round(dU, 3), 'efficiency params', np.round(q, 3), 'touch-off offset', round(p[5]*1e3, 1), 'um', 'film', round(p[6], 3), 'ohm mm^2')

GX, GW = np.polynomial.legendre.leggauss(8)


def bem_flux(xn, yc_n, ya_n, Lp, delta=0.0):
    """Normal flux d(phi)/dn (outward from the electrolyte) at element midpoints of cathode and anode for phi = 0 / 1."""
    def elements(xs, ys, reverse):
        X = np.r_[xs, xs[0] + Lp]; Y = np.r_[ys, ys[0]]
        if reverse: X, Y = X[::-1], Y[::-1]
        p0 = np.c_[X[:-1], Y[:-1]]; p1 = np.c_[X[1:], Y[1:]]
        return p0, p1
    c0, c1 = elements(xn, yc_n, False)          # cathode traversed in +x: electrolyte above -> outward normal points down
    a0, a1 = elements(xn, ya_n, True)           # anode traversed in -x: outward normal points up
    P0 = np.r_[c0, a0]; P1 = np.r_[c1, a1]; n_el = len(P0)
    mid = 0.5*(P0 + P1); tv = P1 - P0; ln = np.hypot(tv[:, 0], tv[:, 1]); tu = tv/ln[:, None]
    nrm = np.c_[tu[:, 1], -tu[:, 0]]           # outward normal for this traversal (domain on the left)
    phi_b = np.r_[np.zeros(len(c0)), np.ones(len(a0))]
    gp = P0[None, :, None, :] + (0.5*(GX + 1))[None, None, :, None]*tv[None, :, None, :]      # (1, el, gauss, 2)
    dxy = mid[:, None, None, :] - gp                                                           # (col, el, gauss, 2)
    k = 2*np.pi/Lp
    ch = np.cosh(k*dxy[..., 1]); co = np.cos(k*dxy[..., 0]); den = 2*(ch - co)
    G = -np.log(np.maximum(den, 1e-300))/(4*np.pi)
    dGdx = -(k*np.sin(k*dxy[..., 0]))*2/den/(4*np.pi)*(-1)         # derivative with respect to the source point
    dGdy = -(k*np.sinh(k*dxy[..., 1]))*2/den/(4*np.pi)*(-1)
    dGdn = dGdx*nrm[None, :, None, 0] + dGdy*nrm[None, :, None, 1]
    w = (0.5*GW)[None, None, :]*ln[None, :, None]
    Gm = np.sum(G*w, axis=2); Hm = np.sum(dGdn*w, axis=2)
    ii = np.arange(n_el)                         # own element: singular part -(1/2pi) ln r integrated exactly
    r_self = np.hypot(*(mid[:, None, None, :] - gp)[ii, ii].transpose(2, 0, 1)) if False else None
    sing_q = -(1/(2*np.pi))*np.log(np.maximum(np.hypot(dxy[ii, ii, :, 0], dxy[ii, ii, :, 1]), 1e-300))
    regular = np.sum((G[ii, ii] - sing_q)*w[0, ii], axis=1)
    Gm[ii, ii] = regular - (1/(2*np.pi))*ln*(np.log(ln/2) - 1)
    Hm[ii, ii] = 0.0
    # 0.5 phi_i + sum_j H_ij phi_j = sum_j G_ij q_j, with phi = 1 - delta q on the anode (film in series)
    D = np.r_[np.zeros(len(c0)), np.full(len(a0), delta)]
    qn = np.linalg.solve(Gm + (Hm + 0.5*np.eye(n_el))*D[None, :], 0.5*phi_b + Hm@phi_b)
    return qn[len(c0):][::-1], mid[len(c0):][::-1, 0]


prod = c['production']; Lp = prod['cathode_face']['L_mm']/1e3; amp = prod['cathode_face']['a_mm']/1e3
res = {}
for nm, st in prod['settings'].items():
    U, f, Tg = st['gap_voltage_V'], st['tool_feed_rate_mm_per_min']/6e4, st['electrolyte_temperature_in_gap_C']
    kap = k20*(1 + a_T*(Tg - 20)); n = 96; xn = np.arange(n)*Lp/n
    yc_n = amp*np.cos(2*np.pi*xn/Lp); ya_n = np.full(n, 0.5e-3)
    for it in range(20000):
        flux, xm = bem_flux(xn, yc_n, ya_n, Lp, kap*rf)                    # flux at anode element midpoints (per volt)
        Jm = kap*(U - dU)*np.abs(flux)
        xa = np.r_[xn, Lp]; ya_ext = np.r_[ya_n, ya_n[0]]
        slope_m = np.diff(ya_ext)/np.diff(xa)
        vm = eta(Jm, q, Tg)*kv*Jm*np.sqrt(1 + slope_m**2)          # vertical recession speed at midpoints
        vn_nodes = 0.5*(vm + np.roll(vm, 1))                       # nodes sit between elements
        if np.max(np.abs(vn_nodes/f - 1)) < 2e-5: break
        ya_n = ya_n + 0.5*(vn_nodes - f)
    gap = ya_n - yc_n
    res[nm] = {f'{x:g}': float(np.interp(x*Lp, np.r_[xn, Lp], np.r_[gap, gap[0]])*1e3) for x in prod['report_positions_x_over_L']}
    print(nm, it, {k_: round(v, 4) for k_, v in res[nm].items()})
json.dump({'gap_along_feed_mm': res}, open(dst, 'w'), indent=2)
