# ecm-cathode-gap

An ECM tool designer needs the gap profile a shaped cathode will settle into. This task gives seventeen flat-tool characterisation runs of Inconel 718 in sodium nitrate, plus a production cathode whose face is corrugated with a 1.6 mm wavelength (a = 0.25 mm). The solver must find the steady gap along the feed at five positions across the corrugation, for two production settings with the electrolyte at 50 °C and free of gas. The runs and the production truth come from a seeded model (`authoring/provenance/generate.py`).

## Difficulty

**Who does this work:** ECM process and tooling engineers at aero-engine and turbine manufacturers. Before cutting a cathode, they characterise the alloy and electrolyte on a flat tool and predict the gap the shaped cathode will run at, because the workpiece takes the cathode shape offset by that gap. A wrong gap profile scraps the cathode and the parts.

**Why the shortcuts fail:** the corrugation is only a few gaps long. Treating the gap as locally plane-parallel with the cos-theta rule misses by up to 54 %. Copying the tool shape at the flat-tool gap misses by up to 43 %. The steady shape comes from a 2-D Laplace problem with a moving anode.

**What has to be inferred first:** the runs never measure the gap. The gap history follows from the initial gap, the logged tool advance and Faraday's law, and the current transients reveal the rest: a current efficiency that rises with current density and falls as the electrolyte gets hotter, an electrode overpotential, and hydrogen in the runs (the production gap is gas-free).

**Hidden effect 1: a resistive anodic film (the decisive trap).** In nitrate the dissolving surface carries a passive/salt film whose resistance, 1.7 Ω mm², sits in series with the electrolyte: J = (U − dU)/(g/κ + R_f). In a flat run the film acts exactly like an extra gap of κ R_f, about 13–21 µm across the runs. It looks like an error in the stated initial gaps, and the campaign file says the gaps were set by touching off and retracting, which invites that reading. Two things tell the two apart:

- an initial-gap error is the same length in every run, while κ R_f follows the conductivity in the gap. It is smaller in the runs with the most hydrogen (12.8 µm at 2 L/min) and larger in the runs with preheated electrolyte (17.5–20.8 µm at 33–48 °C inlet);
- a feed-screw backlash lost on the retract makes the gap smaller than stated, whereas the film makes the current behave as if it were larger.

A solver that fits one common touch-off offset instead of the film still fits all seventeen current traces to near the logger noise (rms 0.35 % against 0.29 %). It recovers an offset of −3.6 µm, a gap larger than stated, and its production gaps miss by up to 13.8 % (4.6 times the 3 % bound). In production the gap is gas-free at 50 °C, so κ R_f grows to 22 µm, and on the corrugated face the film is a Robin condition φ + κ R_f ∂φ/∂n = U − dU on the anode, which also evens out the current over the profile. Fitting a separate touch-off offset to every run fits the runs equally well but leaves nothing to carry the film to production. It misses by 13.2–13.5 %.

**Hidden effect 2: the stated initial gaps are also too large.** The retract after touch-off reverses the feed axis, so the backlash of the feed screw is lost: every run also starts 12 µm closer than stated. The common backlash and the film separate only because the film scales with the conductivity. Trusting the stated gaps while fitting the film misses by up to 10.5 %.

**Hidden effect 3: the feed was held during one run.** In R9 the servo held the feed for 45 s (140–185 s). `ecm_campaign.json` gives only the nominal feed rate; the hold shows in the logged `tool_feed_mm`. A gap history built from the nominal feed rate misses by up to 10.6 %.

**Hidden effect 4: hydrogen, and the efficiency temperature slope.** The cathode evolves one H₂ per two electrons. At the runs' flows of 2–8 L/min and inlet pressures of 0.2–2.8 bar gauge, the void grows from zero at the inlet edge to about 13–35 % at the outlet. The bubbles cut the conductivity (Bruggeman, κ (1 − void)^1.5). Because the film is read from how the apparent offset follows the conductivity, the gas model now matters:

- with the inlet pressure neglected, the error is up to 7.1 %;
- with a linear conductivity loss, up to 13.3 %;
- ignoring the gas altogether comes within 0.9 %, because the film and the backlash then absorb it.

The saturated efficiency drops by 0.45 percentage points per kelvin, and production runs at 50 °C. An efficiency law of current density alone misses by up to 50 %.

The truth is the steady free-boundary solution with the Robin anode condition on a 128 × 65 boundary-fitted grid. In the flat limit the Robin solver reproduces J = (U − dU)/(g/κ + R_f) to 1e-13.

## Reference solution

`solution/solve.sh` runs `solution/ecm_gap_model.py` in two steps:

1. Fit the parameters to the seventeen current traces together: the overpotential, the efficiency law (e₂₅ + s (T − 25 °C)) (1 − exp(−(J − J0)/Jc)), the film resistance R_f and one common touch-off backlash. Each run is simulated from its stated gap less the backlash, with the logged tool advance and J = (U − dU)/(g/κ_eff + R_f). The conductivity is Joule-heated and reduced by the hydrogen void, which comes from Faraday's law and the ideal-gas volume at a pressure falling linearly from inlet to atmosphere, with the Bruggeman loss averaged along the 20 mm flow path.
2. Solve the potential on a periodic boundary-fitted finite-difference grid, with the film as a Robin condition on the anode. March the anode along the feed from a flat workpiece until its recession speed η(J) kv J √(1 + slope²) equals the feed everywhere.

It recovers the film (1.705 Ω mm², true 1.7), the backlash (12.0 µm, true 12), the overpotential (2.701 V, true 2.70) and the temperature slope (−0.00450 per K, true −0.0045). It runs in about ten minutes on two CPUs.

## Verification

`tests/ecm_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `gap_along_feed_mm` → `A`, `B` → the five positions. Malformed output fails every test as a test failure. Ten separately named tests then require each gap to be finite, positive and within 3 % of the steady 2-D solution. Reward is 1 only if all eleven pass.

**Calibration:** `authoring/evidence/grade.py` regenerates the runs and the truth for seeds 1–5 (new logger noise) beside the shipped seed 0. It grades complete submissions with the unchanged check file through pytest with the CTRF plugin, as `tests/test.sh` does. Each submission keeps its `reward.txt` and `ctrf.json`, and the summary is in `authoring/evidence/grading_results.txt`. The summary comes from scoring the saved submissions with the final check file (`GRADE_RESCORE=1`).

**Reward 1 on all six data sets (11/11 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.1–0.6 % (0.04–0.20× the bound) |
| `authoring/evidence/bem_reduction.py`, an independent reduction with no shared code and different numerics: Ohm's law with the gap and the film in series imposed along Faraday-integrated gap histories (stated gap less a fitted common offset, logged tool advance), the hydrogen loss by the trapezoid rule along the path, a relative temperature slope of the efficiency, and a periodic boundary-element method with the film as a Robin condition on free anode nodes | 0.5–2.2 % (0.16–0.75× the bound) |
| Same calibration with the boundary-element field (`routes.py`) | 0.5–2.2 % (0.16–0.74× the bound) |
| Hydrogen ignored in the runs (film and backlash absorb most of it) | 0.5–2.0 % (0.18–0.66× the bound) |

The 3 % bound is set by the correct-physics reductions with different numerics. They read the film from a 13–21 µm conductivity-scaled offset under 0.3 % logger noise, and on two of the six data sets they land at 2.2 %.

**Reward 0 on all six data sets (same file, `authoring/evidence/routes.py`):**

| Route | Tests passed | Largest error |
|---|---|---|
| Anodic film ignored, one common touch-off offset | 1/11 | 13.4–13.7 % (4.5–4.6×) |
| Anodic film ignored, a touch-off offset fitted for every run | 1/11 | 13.2–13.5 % (4.4–4.5×) |
| Stated initial gaps trusted (backlash ignored, film fitted) | 1/11 | 10.4–10.6 % (3.5×) |
| Nominal feed rate assumed (feed hold in R9 ignored) | 1–6/11 | 7.2–11.7 % (2.4–3.9×) |
| Hydrogen at atmospheric pressure (inlet pressure neglected) | 1–6/11 | 6.0–10.7 % (2.0–3.6×) |
| Linear conductivity loss for the hydrogen | 1/11 | 13.3–13.6 % (4.4–4.5×) |
| Logistic efficiency law | 1–4/11 | 5.8–10.1 % (1.9–3.4×) |
| Overpotential ignored | 3–8/11 | 5.0–8.4 % (1.7–2.8×) |
| Temperature dependence of the efficiency ignored | 1/11 | 50.2 % (16.7×) |
| Hydrogen and temperature both ignored | 1/11 | 50.5 % (16.8×) |
| Local plane-parallel cos-theta gap | 1/11 | 53.4–56.0 % (17.8–18.7×) |
| Workpiece copies the tool at the flat-tool gap | 1/11 | 41.4–43.7 % (13.8–14.6×) |
| Efficiency 100 % | 1/11 | 76.1 % (25.4×) |
| One constant efficiency (no steady gap exists; the output is not a finite number and is rejected) | 1/11 | — |

**Trivial answers and the instances they pass:** reward needs all ten gaps within 3 %, and no constant passes more than three of them, so no constant answer earns the reward. Checked against `tests/expected.json`:

| Trivial answer | Value (mm) | Instances passed |
|---|---|---|
| Zero | 0 | none |
| Flat-tool equilibrium gap of `A` / of `B` | 0.1795 / 0.3763 | none |
| Mean of `A` | 0.2447 | none |
| Mean or median of `B` | 0.4684 / 0.4762 | `B` x/L = 0.25 |
| Mean of all ten | 0.3566 | `B` x/L = 0.125 |
| Median of `A` | 0.2716 | `A` x/L = 0.25 |
| Median of all ten | 0.3064 | `A` x/L = 0.375, `B` x/L = 0 |
| Best single constant (0.3032–0.3062) | 0.3032–0.3062 | `A` x/L = 0.375, `A` x/L = 0.5, `B` x/L = 0 |

Zero or negative gaps are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver cannot reproduce the noise and subtract it.

The hidden film resistance, overpotential, efficiency law with its temperature slope, backlash, feed hold and run equilibria are in `authoring/evidence/generator_truth.json`.
