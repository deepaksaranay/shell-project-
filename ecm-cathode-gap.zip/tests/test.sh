#!/usr/bin/env bash
# Grades /app/output/results.json with ecm_checks.py; reward.txt gets 1 only when all checks pass. CTRF from the plugin.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests || exit 0
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest /tests/ecm_checks.py --rootdir=/tests -c /dev/null -p no:cacheprovider \
    -p ctrf --ctrf /logs/verifier/ctrf.json -q && echo 1 > /logs/verifier/reward.txt
exit 0
