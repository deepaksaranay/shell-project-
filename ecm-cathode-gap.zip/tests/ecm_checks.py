"""Steady gaps under the corrugated production cathode, against the 2-D ECM model that produced the characterisation runs."""
import json
import math
import os
from pathlib import Path

ANSWER = Path(os.environ.get('RESULTS_PATH', '/app/output/results.json'))
TRUE = json.loads(Path(__file__).with_name('expected.json').read_text())['gap_along_feed_mm']
SETTINGS = ['A', 'B']
QUANTITIES = sorted(TRUE['A'], key=float)            # positions x / L, as strings
REL_TOL = 0.03


def _unique(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise ValueError(f'key {k} given twice')
        d[k] = v
    return d


def _parse():
    """(targets, None) when the file is well formed, otherwise (None, message)."""
    if ANSWER.is_symlink() or not ANSWER.is_file():
        return None, 'no regular results.json'
    try:
        obj = json.loads(ANSWER.read_text(), object_pairs_hook=_unique)
    except ValueError as err:
        return None, f'results.json rejected: {err}'
    if not isinstance(obj, dict) or list(obj) != ['gap_along_feed_mm']:
        return None, 'results.json must hold exactly one key, gap_along_feed_mm'
    tg = obj['gap_along_feed_mm']
    if not isinstance(tg, dict) or sorted(tg) != SETTINGS:
        return None, f'gap_along_feed_mm must hold exactly {SETTINGS}'
    for s in SETTINGS:
        if not isinstance(tg[s], dict) or sorted(tg[s]) != sorted(QUANTITIES):
            return None, f'gap_along_feed_mm.{s} must hold exactly the positions {QUANTITIES}'
    return tg, None


PARSED = _parse()


def test_answer_well_formed():
    assert PARSED[1] is None, PARSED[1]


def _check(setting, quantity):
    def t():
        tg, problem = PARSED
        assert problem is None, problem
        x = tg[setting][quantity]
        assert isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x > 0, \
            f'{setting}.{quantity} must be a finite positive number'
        assert abs(x/TRUE[setting][quantity] - 1) <= REL_TOL, f'{setting}.{quantity} = {x:.4g}'
    t.__name__ = f'test_gap_{setting}_x{quantity.replace(".", "p")}'
    return t


for _s in SETTINGS:
    for _q in QUANTITIES:
        globals()[f'test_gap_{_s}_x{_q.replace(".", "p")}'] = _check(_s, _q)
