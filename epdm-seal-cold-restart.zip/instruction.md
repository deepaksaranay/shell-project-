A seal supplier ran compression-stress-relaxation tests on peroxide-cured EPDM O-rings in steel jigs: each O-ring was compressed by 25 % at 23 C, held for 30 minutes, and then aged in an oven at a fixed temperature for up to a few thousand hours while the jig's load cell logged the sealing force. Most tests used the production O-ring size; two used a thinner O-ring of the same compound. `/app/data/csr_campaign.json` describes the seals, the jig, the test procedure, the test files and the service conditions; the logs are in `/app/data/tests/` (time in hours from compression, sealing force in N, oven air temperature in C).

The design engineer needs to know how much sealing force the production O-ring will retain in service at the four conditions `S1` to `S4` listed in `csr_campaign.json`, expressed as F/F0 in the sense defined there.

Write `/app/output/results.json` as a regular file containing a JSON object, without duplicate keys, with exactly the keys `S1`, `S2`, `S3` and `S4`. Each must map to an object with exactly one finite number, `retained_force_fraction`. Every value must be within 2 % (relative) of the true value.

You have 28800 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
