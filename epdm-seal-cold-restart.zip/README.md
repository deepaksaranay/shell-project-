# epdm-seal-cold-restart

A seal designer needs the sealing force a production EPDM O-ring (5.33 mm cross-section, 25 % compression in a steel housing) keeps after long service, both hot and after the housing cools back to room temperature. The data are seven compression-stress-relaxation (CSR) logs after ISO 3384: five on the production ring at 40–120 °C for 300–3000 h and two on a thinner 1.78 mm ring of the same compound at 100 and 120 °C. The solver must give F/F0 at four service conditions: 40 °C for 5 years and 23 °C for 10 years read at the service temperature, and 70 °C for 1 year and 100 °C for 2000 h read at 23 °C after cooling (the cold-restart force, where a seal that has aged hot is most likely to leak). The logs and the truth come from a seeded model (`authoring/provenance/generate.py`).

## Difficulty

**Who does this work:** seal and elastomer engineers at automotive, process-plant and aerospace suppliers. They qualify a compound from CSR tests and predict the sealing force at the end of the design life, at the operating temperature and at a cold restart, where a seal that has aged hot is most likely to leak.

**Why a curve fit is not enough:** every log is fitted closely by a simple empirical form, a heating-step factor times a power law in time times an exponential decay. That form is good enough for the two readings at the service temperature, but it cannot say what happens on cooling. The heating step it fits is the product of three effects with opposite behaviour on cooling:

- the entropic stiffening (T + 273.15)/296.15, which is reversible (+26 % at 100 °C);
- the extra compression from the rubber expanding about 15 times more than the steel jig, also reversible (+4.5 % at 100 °C);
- the physical relaxation running faster at temperature (WLF shift of the relaxation time), which is not reversible: the stress relaxed at 100 °C does not come back at 23 °C (about −18 % at 100 °C).

At 40 °C the measured step is about 1.00, below the entropic factor alone (1.057), and at 100 °C it is about 1.08. Taking the measured step off as if it were reversible gives cold readings 16 % (S2) and up to 22.6 % (S3) too high. Taking off only the entropic factor gives 2.6 % and up to 4.5 % too high (up to 2.2 times the 2 % bound). The split is in the data: the first hours at temperature show the force rising with the seal temperature and then falling by about 2 % within a few hours as the faster relaxation catches up. This transient is what fixes the rubber expansion and the WLF constants, and only a model fitted to it, with the jig and seal heating lags, carries over to the cold reading. The reference recovers a_r = 1.66e-4 /K (2.1e-4 generated) and WLF 8.7/96 K (9.5/105) from it. The two are correlated, but their product in the cold reading is pinned to better than 1 %.

**Hidden effects in the logs (none flagged):**

- **Load-cell zero drift.** The load cell sits in the jig, inside the oven, and its zero drifts by 0.40 N/K. The 10 minutes logged after each jig was opened read that zero (7 N at 40 °C, 39 N at 120 °C). That is 13 % of the thin-ring force. Ignoring it misses by up to 5.5 % (2.7 times the bound).
- **Re-zero after a power cut.** In the 80 °C log the sampling suddenly returns to 1 min steps at 422.5 h. The logger restarted, and the load cell re-zeroed, so every later reading is 34 N lower, a step that looks like a burst of relaxation. Taking it as real misses by up to 5.5 % (2.7 times).
- **Diffusion-limited oxidation.** At high temperature the oxygen is consumed before it reaches the core of the thick ring, so the production ring ages more slowly than the thin ring (1.6 times slower at 100 °C, 2.1 times at 120 °C). The modulus grows with the cross-section and with temperature at its own activation energy. Ignoring it misses by up to 15.9 %. Dropping the thin-ring tests and fitting one Arrhenius law misses by up to 10.3 % (5.1 times).
- **Chemical and physical relaxation shift differently with temperature.** One Arrhenius shift of the whole curve misses by up to 3.2 %. One WLF shift misses by up to 33 %.

**Trivial answers:** reward needs all four values within 2 %. Checked against `tests/expected.json`, 1.0, the mean (0.574) and the median (0.611) of the four true values pass none. A constant 0.75 passes only S4. No constant passes more than one, so no constant earns the reward. Zero or negative values and values above 1.5 are rejected.

**Instrument noise cannot be regenerated:** the generator draws it from a 128-bit secret entropy (`NOISE_ENTROPY` in `authoring/provenance/generate.py`, which never reaches the solver's container), not from a small seed. A solver cannot reproduce the noise and subtract it.

Data are SYNTHETIC but built like a real campaign: a seal temperature following the oven air through a jig lag and slab conduction across the cross-section, the force K bT eps Phi exp(−D) with the entropic factor, the compression change from the differing expansion of rubber and steel, physical relaxation (1 + xi/tau0)^−n in WLF reduced time, Arrhenius oxidative relaxation weighted by tanh(beta)/beta for diffusion-limited oxidation, multiplicative and additive logger noise, the load-cell zero drift and the re-zero.

## Reference solution

`solution/solve.sh` runs `solution/seal_relaxation.py`:

1. Normalise each log by its own F0, the mean force over 0.4–0.5 h at the end of the 23 °C hold. Find the logging restart in the 80 °C log from the sudden return to 1 min steps, and give the readings after it a free offset. Read the unloaded rows after each test as the load-cell zero.
2. Seal temperature: the jig follows the oven air with a first-order lag. The cross-section follows the jig plates by slab conduction (odd modes, time constants ~ section²).
3. Force model F/K = bT eps Phi(xi) exp(−D) as above, with the zero drift added to the model of the reading. Fit all 13 parameters to the seven logs and their unloaded tails together: rubber expansion, WLF C1 and C2, tau0, n, Ea, k100, the two lags, the DLO modulus and its activation, the offset and the drift.
4. Targets: apply the service temperature at 0.5 h with the same thermal response. For a cold reading, return the air to 23 °C at the end of the service time and read the force 24 h later. The entropic and expansion factors go back to their 23 °C values, while the reduced time accumulated hot and the oxidation stay.

It recovers the zero drift (0.399 N/K, true 0.40), the offset (−34.0 N, true −34 N), the activation energy (96.0 kJ/mol, true 96), the DLO modulus (1.60, true 1.6) and its activation (60.8 kJ/mol, true 61). The fit rms is 1.10 times the logger noise. It runs in about 80 s on two CPUs.

## Verification

`tests/seal_checks.py` checks that `results.json` is a regular, duplicate-free file holding exactly `S1`–`S4`, each holding exactly `retained_force_fraction` as a finite number. Malformed output fails every test as a test failure. Four separately named tests then require each value to be positive, at most 1.5 and within 2 % (relative) of the model truth. Reward is 1 only if all five pass.

**Calibration:** `authoring/evidence/score_submissions.py` regenerates the campaign and the truth for seeds 1–5 (new logger noise) beside the shipped seed 0. Every submitter writes `results.json` in its own folder. The unchanged check file runs through pytest with the CTRF plugin, as `tests/test.sh` does, and each submission keeps its `reward.txt` and `ctrf.json`. The summary is in `authoring/evidence/grading_results.txt`.

**Reward 1 on all six data sets (5/5 tests):**

| Submitter | Largest error |
|---|---|
| Reference | 0.16–1.08 % (0.08–0.54× the bound) |
| `authoring/evidence/independent_reduction.py`, an independent reduction with no shared code: F0 as the median of the end of the hold, the re-zero found from the jump of the force, two first-order lags in series for the jig and the seal, diffusion-limited oxidation from a finite-difference solution of oxygen diffusion and consumption, and a dogbox least-squares search on log-parameters | 0.31–1.01 % (0.16–0.50× the bound) |
| Seal temperature as a single first-order lag behind the jig, otherwise as the reference (`alternatives.py`) | 0.83–1.83 % (0.41–0.92× the bound) |

The 2 % bound is set by these reductions. The cold readings depend on how well the rubber expansion and the WLF shift are told apart from the first hours at temperature, and a coarser seal-temperature model reaches 1.8 %.

**Reward 0 on all six data sets (same file, `authoring/evidence/alternatives.py`):**

| Route | Tests passed | Largest error |
|---|---|---|
| Cold reading: the whole measured heating step taken as reversible | 3/5 | 22.2–22.6 % (11.1–11.3×) |
| Cold reading: only the entropic factor taken as reversible | 3/5 | 4.0–4.5 % (2.0–2.2×) |
| Thermal expansion of the rubber ignored | 3/5 | 4.0–4.5 % (2.0–2.3×) |
| Entropic factor ignored | 3/5 | 7.4–7.9 % (3.7–4.0×) |
| Load-cell zero drift ignored | 3/5 | 4.6–5.5 % (2.3–2.7×) |
| Re-zero after the power cut taken as real relaxation | 2/5 | 4.9–5.5 % (2.4–2.7×) |
| Diffusion-limited oxidation ignored | 2/5 | 15.1–15.9 % (7.6–7.9×) |
| Thin-ring tests dropped, one Arrhenius law | 1–2/5 | 10.0–10.3 % (5.0–5.1×) |
| One Arrhenius shift for both relaxations | 3/5 | 2.8–3.2 % (1.4–1.6×) |
| One WLF shift for both relaxations | 1/5 | 32.7–32.9 % (16.4–16.5×) |
| Seal at the oven air temperature (no heating lag) | 3/5 | 3.9–4.3 % (2.0–2.2×) |
| Chemical relaxation ignored | 1/5 | 94.4–94.8 % (47.2–47.4×) |

The generated parameters and the targets are in `authoring/evidence/generator_truth.json`.
