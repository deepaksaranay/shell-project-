"""Predicted retained sealing force F/F0 at the four service conditions versus the seal model that generated the records."""
import json
import math
import os
from pathlib import Path

import pytest

OUTPUT = Path(os.environ.get('RESULTS_PATH', '/app/output/results.json'))
TRUTH = json.loads(Path(__file__).with_name('expected.json').read_text())
TARGETS = ('S1', 'S2', 'S3', 'S4')
FIELD = 'retained_force_fraction'
REL_TOL = 0.02


def _no_repeats(items):
    out = {}
    for key, value in items:
        if key in out:
            raise ValueError(f'repeated key {key}')
        out[key] = value
    return out


def _load():
    """Returns (table, None) for a valid file, (None, reason) otherwise; the tests turn a reason into a failure."""
    if OUTPUT.is_symlink() or not OUTPUT.is_file():
        return None, 'results.json is missing or is a symbolic link'
    try:
        data = json.loads(OUTPUT.read_text(), object_pairs_hook=_no_repeats)
    except ValueError as exc:
        return None, f'results.json is not valid: {exc}'
    if not isinstance(data, dict) or sorted(data) != sorted(TARGETS):
        return None, f'results.json must be an object with exactly the keys {list(TARGETS)}'
    for name in TARGETS:
        entry = data[name]
        if not isinstance(entry, dict) or list(entry) != [FIELD]:
            return None, f'{name} must be an object with exactly the key {FIELD}'
        v = entry[FIELD]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            return None, f'{name}.{FIELD} must be a finite number'
    return data, None


@pytest.fixture(scope='module')
def loaded():
    return _load()


def test_output_shape(loaded):
    table, why = loaded
    assert why is None, why


def _target_test(name):
    def run(loaded):
        table, why = loaded
        assert why is None, why
        x = table[name][FIELD]
        assert 0 < x <= 1.5, f'{name}: retained force fraction must be positive and plausible'
        assert abs(x/TRUTH[name][FIELD] - 1) <= REL_TOL, f'{name}: F/F0 = {x:.4f}'
    run.__name__ = f'test_retained_force_{name}'
    return run


for _n in TARGETS:
    globals()[f'test_retained_force_{_n}'] = _target_test(_n)
