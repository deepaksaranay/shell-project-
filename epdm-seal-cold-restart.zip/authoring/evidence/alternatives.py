"""Other reductions of the CSR campaign, each with one step changed from the reference (solution/seal_relaxation.py). Each writes
a complete submission <out_dir>/<route>/results.json for score_submissions.py.

    python alternatives.py <data_dir> <out_dir> <route>
"""
import sys
ROUTE = sys.argv[3]
import json, os
import numpy as np
from scipy.optimize import least_squares

DATA = sys.argv[1]; OUT = os.path.join(sys.argv[2], ROUTE)
cfg = json.load(open(os.path.join(DATA, 'csr_campaign.json')))
A_J = cfg['jig']['steel_linear_expansion_per_K']; EPS0 = 0.25; R = 8.314
NM = 2*np.arange(25) + 1; WM = 8/(NM**2*np.pi**2); WM = WM/WM.sum()

tests = []
for e in cfg['tests']:
    d = np.loadtxt(os.path.join(DATA, e['file']), delimiter=',', skiprows=1)
    t, F = d[:, 0], d[:, 1]
    F0 = np.mean(F[(t > 0.4) & (t <= 0.5 + 1e-9)])
    dt = np.diff(t)                                                 # a restart of the logger's schedule mid-test: the sampling
    rst = [i for i in range(1, len(dt)) if 3.0 < t[i] < 0.5 + e['duration_h'] - 1e-6 and dt[i] < 0.1*dt[i-1]]   # suddenly drops back to 1 min steps
    after = np.zeros(len(t), bool)
    if rst and ROUTE != 'load_cell_rezero_ignored': after[rst[0] + 1:] = True
    tail = t > 0.5 + e['duration_h'] + 1e-6                          # jig opened in the oven: the load cell reads its zero
    tests.append(dict(T=e['oven_temperature_C'], d=e['oring_cross_section_mm'], t=t, y=F/F0, after=after, F0=F0, tail=tail))
if ROUTE == 'thin_tests_dropped_no_dlo':
    tests = [x for x in tests if x['d'] == 5.33]
print('# logging gaps (re-zeroed load cell):', [(x['T'], round(x['t'][x['after']][0], 2)) for x in tests if x['after'].any()])


def history(T_set, t_out, p, t_ins=0.5, d=5.33, t_cool=None):
    ar, C1, C2, tau0, n, Ea, k100, tj, ts, b0, dE = p
    ts = ts*(d/5.33)**2                                            # conduction time ~ section squared
    tf = np.unique(np.r_[np.linspace(0, t_ins + 3, 1500), np.geomspace(t_ins + 3, max(t_out[-1], t_ins + 4), 1500)])
    if t_cool is not None: tf = np.unique(np.r_[tf[tf < t_cool], np.linspace(t_cool, t_out[-1], 1500)])   # back in 23 C air
    Tair = np.where(tf < t_ins, 23.0, T_set)
    if t_cool is not None: Tair = np.where(tf >= t_cool, 23.0, Tair)
    Tj = np.empty_like(tf); Tj[0] = 23.0; md = np.full(len(NM), 23.0); Ts = np.empty_like(tf); Ts[0] = 23.0
    for i in range(1, len(tf)):
        h = tf[i] - tf[i-1]
        Tj[i] = Tair[i] + (Tj[i-1] - Tair[i])*np.exp(-h/tj)
        dv = 0.5*(Tj[i] + Tj[i-1]); md = dv + (md - dv)*np.exp(-h*NM**2/ts); Ts[i] = WM@md
        if ROUTE == 'single_lag_seal_temperature': Ts[i] = dv + (Ts[i-1] - dv)*np.exp(-h/(tj + ts))
        if ROUTE == 'seal_at_oven_temperature': Tj[i] = Ts[i] = Tair[i]
    Tm = 0.5*(Ts[1:] + Ts[:-1]); h = np.diff(tf)
    arr = np.exp(-Ea/R*(1/(Tm + 273.15) - 1/296.15))
    wlf = 10**(C1*(Tm - 23)/(C2 + Tm - 23))
    xi = np.r_[0, np.cumsum(h*3600*(arr if ROUTE == 'single_arrhenius_shift' else wlf))]
    kk = k100*np.exp(-Ea/R*(1/(Tm + 273.15) - 1/373.15))
    if ROUTE == 'single_wlf_shift': kk = k100*np.exp(-Ea/R*(1/373.15 - 1/296.15))*wlf   # chemical rate tied to the WLF shift
    beta = b0*(d/5.33)*np.exp(-dE/(2*R)*(1/(Tm + 273.15) - 1/373.15))
    if ROUTE not in ('dlo_ignored', 'thin_tests_dropped_no_dlo'): kk = kk*np.tanh(beta)/beta                # diffusion-limited oxidation
    D = np.r_[0, np.cumsum(h*kk)]
    if ROUTE == 'chemical_relaxation_ignored': D = 0*D
    eps = 1 - (1 - EPS0)*(1 + A_J*(Tj - 23))/(1 + (0.0 if ROUTE == 'thermal_expansion_ignored' else ar)*(Ts - 23))
    bT = 1.0 if ROUTE == 'entropic_factor_ignored' else (Ts + 273.15)/296.15
    F = bT*eps*(1 + xi/tau0)**(-n)*np.exp(-D)
    return np.interp(t_out, tf, F), np.interp(t_out, tf, Tj)


def residuals(q):
    p, off, ztc = q[:11], q[11], (0.0 if ROUTE == 'load_cell_zero_drift_ignored' else q[12])
    out = []
    for x in tests:
        ld = ~x['tail']; tl = x['t'][ld]
        m, Tj = history(x['T'], tl, p, d=x['d']); m = m/np.interp(0.5, tl, m) + ztc*(Tj - 23)/x['F0']   # load-cell zero drift
        y = x['y'][ld] - np.where(x['after'][ld], off, 0.0)
        out.append((m - y)/0.0015)
        if x['tail'].any() and ROUTE != 'load_cell_zero_drift_ignored':  # unloaded readings: zero drift (+ the re-zero offset)
            yt = x['y'][x['tail']] - np.where(x['after'][x['tail']], off, 0.0)
            out.append((ztc*(x['T'] - 23)/x['F0'] - yt)*x['F0']/0.4)
    return np.concatenate(out)


x0 = [2e-4, 9.0, 110.0, 2.0, 0.02, 9e4, 6e-4, 0.4, 0.15, 1.0, 6e4, 0.0, 0.0]
lo = [0, 2, 30, 1e-3, 1e-3, 3e4, 1e-6, 0.02, 0.01, 1e-3, 0, -0.2, -5]; hi = [1e-3, 30, 400, 1e4, 0.2, 2e5, 1e-1, 3, 3, 20, 2e5, 0.2, 5]
xs = [2e-5, 0.5, 5, 0.5, 0.002, 2e3, 5e-5, 0.05, 0.02, 0.1, 5e3, 0.005, 0.05]
best = None
for st in (x0, [1.5e-4, 7, 90, 10, 0.03, 8e4, 1e-3, 0.3, 0.3, 2.0, 4e4, 0, 0], [2.5e-4, 12, 140, 0.5, 0.015, 1.1e5, 3e-4, 0.6, 0.08, 0.5, 8e4, 0, 0]):
    r = least_squares(residuals, st, bounds=(lo, hi), x_scale=xs)
    if best is None or r.cost < best.cost: best = r
q = best.x
print('# a_r %.3g /K, WLF C1 %.2f C2 %.1f, tau0 %.3g s, n %.4f, Ea %.1f kJ/mol, k100 %.3g /h, lags %.3f / %.3f h, DLO beta %.3f dE %.1f kJ/mol, '
      'offset %.4f, load-cell zero drift %.3f N/K; rms %.3f' % (q[0], q[1], q[2], q[3], q[4], q[5]/1e3, q[6], q[7], q[8], q[9], q[10]/1e3, q[11], q[12], np.sqrt(np.mean(best.fun**2))))
out = {}
for c in cfg['targets']['conditions']:
    T, th, cold = c['service_temperature_C'], c['service_time_h'], c['read_at'].startswith('23')
    if cold and ROUTE in ('cold_read_entropic_only', 'cold_read_divides_heating_step'):
        m, _ = history(T, np.array([0.5, 0.5 + th]), q[:11]); f = m[1]/m[0]   # hot value, then a reversible factor taken off
        if ROUTE == 'cold_read_entropic_only': f /= (T + 273.15)/296.15
        else:                                                          # whole heating step (measured lumped factor) taken as reversible
            pc = q[:11].copy(); pc[6] = 0.0; tl = np.array([0.5, 0.5 + th])
            mh, _ = history(T, tl, pc); mc, _ = history(23.0, tl, pc); f /= (mh[1]/mh[0])/(mc[1]/mc[0])
    else:
        tt = np.array([0.5, 0.5 + th + (24.0 if cold else 0.0)])
        m, _ = history(T, tt, q[:11], t_cool=0.5 + th if cold else None); f = m[1]/m[0]
    out[c['name']] = {'retained_force_fraction': float(f)}
print('#', {k: round(v['retained_force_fraction'], 4) for k, v in out.items()})
os.makedirs(OUT, exist_ok=True)
json.dump(out, open(os.path.join(OUT, 'results.json'), 'w'), indent=2)
