"""Calibrates the bounds with the real checks.

For the shipped data (seed 0) and regenerated campaigns (CSR_SEED = 1..), every submitter writes results.json in its own
folder: solution/solve.sh, independent_reduction.py and each route of alternatives.py. tests/seal_checks.py, unchanged, is
placed next to that campaign's expected.json and run with pytest and the CTRF plugin as tests/test.sh runs it; reward.txt and
ctrf.json stay in the folder. One line per submission: reward, tests passed, largest relative error.

    python score_submissions.py <work_dir> <seed> [<seed> ...]
"""
import json, os, shutil, subprocess, sys
top = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
ev = os.path.join(top, 'authoring', 'evidence'); py = sys.executable; work = os.path.abspath(sys.argv[1])
ROUTES = ['thin_tests_dropped_no_dlo', 'dlo_ignored', 'single_arrhenius_shift', 'single_wlf_shift', 'chemical_relaxation_ignored',
          'thermal_expansion_ignored', 'entropic_factor_ignored', 'load_cell_rezero_ignored', 'single_lag_seal_temperature', 'seal_at_oven_temperature',
          'load_cell_zero_drift_ignored', 'cold_read_entropic_only', 'cold_read_divides_heating_step']
for seed in sys.argv[2:]:
    w = os.path.join(work, f'seed{seed}'); t = os.path.join(w, 'tests'); os.makedirs(t, exist_ok=True)
    if seed == '0':
        data = os.path.join(top, 'environment', 'data'); shutil.copy(os.path.join(top, 'tests', 'expected.json'), t)
    else:
        data = os.path.join(w, 'data')
        subprocess.run([py, os.path.join(top, 'authoring', 'provenance', 'generate.py'), data, t], check=True, env={**os.environ, 'CSR_SEED': seed})
    shutil.copy(os.path.join(top, 'tests', 'seal_checks.py'), t)
    subs = {'reference': os.path.join(w, 'reference'), 'independent': os.path.join(w, 'independent')}
    for f in subs.values(): os.makedirs(f, exist_ok=True)
    subprocess.run(['bash', os.path.join(top, 'solution', 'solve.sh')], check=True, stdout=subprocess.DEVNULL,
                   env={**os.environ, 'DATA_DIR': data, 'OUT_DIR': subs['reference']})
    subprocess.run([py, os.path.join(ev, 'independent_reduction.py'), data, os.path.join(subs['independent'], 'results.json')],
                   check=True, stdout=subprocess.DEVNULL)
    for r in ROUTES:
        subprocess.run([py, os.path.join(ev, 'alternatives.py'), data, os.path.join(w, 'alternatives'), r], check=True, stdout=subprocess.DEVNULL)
        subs[r] = os.path.join(w, 'alternatives', r)
    truth = json.load(open(os.path.join(t, 'expected.json')))
    for name, f in subs.items():
        r = subprocess.run([py, '-m', 'pytest', os.path.join(t, 'seal_checks.py'), '-q', '-p', 'no:cacheprovider', '--rootdir', t,
                            '-c', os.devnull, '-p', 'ctrf', '--ctrf', os.path.join(f, 'ctrf.json')], capture_output=True, text=True,
                           env={**os.environ, 'RESULTS_PATH': os.path.join(f, 'results.json'), 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'})
        reward = int(r.returncode == 0); open(os.path.join(f, 'reward.txt'), 'w').write(f'{reward}\n')
        sm = json.load(open(os.path.join(f, 'ctrf.json')))['results']['summary']
        got = json.load(open(os.path.join(f, 'results.json')))
        e = max(abs(got[k]['retained_force_fraction']/truth[k]['retained_force_fraction'] - 1) for k in truth)
        print(f'[seed {seed}] {name:32s} reward {reward}   tests {sm["passed"]}/{sm["tests"]}   largest error {100*e:6.2f} % ({e/0.02:5.2f} x 2 %)', flush=True)
