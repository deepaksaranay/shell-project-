#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DATA_DIR="${DATA_DIR:-/app/data}" OUT_DIR="${OUT_DIR:-/app/output}"
mkdir -p "$OUT_DIR"
python3 "$here/seal_relaxation.py"
