import sys,json,numpy as np
T,W=sys.argv[1],sys.argv[2]
sys.path[:0]=[T+'/tests',T+'/authoring/provenance']
import cases,truth
out={}
for c in sys.argv[3:]:
    cfg={**cases.VISIBLE,**cases.HIDDEN}[c]; L=np.load(f'{W}/{c}/true_load_kN.npy')
    out[c]=truth.damage(L*cfg['MPa_per_kN'],cfg['Kt'],cases.MATERIALS[cfg['material']])
json.dump(out,open(f'{W}/truth.json','w'),indent=1); print(out)
