import json,sys
W=sys.argv[1]
T=json.load(open(f'{W}/truth.json'))
routes=sys.argv[2:]
print('route'.ljust(24),' '.join(c.rjust(7) for c in T))
for r in routes:
    row=[]
    for c in T:
        try: g=json.load(open(f'{W}/{c}/alt_{r}.json'))['damage_per_block']; row.append(f'{100*(g/T[c]-1):+7.1f}')
        except Exception as e: row.append('    ERR')
    print(r.ljust(24),' '.join(row))
