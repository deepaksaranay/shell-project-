"""Write case directories: python mkcase.py <task_dir> <out_root> <name> [...]"""
import json, os, sys, numpy as np
sys.path[:0] = [sys.argv[1] + '/tests']
import cases
for name in sys.argv[3:]:
    cfg = {**cases.VISIBLE, **cases.HIDDEN}[name]
    d = os.path.join(sys.argv[2], name); os.makedirs(d, exist_ok=True)
    L, c = cases.record(cfg)
    np.save(os.path.join(d, 'load_counts.npy'), c)
    json.dump(cases.case_json(cfg), open(os.path.join(d, 'case.json'), 'w'), indent=2)
    np.save(os.path.join(d, 'true_load_kN.npy'), L)
