"""Builds the visible cases and the expected damages (authoring only).

    python generate.py            (run from anywhere; paths are relative to the task directory)

Visible cases -> environment/data/cases/<V>/{case.json, load_counts.npy} and environment/data/visible_damage.json.
Hidden cases are not written: tests/cases.py regenerates them at test time from the same code; only their expected
damage is stored, in tests/expected_hidden.json. The damage is the exact one (truth.py: root finding for every branch and
every cycle) of the true load, i.e. without the load-cell zero offset, the telemetry corruption and the ADC rounding.
"""
import json, os, sys
from pathlib import Path
import numpy as np

TOP = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(TOP/'tests'), str(Path(__file__).parent)]
import cases, truth


def main():
    vis = {}
    for name, cfg in cases.VISIBLE.items():
        d = TOP/'environment'/'data'/'cases'/name
        d.mkdir(parents=True, exist_ok=True)
        L, counts = cases.record(cfg)
        np.save(d/'load_counts.npy', counts)
        (d/'case.json').write_text(json.dumps(cases.case_json(cfg), indent=2) + '\n')
        vis[name] = truth.damage(L*cfg['MPa_per_kN'], cfg['Kt'], cases.MATERIALS[cfg['material']])
        print(name, len(counts), vis[name], flush=True)
    (TOP/'environment'/'data'/'visible_damage.json').write_text(json.dumps({'damage_per_block': vis}, indent=2) + '\n')
    hid, info = {}, {}
    for name, cfg in cases.HIDDEN.items():
        L, counts = cases.record(cfg)
        hid[name] = truth.damage(L*cfg['MPa_per_kN'], cfg['Kt'], cases.MATERIALS[cfg['material']])
        info[name] = {'samples': int(len(counts)), 'material': cfg['material'], 'Kt': cfg['Kt'],
                      'largest_elastic_notch_stress_MPa': float(cfg['Kt']*np.abs(L).max()*cfg['MPa_per_kN']),
                      'zero_offset_kN': cfg['zero_offset_kN'], 'spikes': cfg.get('spikes'),
                      'overloads_kN': [o[1] for o in cfg.get('overloads', [])], 'damage_per_block': hid[name]}
        print(name, len(counts), hid[name], flush=True)
    (TOP/'tests'/'expected_hidden.json').write_text(json.dumps({'damage_per_block': hid}, indent=2) + '\n')
    vinfo = {n: {'samples': int(round((c['standstill_s'][0] + sum(s[0] for s in c['segments']) + c['standstill_s'][1] + 4)*c.get('fs', 1000.0))),
                 'material': c['material'], 'zero_offset_kN': c['zero_offset_kN'], 'spikes': c.get('spikes'),
                 'overloads_kN': [o[1] for o in c.get('overloads', [])], 'damage_per_block': vis[n]} for n, c in cases.VISIBLE.items()}
    (TOP/'authoring'/'evidence'/'generator_truth.json').write_text(json.dumps({'visible': vinfo, 'hidden': info}, indent=2) + '\n')


if __name__ == '__main__':
    main()
