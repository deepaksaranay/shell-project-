import sys,json,time,subprocess,os
W=sys.argv[1]; prog=sys.argv[2]; tag=sys.argv[3]; lim=float(sys.argv[4])
T=json.load(open(f'{W}/truth.json'))
for c in sys.argv[5:]:
    t=time.time()
    try:
        r=subprocess.run([sys.executable,prog,f'{W}/{c}',f'{W}/{c}/{tag}.json'],capture_output=True,text=True,timeout=lim,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'})
        dt=time.time()-t; g=json.load(open(f'{W}/{c}/{tag}.json'))['damage_per_block'] if r.returncode==0 else float('nan')
        print(f'{tag} {c} err {100*(g/T[c]-1):+.4f} % time {dt:.2f} s {r.stderr.strip()[-120:]}',flush=True)
    except subprocess.TimeoutExpired:
        print(f'{tag} {c} TIMEOUT after {lim} s',flush=True)
