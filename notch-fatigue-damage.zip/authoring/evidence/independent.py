"""Independent program (no code shared with solution/predict.py or the generator), same interface:

    python independent.py <case_dir> <output_json>

Different choices from the reference:
* corrupted samples found from the pattern of second differences (large at the sample, opposite sign and about half
  the size at both neighbours; a real peak has neighbours of the same sign), with a threshold of 2 % of the load range;
* the load-cell zero from the mode of the readings (the standstill readings repeat one value), not from the ends;
* the repeated block is handled by analysing two consecutive blocks from rest (first loading from zero on the cyclic
  curve) and counting only the cycles that close during the second block, instead of starting at the largest |S|;
* Neuber's rule and the SWT life are solved by vectorised Newton iterations on all branches and cycles at once (the
  memory stack is run first on the nominal values only, recording for every turning point the point its branch started
  from); no interpolation tables.
"""
import json, sys
import numpy as np


def clean(x):
    """A corrupted sample has a large second difference whose neighbours have the opposite sign and about half its size
    (the error enters them once, it enters the sample's own twice); a real peak has neighbours of the same sign."""
    d2 = np.zeros(len(x))
    d2[1:-1] = x[:-2] - 2*x[1:-1] + x[2:]
    span = np.subtract(*np.percentile(x, [99.9, 0.1]))
    thr = max(0.02*span, 1e-9)
    l, r = np.roll(d2, 1), np.roll(d2, -1)
    bad = (np.abs(d2) > thr) & (np.sign(l) == -np.sign(d2)) & (np.sign(r) == -np.sign(d2)) \
        & (np.abs(l) > 0.3*np.abs(d2)) & (np.abs(r) > 0.3*np.abs(d2))
    bad[[0, -1]] = False
    k = np.where(bad)[0]
    y = x.copy()
    y[k] = 0.5*(x[k - 1] + x[k + 1])
    return y, len(k)


def zero(x, q):
    v, cnt = np.unique(np.rint(x/q).astype(np.int64), return_counts=True)
    return float(v[np.argmax(cnt)]*q)


def turning(s):
    s = s[np.r_[True, s[1:] != s[:-1]]]
    d = np.diff(s)
    return s[np.r_[True, d[:-1]*d[1:] < 0, True]]


def newton_sig(target, E, K, n, doubled):
    """Solve sig*eps(sig) = target (> 0) for sig, vectorised Newton on log(sig)."""
    a = 2.0 if doubled else 1.0
    kk = 2*K if doubled else K
    u = np.log(np.sqrt(target*E))                    # elastic start
    for _ in range(60):
        s = np.exp(u)
        p = a*(s/kk)**(1/n)
        f = np.log(s*(s/E + p)) - np.log(target)
        df = 1 + (s/E + p/n)/(s/E + p)
        u_new = u - f/df
        if np.max(np.abs(u_new - u)) < 1e-13:
            u = u_new; break
        u = u_new
    s = np.exp(u)
    return s, s/E + a*(s/kk)**(1/n)


def swt_life(P, E, sf, b, ef, c):
    """2N from sig_max*eps_a = P, vectorised Newton on L = log(2N)."""
    A, B = sf*sf/E, sf*ef
    L = np.full(P.shape, 10.0)
    for _ in range(200):
        g1, g2 = A*np.exp(2*b*L), B*np.exp((b + c)*L)
        f = np.log(g1 + g2) - np.log(P)
        df = (2*b*g1 + (b + c)*g2)/(g1 + g2)
        Ln = np.clip(L - f/df, -10, 200)
        if np.max(np.abs(Ln - L)) < 1e-12:
            L = Ln; break
        L = Ln
    return np.exp(L)


def main(d, out):
    cfg = json.load(open(f'{d}/case.json'))
    ch = cfg['load_channel']; q = ch['kN_per_count']
    x = np.load(f"{d}/{ch['file']}").astype(float)*q
    x, nsp = clean(x)
    x = x - zero(x, q)
    m = cfg['cyclic_properties']; Kt = cfg['stress_concentration_factor_Kt']
    E, K, n = m['E'], m['K'], m['n']
    S = Kt*cfg['nominal_stress_MPa_per_kN']*x
    nb = len(S)
    T = turning(np.r_[0.0, S, S])                     # two blocks from rest
    # block membership of each turning point: find where the second copy starts
    split = len(turning(np.r_[0.0, S]))
    # memory stack on nominal values: record branch origins and closed cycles (indices into T)
    Tl = T.tolist()
    origin = np.full(len(T), -1, np.int64)          # -1: on the cyclic curve
    stack = [0]; xmax = 0.0
    cyc = []
    for i in range(1, len(Tl)):
        p = Tl[i]
        if abs(p) >= xmax:
            while len(stack) >= 3:
                cyc.append((stack[-2], stack[-1], i)); del stack[-2:]
            stack = [0, i]; xmax = abs(p)
            continue
        while len(stack) >= 3 and abs(p - Tl[stack[-1]]) >= abs(Tl[stack[-1]] - Tl[stack[-2]]):
            cyc.append((stack[-2], stack[-1], i)); del stack[-2:]
        origin[i] = stack[-1]
        stack.append(i)
    # stresses: cyclic-curve points, then branches (origin always earlier)
    sig = np.zeros(len(T))
    oc = origin < 0
    oc[0] = False
    tc = np.abs(T[oc])
    sig[oc] = np.sign(T[oc])*newton_sig(tc*tc/E, E, K, n, False)[0]
    br = np.where(origin >= 0)[0]
    dx = np.abs(T[br] - T[origin[br]])
    dsg = np.zeros(len(br))
    nz = dx > 0
    dsg[nz] = newton_sig(dx[nz]**2/E, E, K, n, True)[0]
    sgn = np.sign(T[br] - T[origin[br]])
    sl, ol = sig.tolist(), origin.tolist()
    for k, i in enumerate(br.tolist()):
        sl[i] = sl[ol[i]] + sgn[k]*dsg[k]
    sig = np.array(sl)
    C = np.array(cyc, np.int64)
    C = C[C[:, 2] >= split]                           # cycles that close during the second block
    a, b_ = C[:, 0], C[:, 1]
    rng = np.abs(T[b_] - T[a])
    smax = np.maximum(sig[a], sig[b_])
    keep = (smax > 0) & (rng > 0)
    ds, de = newton_sig(rng[keep]**2/E, E, K, n, True)
    twoN = swt_life(smax[keep]*de/2, E, m['sf'], m['b'], m['ef'], m['c'])
    D = float(np.sum(2.0/twoN))
    json.dump({'damage_per_block': D}, open(out, 'w'))
    print(f'# spikes {nsp}, damage {D:.6e}', file=sys.stderr)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
