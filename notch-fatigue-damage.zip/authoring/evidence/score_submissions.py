"""Grades complete submissions with the unchanged tests (tests/test_fatigue.py through pytest and the CTRF plugin, as
tests/test.sh runs it, with the same 8 s limit per run) and prints one line per submission.

    python score_submissions.py <work_dir> [<submitter> ...]

Submitters: reference (solution/predict.py), independent, naive_correct, and every route of alternatives.py (run through
a one-line wrapper with the same command line). Each keeps reward.txt and ctrf.json in <work_dir>/<submitter>/.
FATIGUE_RUN_USER is left empty here (the authoring machine runs the program as the current user).
"""
import json, os, subprocess, sys
from pathlib import Path
TOP = Path(__file__).resolve().parents[2]; EV = TOP/'authoring'/'evidence'
ROUTES = ['spikes_kept', 'spike_threshold_20kN', 'zero_offset_kept', 'memory_ignored', 'residue_half_cycles', 'elastic_notch']
work = Path(sys.argv[1]).resolve()
subs = sys.argv[2:] or ['reference', 'independent', 'naive_correct'] + ROUTES
for name in subs:
    d = work/name; d.mkdir(parents=True, exist_ok=True)
    if name == 'reference':
        prog = TOP/'solution'/'predict.py'
    elif name in ('independent', 'naive_correct'):
        prog = EV/f'{name}.py'
    else:
        prog = d/'predict.py'
        prog.write_text(f"import sys\nsys.path.insert(0, {str(EV)!r})\nimport alternatives\nalternatives.main({name!r}, sys.argv[1], sys.argv[2])\n")
    env = {**os.environ, 'FATIGUE_PROGRAM': str(prog), 'FATIGUE_RUN_USER': '', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1'}
    r = subprocess.run([sys.executable, '-m', 'pytest', str(TOP/'tests'/'test_fatigue.py'), '-q', '-p', 'no:cacheprovider',
                        '--rootdir', str(TOP/'tests'), '-c', os.devnull, '-p', 'ctrf', '--ctrf', str(d/'ctrf.json')],
                       capture_output=True, text=True, env=env)
    reward = int(r.returncode == 0); (d/'reward.txt').write_text(f'{reward}\n')
    res = json.load(open(d/'ctrf.json'))['results']
    sm = res['summary']
    why = sorted({(t.get('message') or '').split(':', 1)[-1].strip()[:60] for t in res['tests'] if t['status'] != 'passed'})
    print(f'{name:24s} reward {reward}   tests {sm["passed"]}/{sm["tests"]}   ' + ('; '.join(why) if why else 'all within the requirement'), flush=True)
