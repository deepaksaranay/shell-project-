"""A correct but unoptimised program (same physics and the same answers as solution/predict.py, within 0.01 %):
plain Python loops over the samples to clean the record and find the turning points, and a root finder (scipy brentq)
for every branch of Neuber's rule and for every cycle's Smith-Watson-Topper life.

    python naive_correct.py <case_dir> <output_json>

On the hidden records (about 10 million samples, about one million turning points) it needs far longer than the per-run
limit; on the visible records it finishes in a few seconds and gives the visible damages.
"""
import json, sys
import numpy as np
from scipy.optimize import brentq


def main(d, out):
    cfg = json.load(open(f'{d}/case.json'))
    ch = cfg['load_channel']
    x = (np.load(f"{d}/{ch['file']}").astype(float)*ch['kN_per_count']).tolist()
    fs = ch['sample_rate_Hz']
    m = cfg['cyclic_properties']; Kt = cfg['stress_concentration_factor_Kt']
    E, K, n, sf, b, ef, c = (m[k] for k in ('E', 'K', 'n', 'sf', 'b', 'ef', 'c'))
    # despike: half second difference against 12 robust standard deviations (at least 1 % of the range)
    N = len(x)
    r = [0.0]*N
    for i in range(1, N - 1):
        r[i] = x[i] - 0.5*(x[i - 1] + x[i + 1])
    med = float(np.median(r[1:-1])); s = 1.4826*float(np.median(np.abs(np.array(r[1:-1]) - med)))
    lo, hi = np.percentile(x, [0.1, 99.9])
    thr = max(12*s, 0.01*(hi - lo))
    y = list(x)
    for i in range(1, N - 1):
        if abs(r[i]) > thr and abs(r[i]) >= abs(r[i - 1]) and abs(r[i]) >= abs(r[i + 1]):
            y[i] = 0.5*(x[i - 1] + x[i + 1])
    k = int(2*fs)
    z = float(np.median(y[:k] + y[-k:]))
    S = [(v - z)*cfg['nominal_stress_MPa_per_kN'] for v in y]
    # turning points of the repeated block, from the largest |S|
    i0 = max(range(N), key=lambda i: abs(S[i]))
    seq = S[i0:] + S[:i0 + 1]
    pts = [seq[0]]
    for v in seq[1:]:
        if v != pts[-1]:
            pts.append(v)
    R = [pts[0]]
    for j in range(1, len(pts) - 1):
        if (pts[j] - pts[j - 1])*(pts[j + 1] - pts[j]) < 0:
            R.append(pts[j])
    R.append(pts[-1])

    def first(xx):
        a = abs(xx)
        if a == 0:
            return 0.0
        f = lambda q: q*(q/E + (q/K)**(1/n)) - a*a/E
        return np.copysign(brentq(f, 0.0, a) if f(a) > 0 else a, xx)

    def branch(dx):
        if dx == 0:
            return 0.0
        f = lambda q: q*(q/E + 2*(q/(2*K))**(1/n)) - dx*dx/E
        return brentq(f, 0.0, dx) if f(dx) > 0 else dx

    def life(smax, ea):
        if smax <= 0:
            return float('inf')
        g = lambda L: np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L)) - np.log(smax*ea)
        if g(120.0) > 0:
            return float('inf')
        return 0.5*np.exp(brentq(g, -5.0, 120.0)) if g(-5.0) > 0 else 0.5

    stx, sts = [Kt*R[0]], [first(Kt*R[0])]
    D = 0.0
    for P in R[1:]:
        P = Kt*P
        while len(stx) >= 2 and abs(P - stx[-1]) >= abs(stx[-1] - stx[-2]):
            ds = branch(abs(stx[-1] - stx[-2]))
            D += 1.0/life(max(sts[-1], sts[-2]), 0.5*(ds/E + 2*(ds/(2*K))**(1/n)))
            del stx[-2:], sts[-2:]
        if not stx:
            stx.append(P); sts.append(first(P)); continue
        o = stx[-1]
        stx.append(P); sts.append(sts[-1] + np.sign(P - o)*branch(abs(P - o)))
    json.dump({'damage_per_block': float(D)}, open(out, 'w'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
