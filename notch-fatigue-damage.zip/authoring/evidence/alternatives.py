"""Shortcut programs, each a complete submission with the same interface as solution/predict.py:

    python alternatives.py <route> <case_dir> <output_json>

Routes (one change each from the reference):
  spikes_kept              telemetry corruption not removed
  spike_threshold_20kN     corrupted samples found with a fixed 20 kN threshold (enough for every visible record)
  zero_offset_kept         load-cell zero at standstill not removed
  memory_ignored           rainflow on the nominal stress; every cycle's loop placed on its own: stress range from the
                           doubled curve, sig_max from the cyclic curve at the cycle's largest nominal stress
  residue_half_cycles      block analysed once from standstill (first loading from zero), the rainflow residue counted
                           as half cycles, instead of the repeated (stabilised) block
  elastic_notch            no notch plasticity: sig = Kt S, eps = sig/E
"""
import json, sys
import numpy as np
sys.path.insert(0, __import__('os').path.join(__import__('os').path.dirname(__file__), '..', '..', 'solution'))
import predict as P


def swt_damage(smax, ea, m):
    smax = np.asarray(smax, float); ea = np.asarray(ea, float)
    keep = (smax > 0) & (ea > 0)
    if not keep.any():
        return 0.0
    E, sf, b, ef, c = m['E'], m['sf'], m['b'], m['ef'], m['c']
    L = np.linspace(-2.0, 90.0, 20000)
    lP = np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L))
    Lc = np.interp(-np.log(smax[keep]*ea[keep]), -lP, L, left=L[0], right=np.inf)
    return float(np.sum(2.0*np.exp(-Lc)))


def neuber_inv(xabs, m, doubled):
    E, K, n = m['E'], m['K'], m['n']
    sig = np.geomspace(1e-4, 4*max(np.max(xabs), 1.0) + 10, 6000)
    eps = sig/E + (2*(sig/(2*K))**(1/n) if doubled else (sig/K)**(1/n))
    lx = np.log(np.sqrt(E*sig*eps))
    xabs = np.maximum(np.asarray(xabs, float), 1e-12)
    s = np.exp(np.interp(np.log(xabs), lx, np.log(sig)))
    s = np.where(np.log(xabs) < lx[0], xabs, s)
    e = s/E + (2*(s/(2*K))**(1/n) if doubled else (s/K)**(1/n))
    return s, e


def rainflow(R):
    """Closed cycles (a, b) and residue of a sequence of turning points (ASTM three-point)."""
    st, cyc = [], []
    for p in R:
        st.append(p)
        while len(st) >= 3 and abs(st[-1] - st[-2]) >= abs(st[-2] - st[-3]):
            cyc.append((st[-3], st[-2]))
            del st[-3:-1]
    return cyc, st


def memory_ignored(S, Kt, m):
    R = P.reversal_points(S)
    cyc, _ = rainflow(R.tolist())
    a = np.array(cyc)
    ds, de = neuber_inv(Kt*np.abs(a[:, 1] - a[:, 0]), m, True)
    smx = np.max(a, axis=1)
    sm, _ = neuber_inv(Kt*np.abs(smx), m, False)
    return swt_damage(np.sign(smx)*sm, de/2, m)


def elastic(S, Kt, m):
    R = P.reversal_points(S)
    cyc, _ = rainflow(R.tolist())
    a = Kt*np.array(cyc)
    return swt_damage(np.max(a, axis=1), np.abs(a[:, 1] - a[:, 0])/(2*m['E']), m)


def residue_half(S, Kt, m):
    """Once through the block from rest: memory stack from zero, first loading on the cyclic curve (and back to it
    whenever |S| exceeds every earlier value), the rainflow residue counted as half cycles."""
    s = S[np.r_[True, np.diff(S) != 0]]
    d = np.diff(s)
    R = (Kt*s[np.r_[True, d[:-1]*d[1:] < 0, True]]).tolist()
    xm = 2*max(abs(v) for v in R) + 1.0
    E, K, n = m['E'], m['K'], m['n']
    sig = np.geomspace(1e-4, 4*xm + 10, 6000)
    lxd = np.log(np.sqrt(E*sig*(sig/E + 2*(sig/(2*K))**(1/n)))); lxc = np.log(np.sqrt(E*sig*(sig/E + (sig/K)**(1/n))))
    ls = np.log(sig)
    dsig = lambda dx: float(np.exp(np.interp(np.log(dx), lxd, ls))) if dx > 0 else 0.0
    first = lambda x: float(np.copysign(np.exp(np.interp(np.log(abs(x)), lxc, ls)), x)) if x != 0 else 0.0
    stx, sts, xmax = [0.0], [0.0], 0.0
    cyc, half = [], []
    for p in R:
        if abs(p) >= xmax:                          # beyond every earlier |S|: cycles inside are closed, cyclic curve
            while len(stx) >= 3:
                cyc.append((abs(stx[-1] - stx[-2]), max(sts[-1], sts[-2]))); del stx[-2:], sts[-2:]
            stx, sts, xmax = [0.0, p], [0.0, first(p)], abs(p)
            continue
        while len(stx) >= 3 and abs(p - stx[-1]) >= abs(stx[-1] - stx[-2]):
            cyc.append((abs(stx[-1] - stx[-2]), max(sts[-1], sts[-2]))); del stx[-2:], sts[-2:]
        o, so = stx[-1], sts[-1]
        stx.append(p); sts.append(so + (dsig(p - o) if p > o else -dsig(o - p)))
    for i in range(1, len(stx) - 1):
        half.append((abs(stx[i + 1] - stx[i]), max(sts[i], sts[i + 1])))
    def dmg(lst, w):
        if not lst:
            return 0.0
        a = np.array(lst); dx, smax = a[:, 0], a[:, 1]
        ds = np.exp(np.interp(np.log(np.maximum(dx, 1e-12)), lxd, ls))
        return w*swt_damage(smax, 0.5*(ds/E + 2*(ds/(2*K))**(1/n)), m)
    return dmg(cyc, 1.0) + dmg(half, 0.5)


def main(route, d, out):
    cfg, x, fs = P.load_case(d)
    Kt = cfg['stress_concentration_factor_Kt']; m = cfg['cyclic_properties']
    if route == 'spikes_kept':
        pass
    elif route == 'spike_threshold_20kN':
        r = np.zeros(len(x)); r[1:-1] = x[1:-1] - 0.5*(x[:-2] + x[2:])
        k = np.where(np.abs(r) > 20.0)[0]
        k = k[(k > 0) & (k < len(x) - 1)]
        k = k[np.abs(r[k]) >= np.maximum(np.abs(r[k - 1]), np.abs(r[k + 1]))]
        x = x.copy(); x[k] = 0.5*(x[k - 1] + x[k + 1])
    else:
        x, _ = P.despike(x)
    if route != 'zero_offset_kept':
        x = x - P.zero_offset(x, fs)
    S = x*cfg['nominal_stress_MPa_per_kN']
    if route == 'memory_ignored':
        D = memory_ignored(S, Kt, m)
    elif route == 'elastic_notch':
        D = elastic(S, Kt, m)
    elif route == 'residue_half_cycles':
        D = residue_half(S, Kt, m)
    else:
        D = P.damage_from_stress(S, Kt, m)[0]
    json.dump({'damage_per_block': D}, open(out, 'w'))


if __name__ == '__main__':
    main(*sys.argv[1:4])
