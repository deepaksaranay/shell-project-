# notch-fatigue-damage

A durability team needs a program that turns a measured service load record of a notched machine part into the fatigue damage that one block of that service does at the notch root. The solver writes `/app/fatigue/predict.py`. The tests run it on eight hidden cases, each run limited to 8 s on one CPU, and require the damage per block of every case to be within the bound of the simulation's damage. Reward is binary: all eight cases must pass.

The method is stated in the instruction: Neuber's rule with the cyclic Ramberg-Osgood curve, Masing branches with material memory, rainflow counting of the block repeated end to start, Smith-Watson-Topper life (no damage for σ_max ≤ 0) and Miner's sum. The difficulty is in applying it correctly to real records, fast enough.

## Difficulty

**Who does this work:** durability and fatigue engineers in the automotive, rail, aerospace and machinery industries. They turn strain-gauge or load-cell records from instrumented vehicles and machines into notch damage (local strain approach after SAE/ASTM practice), usually over hours of data per channel and for many channels, so the analysis program has to be both right and fast.

**What the records contain, unflagged (each occurs in the visible examples):**

1. **Load-cell zero offset.** Every record starts and ends at standstill, where the true load is zero, but the reading there is not (−4.2 to +3.1 kN in the hidden cases, −1.2 to +1.75 kN in the visible). The offset shifts the mean stress and with it the SWT damage. Leaving it in misses the hidden cases by 1.3–3.8 %, more than the bound.
2. **Telemetry corruption.** The channel comes over a wireless telemetry link, and single samples are replaced by unrelated readings. A real sample of this band-limited, densely sampled load lies close to its neighbours; a corrupted one does not. Kept as data, the spikes add cycles: +41 % and +45 % in the two visible cases that have them, and up to +327 % in the hidden ones.
3. **Material memory and the repeated block.** The damage depends on where each cycle's hysteresis loop sits, which depends on the loops around it. Rainflow on the nominal stress with each loop placed on its own (σ_max from the cyclic curve) misses by 8–1066 % on the hidden cases and by 12–31 % on the visible ones. Analysing the block once from standstill, with the rainflow residue as half cycles, instead of the repeated block, misses by up to 78 %. Ignoring notch plasticity misses by 18–2000 %.

**Speed.** The hidden records have 9–12 million samples and about one million turning points each, roughly 20 times the visible ones. The memory model is sequential, and Neuber's rule and the SWT equation are implicit. A correct but unoptimised program, with plain Python loops over the samples and a root finder for every branch and every cycle (`authoring/evidence/naive_correct.py`), gives the visible damages to 0.001 %, but takes 25–37 s on each hidden case and fails the 8 s limit on all eight. The reference (1.6–2.7 s) finds the turning points with array operations, inverts Neuber's rule and SWT by interpolation in tables built once from the explicit forward relations, and keeps only a stack walk in Python.

**The hidden cases are deliberately unlike the visible ones** (`tests/cases.py`, `HIDDEN`; the visible configurations are `VISIBLE` in the same file):

| | Visible (5 cases) | Hidden (8 cases) |
|---|---|---|
| Materials | SAE 1045, AISI 4340, SAE 1020 steels | also Al 7075-T6, Al 2024-T3, Ti-6Al-4V (never seen) |
| Largest elastic notch stress Kt·S | 490–1590 MPa | 910–2320 MPa (beyond the visible range) |
| Overloads | one tensile overload (V4) | compressive overloads in seven of eight, mixed signs |
| Mean load | mostly tensile, one negative (V5) | also mostly compressive (H6) and high tensile preload (H7) |
| Telemetry spikes | 8–12 per record, 50–120 kN readings | 24–60 per record, 5–90 kN readings, some close to the signal |
| Zero offset | −1.2 to +1.75 kN | −4.2 to +3.1 kN |
| Record length | 0.4–1.1 million samples (1 and 2 kHz) | 9.2–11.6 million samples, all 2 kHz with high-frequency vibration |

No visible case appears in the hidden set. A slow implementation that is exact on every visible record times out on every hidden one. Leaving the spikes in passes the visible checks only if the solver ignores the two visible records that have spikes; on the hidden set it fails H1 and H7.

**Instrument noise and hidden data:** the hidden records are generated inside the verifier from `tests/cases.py` and never reach the solver's container. The program runs as an unprivileged user that cannot read `/tests`.

## Reference solution

`solution/solve.sh` installs `solution/predict.py` as `/app/fatigue/predict.py` and runs it on the visible cases:

1. Counts → kN. Corrupted samples: the half second difference r = x[i] − (x[i−1] + x[i+1])/2 is compared with 12 robust standard deviations of r (at least 1 % of the load range), and a flagged local maximum of |r| is replaced by the mean of its neighbours.
2. Zero offset: the median reading over the first and last 2 s (standstill), subtracted.
3. Turning points of the block repeated end to start, started at the largest |S|, which lies on the cyclic curve in the stabilised state, and closed by returning to it.
4. A rainflow stack carries the notch-root stress of every turning point: the cyclic curve at the start, the Masing branch from the point where each branch began, and memory through the stack.
5. SWT life per closed cycle (none for σ_max ≤ 0), Miner's sum.

It reproduces the exact damage (root finding for every branch and cycle, `authoring/provenance/truth.py`) to within 0.005 % on all 13 cases.

## Verification

`tests/test_fatigue.py` generates the eight hidden cases and runs the program on each:

- as `nobody`, pinned to one CPU, with OMP/OpenBLAS/MKL threads set to 1;
- with an 8 s timeout per run, about three times the reference's slowest run.

A run that is killed, exits with an error, or writes no valid `{"damage_per_block": <finite positive number>}` fails its test. Otherwise the damage must be within the bound of the expected damage (`tests/expected_hidden.json`, from the exact solution of the true load). The instruction states the limit and that each damage must meet a relative-error requirement; the size of the bound appears in no file the solver sees. There is a separately named test for each hidden case, plus one test that the program file exists. Reward is 1 only if all nine pass.

**Calibration:** `authoring/evidence/score_submissions.py` grades complete submissions with the unchanged test file through pytest and the CTRF plugin, as `tests/test.sh` does. Each keeps its `reward.txt` and `ctrf.json`, and the summary is in `authoring/evidence/grading_results.txt`. Errors and run times of every program on every case are in `authoring/evidence/case_errors.txt`. The summary was graded with a 6 s limit, before the limit was relaxed to 8 s for slower graders; no outcome changes for any limit from 5.5 s to 25 s.

**Reward 1 (9/9 tests):**

| Submitter | Largest error (13 cases) | Run time on hidden cases |
|---|---|---|
| Reference | 0.005 % | 1.6–2.7 s |
| `authoring/evidence/independent.py`, an independent program with no shared code: spikes found from the sign pattern of second differences, zero from the most frequent reading, two consecutive blocks from rest with only the cycles closing in the second counted, vectorised Newton for Neuber and SWT | 0.004 % | 4.1–5.5 s |
| Spikes removed with a fixed 20 kN threshold, otherwise as the reference | 0.0 % | as the reference |

The bound (1 %) is 200 times the largest error of the two correct programs, which differ in every step. The nearest wrong route misses by 1.3 %.

**Reward 0:**

| Submitter | Tests passed | What fails |
|---|---|---|
| Correct but unoptimised (`naive_correct.py`): Python loops, a root finder per branch and cycle | 1/9 | every hidden case times out (25–37 s); visible damages exact |
| Load-cell zero offset kept | 1/9 | all eight cases, 1.3–3.8 % |
| Telemetry spikes kept | 7/9 | H1 (+3.9 %) and H7 (+327 %) |
| Block once from standstill, residue as half cycles | 2/9 | seven cases, 2.5–78 % |
| Memory ignored (each rainflow loop on its own) | 1/9 | all eight, 8–1066 % |
| Elastic notch (no Neuber plasticity) | 1/9 | all eight, 18–2000 % |

Every route that fails on the hidden set also misses at least one visible case by more than the bound (`case_errors.txt`), apart from the timing: the visible records are small enough for the unoptimised program.

**Trivial answers:** the hidden damages range from 0.141 to 6.98 per block. With a 1 % bound, no constant passes more than one case, and the reward needs all eight.

The generator settings of every case (offsets, spikes, overloads, materials) and the damages are in `authoring/evidence/generator_truth.json`.
