"""Service load records of a notched component (shared by the hidden test cases and the authoring generator).

A record is one block of service: the machine starts from standstill, runs through operating states (a mean load with a
random load on top, in one or more frequency bands, with smooth transitions), sees occasional overload events (half-sine
pulses) and stops again. The load cell is read through a 16-bit telemetry channel in ADC counts. Two acquisition faults
are built in: the load cell's zero is offset (the reading at standstill is not zero), and the telemetry corrupts single
samples (a sample replaced by an unrelated reading). Truth is computed from the true load (authoring/provenance).

    record(cfg) -> (true_load_kN float64 array, counts int16 array)
"""
import numpy as np

BANDS = {'low': (0.3, 3.0), 'mid': (2.0, 12.0), 'wide': (0.5, 40.0), 'hf': (25.0, 150.0)}   # Hz

MATERIALS = {   # cyclic properties: E, K', n' (Ramberg-Osgood); sf', b, ef', c (strain-life)
    'SAE 1045 Q&T':        dict(E=202000.0, K=1258.0, n=0.208, sf=948.0,  b=-0.092, ef=0.260, c=-0.445),
    'AISI 4340 Q&T':       dict(E=200000.0, K=1655.0, n=0.131, sf=1879.0, b=-0.0859, ef=0.640, c=-0.636),
    'SAE 1020 hot-rolled': dict(E=203000.0, K=772.0,  n=0.180, sf=896.0,  b=-0.120, ef=0.410, c=-0.510),
    'Al 7075-T6':          dict(E=71000.0,  K=977.0,  n=0.106, sf=1466.0, b=-0.143, ef=0.262, c=-0.619),
    'Ti-6Al-4V STA':       dict(E=117000.0, K=1772.0, n=0.106, sf=2030.0, b=-0.104, ef=0.841, c=-0.688),
    'Al 2024-T3':          dict(E=73100.0,  K=662.0,  n=0.070, sf=1294.0, b=-0.142, ef=0.327, c=-0.645),
}


def _band_process(rng, n, band, FS):
    """Unit-variance Gaussian process with a flat spectrum between the band edges (FFT filtering of white noise)."""
    f_lo, f_hi = BANDS[band]
    w = rng.standard_normal(n)
    W = np.fft.rfft(w)
    f = np.fft.rfftfreq(n, 1.0/FS)
    W[(f < f_lo) | (f > f_hi)] = 0.0
    x = np.fft.irfft(W, n)
    return x/np.std(x)


def _ramp_profile(n, knots, FS):
    """Piecewise-constant profile with 2 s raised-cosine transitions. knots: list of (start_s, value)."""
    t = np.arange(n)/FS
    out = np.zeros(n)
    prev = 0.0
    for ts, v in knots:
        s = np.clip((t - ts)/2.0, 0.0, 1.0)
        out += (v - prev)*0.5*(1 - np.cos(np.pi*s))
        prev = v
    return out


def record(cfg):
    rng = np.random.default_rng(cfg['seed'])
    FS = cfg.get('fs', 1000.0)
    t_run = sum(seg[0] for seg in cfg['segments'])
    n = int(round((cfg['standstill_s'][0] + t_run + cfg['standstill_s'][1] + 4.0)*FS))
    # operating-state knots: mean load and the rms of each band
    t0 = cfg['standstill_s'][0]
    bands = sorted({b for seg in cfg['segments'] for b in seg[2]})
    mean_knots, rms_knots = [], {b: [] for b in bands}
    ts = t0
    for dur, mean, rms_by_band in cfg['segments']:
        mean_knots.append((ts, mean))
        for b in bands:
            rms_knots[b].append((ts, rms_by_band.get(b, 0.0)))
        ts += dur
    mean_knots.append((ts, 0.0))
    for b in bands:
        rms_knots[b].append((ts, 0.0))
    load = _ramp_profile(n, mean_knots, FS)
    for b in bands:
        load += _ramp_profile(n, rms_knots[b], FS)*_band_process(rng, n, b, FS)
    t = np.arange(n)/FS
    for (te, peak, dur) in cfg.get('overloads', []):
        s = (t - te)/dur
        m = (s >= 0) & (s <= 1)
        load[m] += peak*np.sin(np.pi*s[m])
    load[np.abs(load) < 1e-12] = 0.0
    # acquisition: zero offset of the load cell, 16-bit counts, single-sample telemetry corruption
    q = cfg['kN_per_count']
    counts = np.rint((load + cfg['zero_offset_kN'])/q)
    assert np.abs(counts).max() < 32000, 'load channel would saturate'
    counts = np.clip(counts, -32767, 32767)
    sp = cfg.get('spikes')
    if sp:
        k = rng.choice(np.arange(int(5*FS), n - int(5*FS)), size=sp['count'], replace=False)
        mag = rng.uniform(sp['min_kN'], sp['max_kN'], size=sp['count'])*rng.choice([-1.0, 1.0], size=sp['count'])
        counts[k] = np.clip(np.rint(mag/q), -32767, 32767)
    return load, counts.astype(np.int16)


def case_json(cfg):
    """The case description the solver's program receives (no truth, no fault parameters)."""
    return {
        'component': cfg['component'],
        'material': cfg['material'],
        'cyclic_properties': {k: MATERIALS[cfg['material']][k] for k in ('E', 'K', 'n', 'sf', 'b', 'ef', 'c')},
        'stress_concentration_factor_Kt': cfg['Kt'],
        'nominal_stress_MPa_per_kN': cfg['MPa_per_kN'],
        'load_channel': {'file': 'load_counts.npy', 'dtype': 'int16', 'kN_per_count': cfg['kN_per_count'],
                         'sample_rate_Hz': cfg.get('fs', 1000.0),
                         'acquisition': '16-bit load cell signal sent over a wireless telemetry link from the rotating/moving part'},
        'block': ('the record is one block of service, from standstill to standstill; in service the block is repeated '
                  'end to start without a break'),
    }


def _seg(spec):
    return [(d, m, r) for d, m, r in spec]


# ---------------------------------------------------------------------------------------------------------------------
# Hidden test cases. They are deliberately unlike the visible ones (environment/data/cases): materials never seen
# (aluminium alloys, titanium), notch strains well beyond the visible range, compressive overloads (the visible data have
# one tensile overload record only), mostly-compressive mean load, spikes of a size never seen, larger and negative load
# cell offsets, and records about twenty times longer (2 kHz, high-frequency vibration on every operating state).
HF = {'H1': 3.0, 'H2': 5.0, 'H3': 3.5, 'H4': 6.0, 'H5': 5.5, 'H6': 4.0, 'H7': 3.0, 'H8': 5.0}
HIDDEN = {
    'H1': dict(component='wing-attachment lug', material='Al 7075-T6', Kt=2.6, MPa_per_kN=4.2, kN_per_count=0.0040,
               zero_offset_kN=-2.35, standstill_s=(9.0, 7.0), seed=9101,
               segments=_seg([(1500, 18.0, {'mid': 9.0, 'low': 6.0}), (1800, 10.0, {'wide': 7.5}),
                              (1400, 22.0, {'mid': 11.0})]),
               overloads=[(1200.0, -62.0, 0.6), (3100.0, -70.0, 0.5), (4400.0, 55.0, 0.5)],
               spikes=dict(count=25, min_kN=20.0, max_kN=60.0)),
    'H2': dict(component='connecting-rod shank', material='Ti-6Al-4V STA', Kt=2.1, MPa_per_kN=6.5, kN_per_count=0.0060,
               zero_offset_kN=1.85, standstill_s=(6.0, 6.0), seed=9102,
               segments=_seg([(2500, 25.0, {'wide': 20.0}), (2400, 30.0, {'mid': 22.0, 'low': 10.0})]),
               overloads=[(3000.0, -95.0, 0.4)],
               spikes=dict(count=40, min_kN=8.0, max_kN=30.0)),
    'H3': dict(component='landing-gear torque link', material='Al 2024-T3', Kt=2.9, MPa_per_kN=3.6, kN_per_count=0.0045,
               zero_offset_kN=-3.10, standstill_s=(8.0, 10.0), seed=9103,
               segments=_seg([(1600, 5.0, {'wide': 11.0}), (2000, -4.0, {'mid': 12.0}), (1500, 8.0, {'low': 9.0, 'wide': 6.0})]),
               overloads=[(900.0, 60.0, 0.5), (2600.0, -66.0, 0.5)],
               spikes=dict(count=30, min_kN=15.0, max_kN=45.0)),
    'H4': dict(component='axle fillet', material='SAE 1045 Q&T', Kt=2.4, MPa_per_kN=5.5, kN_per_count=0.0060,
               zero_offset_kN=-4.20, standstill_s=(7.0, 7.0), seed=9104,
               segments=_seg([(2000, 15.0, {'wide': 24.0}), (2600, 12.0, {'mid': 26.0})]),
               overloads=[(1700.0, -120.0, 0.6), (3900.0, -110.0, 0.6)],
               spikes=dict(count=35, min_kN=25.0, max_kN=80.0)),
    'H5': dict(component='crankshaft web', material='AISI 4340 Q&T', Kt=2.7, MPa_per_kN=5.0, kN_per_count=0.0065,
               zero_offset_kN=2.65, standstill_s=(10.0, 8.0), seed=9105,
               segments=_seg([(3000, 20.0, {'wide': 21.0}), (2800, 26.0, {'mid': 20.0, 'low': 12.0})]),
               overloads=[(2200.0, 115.0, 0.4), (4700.0, -100.0, 0.4)],
               spikes=dict(count=60, min_kN=5.0, max_kN=15.0)),
    'H6': dict(component='press-frame tie (mostly compressive)', material='SAE 1020 hot-rolled', Kt=2.3, MPa_per_kN=4.8,
               kN_per_count=0.0050, zero_offset_kN=-1.40, standstill_s=(6.0, 9.0), seed=9106,
               segments=_seg([(2200, -25.0, {'mid': 14.0}), (2400, -18.0, {'wide': 16.0, 'low': 6.0})]),
               overloads=[(1000.0, 45.0, 0.5), (3500.0, -70.0, 0.5)],
               spikes=dict(count=30, min_kN=10.0, max_kN=40.0)),
    'H7': dict(component='bracket under preload', material='Al 7075-T6', Kt=2.2, MPa_per_kN=4.0, kN_per_count=0.0060,
               zero_offset_kN=3.05, standstill_s=(8.0, 8.0), seed=9107,
               segments=_seg([(2500, 45.0, {'wide': 10.0}), (2300, 52.0, {'mid': 12.0})]),
               overloads=[(1400.0, 105.0, 0.5), (3600.0, -40.0, 0.5)],
               spikes=dict(count=25, min_kN=30.0, max_kN=90.0)),
    'H8': dict(component='hydraulic cylinder eye', material='Ti-6Al-4V STA', Kt=2.5, MPa_per_kN=5.8, kN_per_count=0.0065,
               zero_offset_kN=-2.80, standstill_s=(12.0, 12.0), seed=9108,
               segments=_seg([(1500, 30.0, {'low': 18.0}), (1500, 0.0, {'wide': 24.0}), (1700, 34.0, {'mid': 22.0})]),
               overloads=[(800.0, -105.0, 0.5), (2300.0, 125.0, 0.5), (4000.0, -115.0, 0.5)],
               spikes=dict(count=45, min_kN=6.0, max_kN=20.0)),
}
for _k, _c in HIDDEN.items():                      # every hidden record: 2 kHz with machine vibration on top
    _c['fs'] = 2000.0
    _c['segments'] = [(d, mm, {**r, 'hf': HF[_k]}) for d, mm, r in _c['segments']]

# Visible cases (environment/data/cases), with their damage given to the solver. Every effect that matters for the
# hidden cases occurs in at least one of them: plasticity at the notch (V2), a tensile overload (V4), telemetry spikes
# (V3, V5), load-cell zero offset (all), a negative mean load (V5), a quiet low-band record (V1) and a 2 kHz record with high-frequency vibration (V2).
VISIBLE = {
    'V1': dict(component='axle fillet', material='SAE 1045 Q&T', Kt=2.2, MPa_per_kN=5.0, kN_per_count=0.0050,
               zero_offset_kN=0.95, standstill_s=(5.0, 5.0), seed=8101,
               segments=_seg([(250, 12.0, {'low': 14.0, 'mid': 6.0}), (200, 8.0, {'mid': 15.0})])),
    'V2': dict(component='crankshaft web', material='AISI 4340 Q&T', Kt=2.6, MPa_per_kN=5.0, kN_per_count=0.0050,
               zero_offset_kN=-1.20, standstill_s=(5.0, 5.0), seed=8102,
               segments=_seg([(300, 22.0, {'wide': 22.0, 'hf': 4.0}), (250, 25.0, {'mid': 21.0, 'hf': 5.0})]), fs=2000.0),
    'V3': dict(component='suspension link', material='SAE 1020 hot-rolled', Kt=2.0, MPa_per_kN=4.5, kN_per_count=0.0040,
               zero_offset_kN=0.60, standstill_s=(5.0, 6.0), seed=8103,
               segments=_seg([(400, 6.0, {'wide': 12.0})]),
               spikes=dict(count=12, min_kN=60.0, max_kN=120.0)),
    'V4': dict(component='axle fillet', material='SAE 1045 Q&T', Kt=2.3, MPa_per_kN=5.0, kN_per_count=0.0050,
               zero_offset_kN=1.75, standstill_s=(6.0, 5.0), seed=8104,
               segments=_seg([(220, 10.0, {'mid': 18.0}), (230, 14.0, {'wide': 16.0})]),
               overloads=[(180.0, 92.0, 0.5)]),
    'V5': dict(component='press-frame tie', material='AISI 4340 Q&T', Kt=2.4, MPa_per_kN=5.0, kN_per_count=0.0050,
               zero_offset_kN=-0.85, standstill_s=(5.0, 5.0), seed=8105,
               segments=_seg([(300, -10.0, {'mid': 20.0}), (200, 4.0, {'low': 15.0})]),
               spikes=dict(count=8, min_kN=50.0, max_kN=110.0)),
}
