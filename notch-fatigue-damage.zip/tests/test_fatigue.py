"""Runs the solver's program on hidden service records and checks the damage per block against the simulation.

The hidden records are generated here (cases.py) and are deliberately unlike the visible ones: other materials, larger
notch strains, compressive overloads, other fault sizes and records about twenty times longer. Each run is limited to
TIME_LIMIT_S seconds on one CPU (threads pinned); a run that is killed, fails or writes no valid result fails its test.
The program runs as an unprivileged user that cannot read this directory.
"""
import json
import math
import os
import pwd
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent))
import cases  # noqa: E402

PROGRAM = Path(os.environ.get('FATIGUE_PROGRAM', '/app/fatigue/predict.py'))
EXPECTED = json.loads((Path(__file__).parent / 'expected_hidden.json').read_text())['damage_per_block']
TIME_LIMIT_S = 8.0
REL_TOL = 0.01
RUN_USER = os.environ.get('FATIGUE_RUN_USER', 'nobody')


def _no_repeats(items):
    out = {}
    for k, v in items:
        if k in out:
            raise ValueError(f'repeated key {k}')
        out[k] = v
    return out


@pytest.fixture(scope='session')
def workdir():
    root = Path(tempfile.mkdtemp(prefix='fatigue_hidden_'))
    os.chmod(root, 0o755)
    prog = root / 'program' / 'predict.py'
    prog.parent.mkdir()
    if PROGRAM.is_file() and not PROGRAM.is_symlink():
        shutil.copyfile(PROGRAM, prog)
        os.chmod(prog, 0o644)
    for name, cfg in cases.HIDDEN.items():
        d = root / name
        d.mkdir()
        _, counts = cases.record(cfg)
        np.save(d / 'load_counts.npy', counts)
        (d / 'case.json').write_text(json.dumps(cases.case_json(cfg), indent=2))
        os.chmod(d, 0o777)
    yield root
    shutil.rmtree(root, ignore_errors=True)


def _demote():
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})        # one CPU
    if os.getuid() == 0 and RUN_USER:
        pw = pwd.getpwnam(RUN_USER)
        os.setgroups([])
        os.setgid(pw.pw_gid)
        os.setuid(pw.pw_uid)


def test_program_present():
    assert PROGRAM.is_file() and not PROGRAM.is_symlink(), f'{PROGRAM} is missing or is a symbolic link'


def _run_case(workdir, name):
    prog = workdir / 'program' / 'predict.py'
    assert prog.is_file(), f'{PROGRAM} is missing'
    case_dir = workdir / name
    out = case_dir / 'result.json'
    env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(case_dir), 'OMP_NUM_THREADS': '1',
           'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
    try:
        r = subprocess.run([sys.executable, str(prog), str(case_dir), str(out)], cwd=case_dir, env=env,
                           capture_output=True, text=True, timeout=TIME_LIMIT_S, preexec_fn=_demote)
    except subprocess.TimeoutExpired:
        pytest.fail(f'{name}: the run did not finish within {TIME_LIMIT_S:.0f} s on 1 CPU')
    assert r.returncode == 0, f'{name}: the program exited with code {r.returncode}: {r.stderr[-800:]}'
    assert out.is_file() and not out.is_symlink(), f'{name}: no result file written'
    try:
        data = json.loads(out.read_text(), object_pairs_hook=_no_repeats)
    except ValueError as exc:
        pytest.fail(f'{name}: result file is not valid JSON: {exc}')
    assert isinstance(data, dict) and list(data) == ['damage_per_block'], \
        f'{name}: the result must be an object with the single key damage_per_block'
    v = data['damage_per_block']
    assert isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > 0, \
        f'{name}: damage_per_block must be a finite positive number'
    truth = EXPECTED[name]
    assert abs(v/truth - 1) <= REL_TOL, f'{name}: damage per block {v:.6g} does not meet the requirement'


def _make(name):
    def test(workdir):
        _run_case(workdir, name)
    test.__name__ = f'test_hidden_case_{name}'
    test.__doc__ = f'Hidden case {name}: run within the time limit, valid result, damage per block within the requirement.'
    return test


for _name in sorted(cases.HIDDEN):                   # one separately named test per hidden case
    globals()[f'test_hidden_case_{_name}'] = _make(_name)
