"""Reference program: fatigue damage per block at a notch from a service load record.

    python3 predict.py <case_dir> <output_json>

1. Read the ADC counts and convert them to kN.
2. Telemetry corruption: single samples replaced by an unrelated reading. The load is band-limited and sampled at 1 kHz,
   so a real sample lies close to the mean of its two neighbours; a corrupted one does not. The half second difference
   r = x[i] - (x[i-1] + x[i+1])/2 is compared with a threshold (12 robust standard deviations of r, at least 1 % of the
   load range), and a flagged sample is replaced by the mean of its neighbours.
3. Load-cell zero: the record starts and ends at standstill (no load), so the median reading over the first and last
   two seconds is the zero offset, removed from every sample.
4. Nominal stress, turning points of the block repeated end to start, started at the largest |S|.
5. Notch root: Neuber with the cyclic Ramberg-Osgood curve for the first point, the Masing-doubled curve for every branch
   from the reversal where it began, material memory through the rainflow stack (a closed loop returns the material to the
   branch it left). Neuber is inverted by interpolation in tables built once from the explicit forward relations (the
   branch table on a uniform grid in log x, so the stack walk finds its interval by direct indexing).
6. Smith-Watson-Topper life per closed cycle (none for sig_max <= 0), inverted by interpolation in a table of log(2N);
   Miner's sum is the damage per block.
"""
import json, sys
from bisect import bisect_left
from math import log, exp
import numpy as np


def load_case(d):
    cfg = json.load(open(f'{d}/case.json'))
    ch = cfg['load_channel']
    x = np.load(f"{d}/{ch['file']}").astype(np.float64)*ch['kN_per_count']
    return cfg, x, ch['sample_rate_Hz']


def despike(x):
    r = x[1:-1] - 0.5*(x[:-2] + x[2:])
    rs = r[::7]                                  # robust statistics from every 7th sample (enough, and fast)
    s = 1.4826*np.median(np.abs(rs - np.median(rs)))
    lo, hi = np.percentile(x[::7], [0.1, 99.9])
    thr = max(12.0*s, 0.01*(hi - lo))          # never below 1 % of the load range: quiet records have a tiny s
    bad = np.zeros(len(x), bool)
    bad[1:-1] = np.abs(r) > thr
    # a corrupted sample also disturbs r of its neighbours (by half its error): keep only the local maxima of |r|
    ar = np.zeros(len(x)); ar[1:-1] = np.abs(r)
    bad &= (ar >= np.roll(ar, 1)) & (ar >= np.roll(ar, -1))
    y = x.copy()
    k = np.where(bad)[0]
    y[k] = 0.5*(x[k - 1] + x[k + 1])
    return y, len(k)


def zero_offset(x, fs):
    m = int(2*fs)
    return float(np.median(np.r_[x[:m], x[-m:]]))


def reversal_points(S):
    i = int(np.argmax(np.abs(S)))
    s = np.concatenate([S[i:], S[:i + 1]])
    s = s[np.r_[True, np.diff(s) != 0]]
    d = np.diff(s)
    return s[np.r_[True, d[:-1]*d[1:] < 0, True]]


def tables(m, xmax):
    """Inverse Neuber tables in log space: cyclic curve (first loading) and doubled curve (branches)."""
    E, K, n = m['E'], m['K'], m['n']
    sig = np.geomspace(1e-4, 4*xmax + 10, 20000)
    eps_c = sig/E + (sig/K)**(1/n)
    eps_d = sig/E + 2*(sig/(2*K))**(1/n)
    xc = np.sqrt(E*sig*eps_c)                     # x = Kt*S for which Neuber gives sig on the cyclic curve
    xd = np.sqrt(E*sig*eps_d)                     # x = Kt*dS for the doubled curve
    # branch table on a uniform grid in log x (direct index in the stack walk)
    lxu = np.linspace(np.log(xd[0]), np.log(xd[-1]), 6000)
    lsu = np.interp(lxu, np.log(xd), np.log(sig))
    return (np.log(xc), np.log(sig)), (lxu, lsu, None)


def damage_from_stress(S, Kt, m):
    """Damage per block of the repeated block from the nominal stress history S (MPa)."""
    E, K, n = m['E'], m['K'], m['n']
    R = reversal_points(S)
    xmax = Kt*2*float(np.max(np.abs(R)))
    (lxc, lsc), (lxd, lsd, _) = tables(m, xmax)
    lxd_l, lsd_l = lxd.tolist(), lsd.tolist()

    def first(x):                                   # cyclic curve: stress for Kt*S = x
        return float(np.copysign(np.exp(np.interp(np.log(abs(x)), lxc, lsc)), x)) if x != 0 else 0.0

    Rl = (Kt*R).tolist()                            # work with x = Kt*S
    stx, sts = [Rl[0]], [first(Rl[0])]
    cyc_dx, cyc_smax = [], []
    add_dx, add_sm = cyc_dx.append, cyc_smax.append
    x0, dl0, n_tab = lxd_l[0], lxd_l[1] - lxd_l[0], len(lxd_l)
    for P in Rl[1:]:
        while len(stx) >= 2:
            a, b = stx[-2], stx[-1]
            r = b - a if b > a else a - b
            if (P - b if P > b else b - P) < r:
                break
            add_dx(r)
            sa, sb = sts[-2], sts[-1]
            add_sm(sb if sb > sa else sa)
            del stx[-2:], sts[-2:]
        if not stx:                                 # the largest |S| reached again: back on the cyclic curve
            stx.append(P); sts.append(first(P))
            continue
        o = stx[-1]
        dx = P - o if P > o else o - P
        if dx > 0.0:                                # branch stress range: table lookup (uniform grid in log x)
            L = log(dx)
            j = int((L - x0)/dl0)
            if j < 0:
                d = dx
            else:
                if j >= n_tab - 1:
                    j = n_tab - 2
                f = (L - lxd_l[j])/(lxd_l[j + 1] - lxd_l[j])
                d = exp(lsd_l[j] + f*(lsd_l[j + 1] - lsd_l[j]))
        else:
            d = 0.0
        stx.append(P)
        sts.append(sts[-1] + d if P > o else sts[-1] - d)
    dx = np.asarray(cyc_dx); smax = np.asarray(cyc_smax)
    keep = (dx > 0) & (smax > 0)                    # SWT: no damage for sig_max <= 0
    dx, smax = dx[keep], smax[keep]
    ds = np.exp(np.interp(np.log(dx), lxd, lsd))
    ds = np.where(np.log(dx) < lxd[0], dx, ds)
    ea = 0.5*(ds/E + 2*(ds/(2*K))**(1/n))
    L = np.linspace(-2.0, 90.0, 20000)               # log(2N)
    sf, b, ef, c = m['sf'], m['b'], m['ef'], m['c']
    lP = np.log(sf*sf/E*np.exp(2*b*L) + sf*ef*np.exp((b + c)*L))   # decreasing in L
    Lc = np.interp(-np.log(smax*ea), -lP, L, left=L[0], right=np.inf)
    return float(np.sum(2.0*np.exp(-Lc))), len(R), len(cyc_dx)


def main(case_dir, out):
    cfg, x, fs = load_case(case_dir)
    x, n_spikes = despike(x)
    x = x - zero_offset(x, fs)
    S = x*cfg['nominal_stress_MPa_per_kN']
    D, nr, nc = damage_from_stress(S, cfg['stress_concentration_factor_Kt'], cfg['cyclic_properties'])
    json.dump({'damage_per_block': D}, open(out, 'w'))
    print(f'# spikes removed {n_spikes}, reversals {nr}, cycles {nc}, damage per block {D:.6e}', file=sys.stderr)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
